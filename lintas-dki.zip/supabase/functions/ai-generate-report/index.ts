import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': '*',
};

interface Article {
  title: string;
  category: string;
  source: string;
  mediaType: string;
  time: string;
  summary: string;
  content?: string;
  link: string;
  date: string;
}

interface GenerateReportRequest {
  date: string;
  articles: Article[];
  piketNames?: string[];
  useAI?: boolean;
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: corsHeaders });
  }

  try {
    const requestId = crypto.randomUUID();
    console.log(`[${requestId}] Report generation request received`);

    const { date, articles, piketNames = [], useAI = false }: GenerateReportRequest = await req.json();

    // Validate input
    if (!date || !articles || articles.length === 0) {
      return new Response(
        JSON.stringify({ error: 'Date and articles are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`[${requestId}] Generating report for ${date} with ${articles.length} articles`);

    // Format date in Indonesian
    const dateObj = new Date(date);
    const dateStr = dateObj.toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    // Build report following the EXACT template format
    let reportContent = `*Melaporkan,*\n`;
    reportContent += `*Pantauan hal-hal menonjol di media online dan sosial pada ${dateStr} hingga pukul 22.00 WIB dapat dilaporkan sebagai berikut:*\n\n`;

    // Group articles by category
    const categories = ['Politik', 'Ekonomi', 'Sosbud', 'Hankam'];
    const grouped: Record<string, Article[]> = {};

    articles.forEach((article) => {
      const cat = article.category || 'Lainnya';
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(article);
    });

    // Generate sections for each category
    categories.forEach((cat) => {
      if (grouped[cat] && grouped[cat].length > 0) {
        reportContent += `*${cat}:*\n`;

        grouped[cat].forEach((item, idx) => {
          // Use letter prefix (a, b, c, etc.)
          const prefix = String.fromCharCode(97 + idx) + '. ';

          // Clean source name
          const cleanSource = item.source ? item.source.replace(/[""]/g, '') : 'Sumber';

          // Determine media type
          const mediaType = item.mediaType || 'media online';

          // Build report item
          reportContent += `${prefix}Pukul ${item.time} WIB, melalui ${mediaType} "${cleanSource}", diperoleh informasi bahwa ${item.summary}`;

          // Add additional content if available
          if (item.content && item.content.trim()) {
            reportContent += `. ${item.content}`;
          }

          reportContent += `\n`;
          reportContent += `Link: ${item.link || 'Tidak tersedia'}\n\n`;
        });
      }
    });

    // Add piket names
    const piketText = piketNames.length > 0 ? piketNames.join(', ') : '...., ....., .....';
    reportContent += `*Piket : ${piketText}*`;

    // If AI enhancement is requested
    if (useAI) {
      console.log(`[${requestId}] Enhancing report with AI`);
      
      const openaiApiKey = Deno.env.get('OPENAI_API_KEY');
      if (openaiApiKey) {
        try {
          const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${openaiApiKey}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              model: 'gpt-4-turbo-preview',
              messages: [
                {
                  role: 'system',
                  content: 'Anda adalah asisten yang membantu menyempurnakan laporan monitoring media. Perbaiki tata bahasa dan struktur kalimat tanpa mengubah format template atau informasi faktual.',
                },
                {
                  role: 'user',
                  content: `Sempurnakan laporan berikut dengan memperbaiki tata bahasa dan struktur kalimat, tetapi JANGAN ubah format template, waktu, sumber, atau link:\n\n${reportContent}`,
                },
              ],
              temperature: 0.3,
              max_tokens: 3000,
            }),
          });

          if (response.ok) {
            const aiData = await response.json();
            reportContent = aiData.choices[0].message.content;
            console.log(`[${requestId}] AI enhancement completed`);
          }
        } catch (aiError) {
          console.error(`[${requestId}] AI enhancement failed:`, aiError);
          // Continue with non-AI enhanced version
        }
      }
    }

    // Log generation to database
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    let userId = null;
    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      const { data: { user } } = await supabase.auth.getUser(token);
      userId = user?.id;
    }

    await supabase.from('ai_generations').insert({
      user_id: userId,
      generation_type: 'report',
      input_prompt: `Generate report for ${date} with ${articles.length} articles`,
      output_content: reportContent,
      model_used: useAI ? 'gpt-4-turbo-preview' : 'template',
      tokens_used: Math.ceil(reportContent.length / 4),
      cost: 0,
      metadata: {
        date,
        article_count: articles.length,
        categories: Object.keys(grouped),
        piket_names: piketNames,
      },
    });

    console.log(`[${requestId}] Report generation completed successfully`);

    return new Response(
      JSON.stringify({
        title: `Laporan Monitoring ${dateStr}`,
        content: reportContent,
        sections: grouped,
        wordCount: reportContent.split(/\s+/).length,
        metadata: {
          date,
          articleCount: articles.length,
          categories: Object.keys(grouped),
        },
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  } catch (error) {
    console.error('Report generation error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Create custom types
CREATE TYPE user_role AS ENUM ('admin', 'editor');
CREATE TYPE article_status AS ENUM ('draft', 'published', 'scheduled', 'archived');
CREATE TYPE report_type AS ENUM ('investigation', 'analysis', 'breaking');
CREATE TYPE report_priority AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE sentiment_type AS ENUM ('positive', 'neutral', 'negative');
CREATE TYPE ai_generation_type AS ENUM ('article', 'summary', 'classification', 'report', 'assistant');
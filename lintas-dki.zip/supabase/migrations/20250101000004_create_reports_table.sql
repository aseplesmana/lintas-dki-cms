-- Reports table
CREATE TABLE IF NOT EXISTS public.reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  content TEXT NOT NULL,
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  author_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
  report_type report_type DEFAULT 'analysis',
  featured_image TEXT,
  status article_status DEFAULT 'draft',
  published_at TIMESTAMPTZ,
  priority report_priority DEFAULT 'medium',
  source_urls TEXT[],
  report_date DATE DEFAULT CURRENT_DATE,
  piket_names TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Published reports are viewable by everyone"
  ON public.reports FOR SELECT
  USING (status = 'published' OR author_id = auth.uid());

CREATE POLICY "Authenticated users can insert reports"
  ON public.reports FOR INSERT
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authors can update their own reports"
  ON public.reports FOR UPDATE
  USING (author_id = auth.uid());

CREATE POLICY "Admins can update all reports"
  ON public.reports FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = auth.uid() AND users.role = 'admin'
    )
  );

CREATE POLICY "Admins can delete reports"
  ON public.reports FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = auth.uid() AND users.role = 'admin'
    )
  );

-- Create indexes
CREATE INDEX idx_reports_slug ON public.reports(slug);
CREATE INDEX idx_reports_category_id ON public.reports(category_id);
CREATE INDEX idx_reports_author_id ON public.reports(author_id);
CREATE INDEX idx_reports_status ON public.reports(status);
CREATE INDEX idx_reports_priority ON public.reports(priority);
CREATE INDEX idx_reports_published_at ON public.reports(published_at DESC);
CREATE INDEX idx_reports_report_date ON public.reports(report_date DESC);

-- Trigger for updated_at
CREATE TRIGGER update_reports_updated_at
  BEFORE UPDATE ON public.reports
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
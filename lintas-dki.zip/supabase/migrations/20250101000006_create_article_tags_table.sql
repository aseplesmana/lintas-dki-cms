-- Article tags junction table
CREATE TABLE IF NOT EXISTS public.article_tags (
  article_id UUID REFERENCES public.articles(id) ON DELETE CASCADE,
  tag_id UUID REFERENCES public.tags(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (article_id, tag_id)
);

-- Enable RLS
ALTER TABLE public.article_tags ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Article tags are viewable by everyone"
  ON public.article_tags FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage article tags"
  ON public.article_tags FOR ALL
  USING (auth.uid() IS NOT NULL);

-- Create indexes
CREATE INDEX idx_article_tags_article_id ON public.article_tags(article_id);
CREATE INDEX idx_article_tags_tag_id ON public.article_tags(tag_id);
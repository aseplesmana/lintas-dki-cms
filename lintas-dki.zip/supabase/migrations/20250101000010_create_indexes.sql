-- Additional performance indexes

-- Composite indexes for common queries
CREATE INDEX idx_articles_status_published_at ON public.articles(status, published_at DESC) 
  WHERE status = 'published';

CREATE INDEX idx_articles_category_status ON public.articles(category_id, status, published_at DESC);

CREATE INDEX idx_reports_status_date ON public.reports(status, report_date DESC) 
  WHERE status = 'published';

-- GIN index for array searches
CREATE INDEX idx_reports_source_urls ON public.reports USING gin(source_urls);
CREATE INDEX idx_reports_piket_names ON public.reports USING gin(piket_names);

-- Partial indexes for performance
CREATE INDEX idx_articles_featured ON public.articles(published_at DESC) 
  WHERE is_featured = true AND status = 'published';

CREATE INDEX idx_media_monitoring_unprocessed ON public.media_monitoring(scraped_at DESC) 
  WHERE is_processed = false;
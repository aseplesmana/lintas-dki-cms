-- Media monitoring table
CREATE TABLE IF NOT EXISTS public.media_monitoring (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source_name TEXT NOT NULL,
  source_url TEXT NOT NULL,
  source_type TEXT NOT NULL, -- 'website', 'instagram', 'facebook', 'twitter', 'tiktok'
  title TEXT NOT NULL,
  content TEXT,
  published_date TIMESTAMPTZ,
  scraped_at TIMESTAMPTZ DEFAULT NOW(),
  category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
  sentiment sentiment_type DEFAULT 'neutral',
  is_processed BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.media_monitoring ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Authenticated users can view monitoring"
  ON public.media_monitoring FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "System can insert monitoring data"
  ON public.media_monitoring FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update monitoring"
  ON public.media_monitoring FOR UPDATE
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can delete monitoring"
  ON public.media_monitoring FOR DELETE
  USING (
    EXISTS (
      SELECT 1 FROM public.users
      WHERE users.id = auth.uid() AND users.role = 'admin'
    )
  );

-- Create indexes
CREATE INDEX idx_media_monitoring_source_name ON public.media_monitoring(source_name);
CREATE INDEX idx_media_monitoring_category_id ON public.media_monitoring(category_id);
CREATE INDEX idx_media_monitoring_is_processed ON public.media_monitoring(is_processed);
CREATE INDEX idx_media_monitoring_published_date ON public.media_monitoring(published_date DESC);
CREATE INDEX idx_media_monitoring_scraped_at ON public.media_monitoring(scraped_at DESC);
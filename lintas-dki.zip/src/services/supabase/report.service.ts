import { supabase } from './client';
import { Report, CreateReportDTO, UpdateReportDTO, ReportFilters } from '../../types/report.types';
import { PaginationParams, PaginatedResponse } from '../../types/common.types';

export class ReportService {
  async getReports(
    filters?: ReportFilters,
    pagination?: PaginationParams
  ): Promise<PaginatedResponse<Report>> {
    let query = supabase
      .from('reports')
      .select(`
        *,
        category:categories(*),
        author:users(*)
      `, { count: 'exact' });

    // Apply filters
    if (filters?.search) {
      query = query.or(`title.ilike.%${filters.search}%,content.ilike.%${filters.search}%`);
    }
    if (filters?.report_type) {
      query = query.eq('report_type', filters.report_type);
    }
    if (filters?.priority) {
      query = query.eq('priority', filters.priority);
    }
    if (filters?.startDate) {
      query = query.gte('report_date', filters.startDate);
    }
    if (filters?.endDate) {
      query = query.lte('report_date', filters.endDate);
    }

    // Apply pagination
    const page = pagination?.page || 1;
    const limit = pagination?.limit || 10;
    const from = (page - 1) * limit;
    const to = from + limit - 1;

    query = query.range(from, to).order('report_date', { ascending: false });

    const { data, error, count } = await query;

    if (error) throw error;

    return {
      data: data || [],
      total: count || 0,
      page,
      limit,
      totalPages: Math.ceil((count || 0) / limit),
    };
  }

  async getReportById(id: string): Promise<Report> {
    const { data, error } = await supabase
      .from('reports')
      .select(`
        *,
        category:categories(*),
        author:users(*)
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  async getReportBySlug(slug: string): Promise<Report> {
    const { data, error } = await supabase
      .from('reports')
      .select(`
        *,
        category:categories(*),
        author:users(*)
      `)
      .eq('slug', slug)
      .single();

    if (error) throw error;
    return data;
  }

  async createReport(reportData: CreateReportDTO): Promise<Report> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('reports')
      .insert({
        ...reportData,
        author_id: user.id,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async updateReport(id: string, updates: UpdateReportDTO): Promise<Report> {
    const { data, error } = await supabase
      .from('reports')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async deleteReport(id: string): Promise<void> {
    const { error } = await supabase
      .from('reports')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }

  async publishReport(id: string): Promise<Report> {
    const { data, error } = await supabase
      .from('reports')
      .update({
        status: 'published',
        published_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }
}

export const reportService = new ReportService();
import { supabase } from './client';
import { MediaFile, UploadMediaDTO, MediaFilters } from '../../types/media.types';

export class MediaService {
  private bucketName = 'media';

  async uploadFile(uploadData: UploadMediaDTO): Promise<MediaFile> {
    const { file, folder = 'uploads' } = uploadData;
    const timestamp = Date.now();
    const fileName = `${timestamp}-${file.name}`;
    const filePath = `${folder}/${fileName}`;

    // Upload file to Supabase Storage
    const { error: uploadError } = await supabase.storage
      .from(this.bucketName)
      .upload(filePath, file);

    if (uploadError) throw uploadError;

    // Get public URL
    const { data: { publicUrl } } = supabase.storage
      .from(this.bucketName)
      .getPublicUrl(filePath);

    // Get current user
    const { data: { user } } = await supabase.auth.getUser();

    // Create media record
    const mediaFile: MediaFile = {
      id: crypto.randomUUID(),
      name: file.name,
      path: filePath,
      url: publicUrl,
      type: file.type,
      size: file.size,
      uploaded_by: user?.id || '',
      created_at: new Date().toISOString(),
    };

    return mediaFile;
  }

  async getFiles(filters?: MediaFilters): Promise<MediaFile[]> {
    const { data, error } = await supabase.storage
      .from(this.bucketName)
      .list('uploads', {
        limit: 100,
        sortBy: { column: 'created_at', order: 'desc' },
      });

    if (error) throw error;

    const files: MediaFile[] = (data || []).map(file => {
      const { data: { publicUrl } } = supabase.storage
        .from(this.bucketName)
        .getPublicUrl(`uploads/${file.name}`);

      return {
        id: file.id,
        name: file.name,
        path: `uploads/${file.name}`,
        url: publicUrl,
        type: file.metadata?.mimetype || '',
        size: file.metadata?.size || 0,
        uploaded_by: '',
        created_at: file.created_at,
      };
    });

    // Apply filters
    let filteredFiles = files;
    if (filters?.search) {
      filteredFiles = filteredFiles.filter(f => 
        f.name.toLowerCase().includes(filters.search!.toLowerCase())
      );
    }
    if (filters?.type) {
      filteredFiles = filteredFiles.filter(f => 
        f.type.startsWith(filters.type!)
      );
    }

    return filteredFiles;
  }

  async deleteFile(path: string): Promise<void> {
    const { error } = await supabase.storage
      .from(this.bucketName)
      .remove([path]);

    if (error) throw error;
  }
}

export const mediaService = new MediaService();
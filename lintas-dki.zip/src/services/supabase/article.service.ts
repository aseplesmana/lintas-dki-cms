import { supabase } from './client';
import { Article, CreateArticleDTO, UpdateArticleDTO, ArticleFilters } from '../../types/article.types';
import { PaginationParams, PaginatedResponse } from '../../types/common.types';

export class ArticleService {
  async getArticles(
    filters?: ArticleFilters,
    pagination?: PaginationParams
  ): Promise<PaginatedResponse<Article>> {
    let query = supabase
      .from('articles')
      .select(`
        *,
        category:categories(*),
        author:users(*),
        tags:article_tags(tag:tags(*))
      `, { count: 'exact' });

    // Apply filters
    if (filters?.search) {
      query = query.or(`title.ilike.%${filters.search}%,content.ilike.%${filters.search}%`);
    }
    if (filters?.category) {
      query = query.eq('category_id', filters.category);
    }
    if (filters?.status) {
      query = query.eq('status', filters.status);
    }
    if (filters?.author) {
      query = query.eq('author_id', filters.author);
    }
    if (filters?.is_featured !== undefined) {
      query = query.eq('is_featured', filters.is_featured);
    }
    if (filters?.startDate) {
      query = query.gte('published_at', filters.startDate);
    }
    if (filters?.endDate) {
      query = query.lte('published_at', filters.endDate);
    }

    // Apply pagination
    const page = pagination?.page || 1;
    const limit = pagination?.limit || 10;
    const from = (page - 1) * limit;
    const to = from + limit - 1;

    query = query.range(from, to).order('created_at', { ascending: false });

    const { data, error, count } = await query;

    if (error) throw error;

    return {
      data: data || [],
      total: count || 0,
      page,
      limit,
      totalPages: Math.ceil((count || 0) / limit),
    };
  }

  async getArticleById(id: string): Promise<Article> {
    const { data, error } = await supabase
      .from('articles')
      .select(`
        *,
        category:categories(*),
        author:users(*),
        tags:article_tags(tag:tags(*))
      `)
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  async getArticleBySlug(slug: string): Promise<Article> {
    const { data, error } = await supabase
      .from('articles')
      .select(`
        *,
        category:categories(*),
        author:users(*),
        tags:article_tags(tag:tags(*))
      `)
      .eq('slug', slug)
      .single();

    if (error) throw error;
    return data;
  }

  async createArticle(articleData: CreateArticleDTO): Promise<Article> {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { tags, ...articleFields } = articleData;

    const { data, error } = await supabase
      .from('articles')
      .insert({
        ...articleFields,
        author_id: user.id,
      })
      .select()
      .single();

    if (error) throw error;

    // Add tags if provided
    if (tags && tags.length > 0) {
      await this.updateArticleTags(data.id, tags);
    }

    return data;
  }

  async updateArticle(id: string, updates: UpdateArticleDTO): Promise<Article> {
    const { tags, ...articleFields } = updates;

    const { data, error } = await supabase
      .from('articles')
      .update(articleFields)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;

    // Update tags if provided
    if (tags) {
      await this.updateArticleTags(id, tags);
    }

    return data;
  }

  async deleteArticle(id: string): Promise<void> {
    const { error } = await supabase
      .from('articles')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }

  async publishArticle(id: string): Promise<Article> {
    const { data, error } = await supabase
      .from('articles')
      .update({
        status: 'published',
        published_at: new Date().toISOString(),
      })
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async incrementViews(id: string): Promise<void> {
    const { error } = await supabase.rpc('increment_article_views', {
      article_id: id,
    });

    if (error) throw error;
  }

  private async updateArticleTags(articleId: string, tagNames: string[]): Promise<void> {
    // Remove existing tags
    await supabase.from('article_tags').delete().eq('article_id', articleId);

    // Get or create tags
    const tagIds: string[] = [];
    for (const tagName of tagNames) {
      const slug = tagName.toLowerCase().replace(/\s+/g, '-');
      
      // Try to get existing tag
      let { data: tag } = await supabase
        .from('tags')
        .select('id')
        .eq('slug', slug)
        .single();

      // Create if doesn't exist
      if (!tag) {
        const { data: newTag } = await supabase
          .from('tags')
          .insert({ name: tagName, slug })
          .select('id')
          .single();
        tag = newTag;
      }

      if (tag) tagIds.push(tag.id);
    }

    // Insert new tag associations
    if (tagIds.length > 0) {
      await supabase
        .from('article_tags')
        .insert(tagIds.map(tagId => ({ article_id: articleId, tag_id: tagId })));
    }
  }
}

export const articleService = new ArticleService();
import { supabase } from './client';
import {
  GenerateArticleParams,
  GenerateArticleResponse,
  SummarizeParams,
  SummarizeResponse,
  ClassifyParams,
  ClassifyResponse,
  GenerateReportParams,
  GenerateReportResponse,
  ChatParams,
  ChatResponse,
} from '../../types/ai.types';

export class AIService {
  async generateArticle(params: GenerateArticleParams): Promise<GenerateArticleResponse> {
    const { data, error } = await supabase.functions.invoke('ai-generate-article', {
      body: params,
    });

    if (error) throw error;
    return data;
  }

  async summarizeContent(params: SummarizeParams): Promise<SummarizeResponse> {
    const { data, error } = await supabase.functions.invoke('ai-summarize', {
      body: params,
    });

    if (error) throw error;
    return data;
  }

  async classifyContent(params: ClassifyParams): Promise<ClassifyResponse> {
    const { data, error } = await supabase.functions.invoke('ai-classify', {
      body: params,
    });

    if (error) throw error;
    return data;
  }

  async generateReport(params: GenerateReportParams): Promise<GenerateReportResponse> {
    const { data, error } = await supabase.functions.invoke('ai-generate-report', {
      body: params,
    });

    if (error) throw error;
    return data;
  }

  async chat(params: ChatParams): Promise<ChatResponse> {
    const { data, error } = await supabase.functions.invoke('ai-chat', {
      body: params,
    });

    if (error) throw error;
    return data;
  }

  async getGenerationHistory(userId?: string) {
    let query = supabase
      .from('ai_generations')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(50);

    if (userId) {
      query = query.eq('user_id', userId);
    }

    const { data, error } = await query;

    if (error) throw error;
    return data || [];
  }
}

export const aiService = new AIService();
import { supabase } from './client';
import { Tag, CreateTagDTO, UpdateTagDTO, TagFilters } from '../../types/tag.types';

export class TagService {
  async getTags(filters?: TagFilters): Promise<Tag[]> {
    let query = supabase
      .from('tags')
      .select('*');

    if (filters?.search) {
      query = query.or(`name.ilike.%${filters.search}%,slug.ilike.%${filters.search}%`);
    }

    query = query.order('name', { ascending: true });

    const { data, error } = await query;

    if (error) throw error;
    return data || [];
  }

  async getTagById(id: string): Promise<Tag> {
    const { data, error } = await supabase
      .from('tags')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw error;
    return data;
  }

  async createTag(tagData: CreateTagDTO): Promise<Tag> {
    const { data, error } = await supabase
      .from('tags')
      .insert(tagData)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async updateTag(id: string, updates: UpdateTagDTO): Promise<Tag> {
    const { data, error } = await supabase
      .from('tags')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  }

  async deleteTag(id: string): Promise<void> {
    const { error } = await supabase
      .from('tags')
      .delete()
      .eq('id', id);

    if (error) throw error;
  }
}

export const tagService = new TagService();
import React from 'react';
import { Edit, Trash2 } from 'lucide-react';
import { Tag } from '../../types/tag.types';
import TagBadge from './TagBadge';
import Spinner from '../common/Spinner';

interface TagListProps {
  tags: Tag[];
  loading?: boolean;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
}

const TagList: React.FC<TagListProps> = ({ tags, loading = false, onEdit, onDelete }) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Spinner size="lg" />
      </div>
    );
  }

  if (tags.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
        <p className="text-slate-600">Belum ada tag. Buat tag pertama Anda!</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
      <table className="w-full">
        <thead className="bg-slate-50 border-b border-slate-200">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-bold uppercase text-slate-500">
              Tag
            </th>
            <th className="px-6 py-3 text-left text-xs font-bold uppercase text-slate-500">
              Slug
            </th>
            <th className="px-6 py-3 text-left text-xs font-bold uppercase text-slate-500">
              Artikel
            </th>
            <th className="px-6 py-3 text-right text-xs font-bold uppercase text-slate-500">
              Aksi
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-200">
          {tags.map((tag) => (
            <tr key={tag.id} className="hover:bg-slate-50 transition">
              <td className="px-6 py-4">
                <TagBadge tag={tag} size="md" />
              </td>
              <td className="px-6 py-4 text-sm text-slate-600">{tag.slug}</td>
              <td className="px-6 py-4 text-sm text-slate-600">
                {tag.article_count || 0} artikel
              </td>
              <td className="px-6 py-4 text-right">
                <div className="flex items-center justify-end gap-2">
                  <button
                    onClick={() => onEdit?.(tag.id)}
                    className="p-2 hover:bg-slate-200 rounded-lg transition"
                    title="Edit"
                  >
                    <Edit size={16} />
                  </button>
                  <button
                    onClick={() => onDelete?.(tag.id)}
                    className="p-2 hover:bg-red-100 text-red-600 rounded-lg transition"
                    title="Hapus"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TagList;
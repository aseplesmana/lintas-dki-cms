import React from 'react';
import { Tag } from '../../types/tag.types';
import { X } from 'lucide-react';

interface TagBadgeProps {
  tag: Tag;
  onRemove?: () => void;
  size?: 'sm' | 'md' | 'lg';
}

const TagBadge: React.FC<TagBadgeProps> = ({ tag, onRemove, size = 'md' }) => {
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-3 py-1 text-sm',
    lg: 'px-4 py-2 text-base',
  };

  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full font-bold text-white ${sizeClasses[size]}`}
      style={{ backgroundColor: tag.color || '#3B82F6' }}
    >
      {tag.name}
      {onRemove && (
        <button
          onClick={onRemove}
          className="hover:bg-white/20 rounded-full p-0.5 transition"
        >
          <X size={size === 'sm' ? 12 : size === 'md' ? 14 : 16} />
        </button>
      )}
    </span>
  );
};

export default TagBadge;
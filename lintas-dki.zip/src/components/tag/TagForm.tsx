import React, { useState } from 'react';
import { Save, Tag as TagIcon } from 'lucide-react';
import { CreateTagDTO } from '../../types/tag.types';
import Input from '../common/Input';
import Button from '../common/Button';

interface TagFormProps {
  initialData?: Partial<CreateTagDTO>;
  onSubmit: (data: CreateTagDTO) => void;
  onCancel: () => void;
  loading?: boolean;
}

const TagForm: React.FC<TagFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  loading = false,
}) => {
  const [formData, setFormData] = useState<CreateTagDTO>({
    name: initialData?.name || '',
    slug: initialData?.slug || '',
    color: initialData?.color || '#3B82F6',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (field: keyof CreateTagDTO, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }

    // Auto-generate slug from name
    if (field === 'name') {
      const slug = value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      setFormData((prev) => ({ ...prev, slug }));
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) newErrors.name = 'Nama tag wajib diisi';
    if (!formData.slug.trim()) newErrors.slug = 'Slug wajib diisi';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(formData);
    }
  };

  const colorPresets = [
    '#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6',
    '#EC4899', '#06B6D4', '#84CC16', '#F97316', '#6366F1',
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="Nama Tag *"
        value={formData.name}
        onChange={(e) => handleChange('name', e.target.value)}
        error={errors.name}
        placeholder="Masukkan nama tag"
        icon={<TagIcon size={18} />}
      />

      <Input
        label="Slug *"
        value={formData.slug}
        onChange={(e) => handleChange('slug', e.target.value)}
        error={errors.slug}
        placeholder="tag-slug"
      />

      <div>
        <label className="block text-xs font-bold uppercase text-slate-500 mb-2">
          Warna Tag
        </label>
        <div className="flex items-center gap-3">
          <input
            type="color"
            value={formData.color}
            onChange={(e) => handleChange('color', e.target.value)}
            className="w-16 h-10 rounded border border-slate-300 cursor-pointer"
          />
          <div className="flex flex-wrap gap-2">
            {colorPresets.map((color) => (
              <button
                key={color}
                type="button"
                onClick={() => handleChange('color', color)}
                className="w-8 h-8 rounded border-2 border-slate-200 hover:scale-110 transition"
                style={{ backgroundColor: color }}
              />
            ))}
          </div>
        </div>
        <div className="mt-2 flex items-center gap-2">
          <span className="text-sm text-slate-600">Preview:</span>
          <span
            className="px-3 py-1 rounded-full text-xs font-bold text-white"
            style={{ backgroundColor: formData.color }}
          >
            {formData.name || 'Tag Name'}
          </span>
        </div>
      </div>

      <div className="flex justify-end gap-3 pt-6 border-t border-slate-200">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Batal
        </Button>
        <Button type="submit" variant="primary" loading={loading} icon={<Save size={18} />}>
          Simpan Tag
        </Button>
      </div>
    </form>
  );
};

export default TagForm;
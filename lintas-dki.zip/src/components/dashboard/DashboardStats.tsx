import React from 'react';
import { FileText, Users, Eye, ArrowUp, ArrowDown } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  change: number;
  icon: React.ReactNode;
  color: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, change, icon, color }) => {
  const isPositive = change >= 0;

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 hover:shadow-md transition">
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-xs font-bold uppercase text-slate-500 tracking-wider">{title}</p>
          <h3 className="text-3xl font-bold text-slate-900 mt-2">{value}</h3>
        </div>
        <div className={`w-12 h-12 rounded-lg ${color} flex items-center justify-center`}>
          {icon}
        </div>
      </div>
      <div className="flex items-center gap-2">
        <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs font-bold ${
          isPositive ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
        }`}>
          {isPositive ? <ArrowUp size={12} /> : <ArrowDown size={12} />}
          {Math.abs(change)}%
        </div>
        <span className="text-xs text-slate-500">vs bulan lalu</span>
      </div>
    </div>
  );
};

interface DashboardStatsProps {
  stats: {
    totalArticles: number;
    totalReports: number;
    totalViews: number;
    activeUsers: number;
    articlesChange: number;
    reportsChange: number;
    viewsChange: number;
    usersChange: number;
  };
}

const DashboardStats: React.FC<DashboardStatsProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard
        title="Total Artikel"
        value={stats.totalArticles.toLocaleString()}
        change={stats.articlesChange}
        icon={<FileText size={24} className="text-blue-600" />}
        color="bg-blue-100"
      />
      <StatCard
        title="Total Laporan"
        value={stats.totalReports.toLocaleString()}
        change={stats.reportsChange}
        icon={<FileText size={24} className="text-purple-600" />}
        color="bg-purple-100"
      />
      <StatCard
        title="Total Views"
        value={stats.totalViews.toLocaleString()}
        change={stats.viewsChange}
        icon={<Eye size={24} className="text-green-600" />}
        color="bg-green-100"
      />
      <StatCard
        title="Pengguna Aktif"
        value={stats.activeUsers.toLocaleString()}
        change={stats.usersChange}
        icon={<Users size={24} className="text-orange-600" />}
        color="bg-orange-100"
      />
    </div>
  );
};

export default DashboardStats;
import React from 'react';
import { BarChart3 } from 'lucide-react';

interface ContentChartProps {
  data: {
    labels: string[];
    articles: number[];
    reports: number[];
  };
}

const ContentChart: React.FC<ContentChartProps> = ({ data }) => {
  const maxValue = Math.max(...data.articles, ...data.reports);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <BarChart3 size={20} className="text-blue-600" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900">Konten Bulanan</h3>
            <p className="text-xs text-slate-500">Artikel & Laporan</p>
          </div>
        </div>
        <div className="flex gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span className="text-slate-600">Artikel</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-purple-500 rounded"></div>
            <span className="text-slate-600">Laporan</span>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        {data.labels.map((label, idx) => (
          <div key={idx} className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="font-medium text-slate-700">{label}</span>
              <span className="text-slate-500">{data.articles[idx] + data.reports[idx]} total</span>
            </div>
            <div className="flex gap-1 h-8">
              <div
                className="bg-blue-500 rounded-l transition-all duration-500 hover:bg-blue-600"
                style={{ width: `${(data.articles[idx] / maxValue) * 100}%` }}
                title={`${data.articles[idx]} artikel`}
              ></div>
              <div
                className="bg-purple-500 rounded-r transition-all duration-500 hover:bg-purple-600"
                style={{ width: `${(data.reports[idx] / maxValue) * 100}%` }}
                title={`${data.reports[idx]} laporan`}
              ></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ContentChart;
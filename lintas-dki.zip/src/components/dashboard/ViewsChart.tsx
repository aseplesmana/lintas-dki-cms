import React from 'react';
import { TrendingUp } from 'lucide-react';

interface ViewsChartProps {
  data: {
    labels: string[];
    views: number[];
  };
}

const ViewsChart: React.FC<ViewsChartProps> = ({ data }) => {
  const maxValue = Math.max(...data.views);
  const minValue = Math.min(...data.views);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
            <TrendingUp size={20} className="text-green-600" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900">Tren Views</h3>
            <p className="text-xs text-slate-500">7 Hari Terakhir</p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-2xl font-bold text-slate-900">{data.views[data.views.length - 1].toLocaleString()}</p>
          <p className="text-xs text-slate-500">Hari ini</p>
        </div>
      </div>

      <div className="relative h-48">
        <div className="absolute inset-0 flex items-end justify-between gap-2">
          {data.views.map((value, idx) => {
            const height = ((value - minValue) / (maxValue - minValue)) * 100;
            const isToday = idx === data.views.length - 1;

            return (
              <div key={idx} className="flex-1 flex flex-col items-center gap-2 group">
                <div className="relative w-full">
                  <div
                    className={`w-full rounded-t-lg transition-all duration-500 ${
                      isToday ? 'bg-green-500' : 'bg-green-200 group-hover:bg-green-400'
                    }`}
                    style={{ height: `${Math.max(height, 10)}%` }}
                  >
                    <div className="absolute -top-8 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                      {value.toLocaleString()} views
                    </div>
                  </div>
                </div>
                <span className="text-xs text-slate-500 font-medium">{data.labels[idx]}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ViewsChart;
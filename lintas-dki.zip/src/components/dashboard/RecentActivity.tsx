import React from 'react';
import { Clock, FileText, User, Eye } from 'lucide-react';

interface Activity {
  id: string;
  type: 'article' | 'report' | 'user' | 'view';
  title: string;
  description: string;
  timestamp: string;
  user?: string;
}

interface RecentActivityProps {
  activities: Activity[];
}

const RecentActivity: React.FC<RecentActivityProps> = ({ activities }) => {
  const getIcon = (type: Activity['type']) => {
    switch (type) {
      case 'article':
        return <FileText size={16} className="text-blue-600" />;
      case 'report':
        return <FileText size={16} className="text-purple-600" />;
      case 'user':
        return <User size={16} className="text-green-600" />;
      case 'view':
        return <Eye size={16} className="text-orange-600" />;
    }
  };

  const getColor = (type: Activity['type']) => {
    switch (type) {
      case 'article':
        return 'bg-blue-100';
      case 'report':
        return 'bg-purple-100';
      case 'user':
        return 'bg-green-100';
      case 'view':
        return 'bg-orange-100';
    }
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
      <div className="flex items-center gap-2 mb-4">
        <Clock size={20} className="text-slate-600" />
        <h3 className="font-bold text-slate-900">Aktivitas Terkini</h3>
      </div>

      <div className="space-y-4">
        {activities.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <p className="text-sm">Belum ada aktivitas</p>
          </div>
        ) : (
          activities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-3 pb-4 border-b border-slate-100 last:border-0 last:pb-0">
              <div className={`w-8 h-8 rounded-lg ${getColor(activity.type)} flex items-center justify-center shrink-0`}>
                {getIcon(activity.type)}
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-slate-900 text-sm truncate">{activity.title}</h4>
                <p className="text-xs text-slate-500 mt-0.5">{activity.description}</p>
                <div className="flex items-center gap-2 mt-1">
                  {activity.user && (
                    <span className="text-xs text-slate-400">oleh {activity.user}</span>
                  )}
                  <span className="text-xs text-slate-400">{activity.timestamp}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      <button className="w-full mt-4 py-2 text-sm font-bold text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition">
        Lihat Semua Aktivitas
      </button>
    </div>
  );
};

export default RecentActivity;
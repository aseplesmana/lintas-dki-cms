import React from 'react';
import { PlusCircle, FileText, Sparkles, Eye } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const QuickActions: React.FC = () => {
  const navigate = useNavigate();

  const actions = [
    {
      icon: <PlusCircle size={24} />,
      title: 'Artikel Baru',
      description: 'Tulis artikel baru',
      color: 'bg-blue-500',
      hoverColor: 'hover:bg-blue-600',
      onClick: () => navigate('/admin/articles/new'),
    },
    {
      icon: <FileText size={24} />,
      title: 'Laporan Baru',
      description: 'Buat laporan monitoring',
      color: 'bg-purple-500',
      hoverColor: 'hover:bg-purple-600',
      onClick: () => navigate('/admin/reports/new'),
    },
    {
      icon: <Sparkles size={24} />,
      title: 'AI Tools',
      description: 'Generate dengan AI',
      color: 'bg-gradient-to-r from-pink-500 to-purple-500',
      hoverColor: 'hover:from-pink-600 hover:to-purple-600',
      onClick: () => navigate('/admin/ai-tools'),
    },
    {
      icon: <Eye size={24} />,
      title: 'Monitoring',
      description: 'Pantau media sosial',
      color: 'bg-green-500',
      hoverColor: 'hover:bg-green-600',
      onClick: () => navigate('/admin/monitoring'),
    },
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
      <h3 className="font-bold text-slate-900 mb-4">Quick Actions</h3>
      <div className="grid grid-cols-2 gap-3">
        {actions.map((action, idx) => (
          <button
            key={idx}
            onClick={action.onClick}
            className={`${action.color} ${action.hoverColor} text-white p-4 rounded-xl transition-all duration-200 transform hover:scale-105 hover:shadow-lg group`}
          >
            <div className="flex flex-col items-start gap-2">
              <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center group-hover:bg-white/30 transition">
                {action.icon}
              </div>
              <div className="text-left">
                <h4 className="font-bold text-sm">{action.title}</h4>
                <p className="text-xs opacity-90">{action.description}</p>
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickActions;
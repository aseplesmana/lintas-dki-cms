import React, { useState } from 'react';
import { MessageSquare, Send } from 'lucide-react';
import Button from '../common/Button';
import Textarea from '../common/Textarea';
import Input from '../common/Input';

interface Comment {
  id: string;
  author: string;
  content: string;
  created_at: string;
}

interface CommentSectionProps {
  articleId: string;
}

const CommentSection: React.FC<CommentSectionProps> = () => {
  const [comments] = useState<Comment[]>([
    {
      id: '1',
      author: 'John Doe',
      content: 'Artikel yang sangat informatif! Terima kasih atas informasinya.',
      created_at: '2024-01-15T10:30:00Z',
    },
    {
      id: '2',
      author: 'Jane Smith',
      content: 'Saya setuju dengan poin-poin yang disampaikan. Sangat relevan dengan situasi saat ini.',
      created_at: '2024-01-15T11:45:00Z',
    },
  ]);

  const [newComment, setNewComment] = useState({ name: '', content: '' });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.name || !newComment.content) return;

    setSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setSubmitting(false);
    setNewComment({ name: '', content: '' });
    alert('Komentar berhasil dikirim!');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <MessageSquare size={24} className="text-slate-600" />
        <h2 className="text-2xl font-bold text-slate-900">
          Komentar ({comments.length})
        </h2>
      </div>

      {/* Comment Form */}
      <form onSubmit={handleSubmit} className="bg-slate-50 rounded-xl p-6 space-y-4">
        <h3 className="font-bold text-slate-900">Tinggalkan Komentar</h3>
        <Input
          label="Nama"
          value={newComment.name}
          onChange={(e) => setNewComment({ ...newComment, name: e.target.value })}
          placeholder="Nama Anda"
          required
        />
        <Textarea
          label="Komentar"
          value={newComment.content}
          onChange={(e) => setNewComment({ ...newComment, content: e.target.value })}
          placeholder="Tulis komentar Anda..."
          rows={4}
          required
        />
        <Button
          type="submit"
          variant="primary"
          icon={<Send size={18} />}
          loading={submitting}
        >
          Kirim Komentar
        </Button>
      </form>

      {/* Comments List */}
      <div className="space-y-4">
        {comments.map((comment) => (
          <div key={comment.id} className="bg-white rounded-xl border border-slate-200 p-6">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-bold text-slate-900">{comment.author}</h4>
                <p className="text-xs text-slate-500">
                  {new Date(comment.created_at).toLocaleDateString('id-ID', {
                    day: 'numeric',
                    month: 'long',
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </p>
              </div>
            </div>
            <p className="text-slate-700">{comment.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommentSection;
import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Eye } from 'lucide-react';
import { Article } from '../../types/article.types';
import { formatDate } from '../../utils/date.utils';

interface RelatedArticlesProps {
  articles: Article[];
  currentArticleId: string;
}

const RelatedArticles: React.FC<RelatedArticlesProps> = ({ articles, currentArticleId }) => {
  const relatedArticles = articles
    .filter((article) => article.id !== currentArticleId)
    .slice(0, 3);

  if (relatedArticles.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-slate-900">Artikel Terkait</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {relatedArticles.map((article) => (
          <Link
            key={article.id}
            to={`/article/${article.slug}`}
            className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition"
          >
            {article.featured_image && (
              <div className="aspect-video bg-slate-100 overflow-hidden">
                <img
                  src={article.featured_image}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                />
              </div>
            )}
            <div className="p-4">
              <h3 className="font-bold text-slate-900 line-clamp-2 group-hover:text-blue-600 transition mb-2">
                {article.title}
              </h3>
              <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                {article.excerpt}
              </p>
              <div className="flex items-center gap-4 text-xs text-slate-500">
                <div className="flex items-center gap-1">
                  <Clock size={14} />
                  <span>{formatDate(article.published_at || article.created_at)}</span>
                </div>
                {article.views !== undefined && (
                  <div className="flex items-center gap-1">
                    <Eye size={14} />
                    <span>{article.views}</span>
                  </div>
                )}
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
};

export default RelatedArticles;
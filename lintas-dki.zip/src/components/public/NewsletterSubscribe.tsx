import React, { useState } from 'react';
import { Mail, CheckCircle } from 'lucide-react';
import Button from '../common/Button';
import Input from '../common/Input';

const NewsletterSubscribe: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setLoading(false);
    setSubscribed(true);
    setEmail('');

    // Reset after 3 seconds
    setTimeout(() => setSubscribed(false), 3000);
  };

  return (
    <div className="bg-gradient-to-r from-blue-600 to-blue-700 rounded-xl p-8 text-white">
      <div className="max-w-2xl mx-auto text-center">
        <Mail size={48} className="mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2">Berlangganan Newsletter</h2>
        <p className="text-blue-100 mb-6">
          Dapatkan berita terbaru langsung ke email Anda setiap hari
        </p>

        {subscribed ? (
          <div className="flex items-center justify-center gap-2 text-green-300">
            <CheckCircle size={24} />
            <span className="font-medium">Terima kasih! Anda telah berlangganan.</span>
          </div>
        ) : (
          <form onSubmit={handleSubscribe} className="flex gap-3 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="Email Anda"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1 bg-white/10 border-white/20 text-white placeholder:text-white/60"
            />
            <Button type="submit" variant="primary" loading={loading} className="bg-white text-blue-600 hover:bg-blue-50">
              Berlangganan
            </Button>
          </form>
        )}
      </div>
    </div>
  );
};

export default NewsletterSubscribe;
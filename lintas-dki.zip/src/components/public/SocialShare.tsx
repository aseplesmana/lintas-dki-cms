import React from 'react';
import { Facebook, Twitter, Linkedin, MessageCircle, Link as LinkIcon } from 'lucide-react';

interface SocialShareProps {
  url: string;
  title: string;
  description?: string;
}

const SocialShare: React.FC<SocialShareProps> = ({ url, title }) => {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  const shareLinks = {
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
    twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    whatsapp: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`,
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(url);
    alert('Link berhasil disalin!');
  };

  const handleShare = (platform: keyof typeof shareLinks) => {
    window.open(shareLinks[platform], '_blank', 'width=600,height=400');
  };

  return (
    <div className="flex items-center gap-2">
      <span className="text-sm font-medium text-slate-600">Bagikan:</span>
      <button
        onClick={() => handleShare('facebook')}
        className="p-2 rounded-full hover:bg-blue-100 text-blue-600 transition"
        title="Share on Facebook"
      >
        <Facebook size={20} />
      </button>
      <button
        onClick={() => handleShare('twitter')}
        className="p-2 rounded-full hover:bg-sky-100 text-sky-600 transition"
        title="Share on Twitter"
      >
        <Twitter size={20} />
      </button>
      <button
        onClick={() => handleShare('linkedin')}
        className="p-2 rounded-full hover:bg-blue-100 text-blue-700 transition"
        title="Share on LinkedIn"
      >
        <Linkedin size={20} />
      </button>
      <button
        onClick={() => handleShare('whatsapp')}
        className="p-2 rounded-full hover:bg-green-100 text-green-600 transition"
        title="Share on WhatsApp"
      >
        <MessageCircle size={20} />
      </button>
      <button
        onClick={handleCopyLink}
        className="p-2 rounded-full hover:bg-slate-100 text-slate-600 transition"
        title="Copy Link"
      >
        <LinkIcon size={20} />
      </button>
    </div>
  );
};

export default SocialShare;
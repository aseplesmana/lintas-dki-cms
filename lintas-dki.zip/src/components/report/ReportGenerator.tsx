import React, { useState } from 'react';
import { Calendar, Users, FileText, Download, Copy, Save, Sparkles } from 'lucide-react';
import Button from '../common/Button';
import Input from '../common/Input';
import Textarea from '../common/Textarea';
import { aiService } from '../../services/supabase/ai.service';

const ReportGenerator: React.FC = () => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [piketNames, setPiketNames] = useState('');
  const [generatedReport, setGeneratedReport] = useState('');
  const [loading, setLoading] = useState(false);
  const [useAI, setUseAI] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const piketArray = piketNames.split(',').map(name => name.trim()).filter(Boolean);
      const report = await aiService.generateReport({
        template: 'investigation',
        date,
        articles: [],
        piketNames: piketArray,
      });
      setGeneratedReport(report.content);
    } catch (error) {
      console.error('Error generating report:', error);
      alert('Gagal generate laporan');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedReport);
    alert('Laporan berhasil disalin!');
  };

  const handleDownload = () => {
    const blob = new Blob([generatedReport], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `laporan-${date}.txt`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-8 text-white">
        <div className="flex items-center gap-3 mb-4">
          <Sparkles size={32} />
          <h2 className="text-3xl font-bold">AI Report Generator</h2>
        </div>
        <p className="text-purple-100">
          Generate laporan monitoring media otomatis dengan format TNI/Instansi
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-6">
          <h3 className="font-bold text-slate-900 text-lg">Parameter Laporan</h3>

          <Input
            type="date"
            label="Tanggal Laporan"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            icon={<Calendar size={18} />}
          />

          <Input
            type="text"
            label="Nama Piket"
            placeholder="Nama1, Nama2, Nama3"
            value={piketNames}
            onChange={(e) => setPiketNames(e.target.value)}
            icon={<Users size={18} />}
          />

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={useAI}
              onChange={(e) => setUseAI(e.target.checked)}
              className="rounded border-slate-300"
            />
            <span className="text-sm font-medium text-slate-700">
              Gunakan AI Enhancement (GPT-4)
            </span>
          </label>

          <Button
            variant="primary"
            size="lg"
            className="w-full"
            onClick={handleGenerate}
            loading={loading}
            icon={<FileText size={18} />}
          >
            Generate Laporan
          </Button>
        </div>

        {/* Preview */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-lg">Preview Laporan</h3>
            {generatedReport && (
              <div className="flex gap-2">
                <Button variant="outline" size="sm" icon={<Copy size={16} />} onClick={handleCopy}>
                  Copy
                </Button>
                <Button variant="outline" size="sm" icon={<Download size={16} />} onClick={handleDownload}>
                  Download
                </Button>
                <Button variant="primary" size="sm" icon={<Save size={16} />}>
                  Simpan
                </Button>
              </div>
            )}
          </div>

          <Textarea
            value={generatedReport}
            onChange={(e) => setGeneratedReport(e.target.value)}
            placeholder="Laporan akan muncul di sini..."
            rows={20}
            className="font-mono text-sm"
          />
        </div>
      </div>
    </div>
  );
};

export default ReportGenerator;
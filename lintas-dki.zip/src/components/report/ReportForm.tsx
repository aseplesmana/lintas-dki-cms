import React, { useState } from 'react';
import { Save, Calendar, FileText, AlertCircle } from 'lucide-react';
import { CreateReportDTO } from '../../types/report.types';
import Input from '../common/Input';
import Textarea from '../common/Textarea';
import Button from '../common/Button';

interface ReportFormProps {
  initialData?: Partial<CreateReportDTO>;
  onSubmit: (data: CreateReportDTO) => void;
  onCancel: () => void;
  loading?: boolean;
}

const ReportForm: React.FC<ReportFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  loading = false,
}) => {
  const [formData, setFormData] = useState<CreateReportDTO>({
    title: initialData?.title || '',
    slug: initialData?.slug || '',
    content: initialData?.content || '',
    summary: initialData?.summary || '',
    report_type: initialData?.report_type || 'investigation',
    report_date: initialData?.report_date || new Date().toISOString().split('T')[0],
    priority: initialData?.priority || 'medium',
    template: initialData?.template || 'investigation',
    article_ids: initialData?.article_ids || [],
    issues_count: initialData?.issues_count || 0,
    metadata: initialData?.metadata || {},
    source_urls: initialData?.source_urls || [],
    piket_names: initialData?.piket_names || [],
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (field: keyof CreateReportDTO, value: string | number | string[]) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) newErrors.title = 'Judul wajib diisi';
    if (!formData.content.trim()) newErrors.content = 'Konten wajib diisi';
    if (!formData.report_date) newErrors.report_date = 'Tanggal laporan wajib diisi';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Title & Date */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Input
          label="Judul Laporan *"
          value={formData.title}
          onChange={(e) => handleChange('title', e.target.value)}
          error={errors.title}
          placeholder="Masukkan judul laporan"
          icon={<FileText size={18} />}
        />
        <Input
          type="date"
          label="Tanggal Laporan *"
          value={formData.report_date}
          onChange={(e) => handleChange('report_date', e.target.value)}
          error={errors.report_date}
          icon={<Calendar size={18} />}
        />
      </div>

      {/* Type, Priority, Template */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <label className="block text-xs font-bold uppercase text-slate-500 mb-2">
            Tipe Laporan *
          </label>
          <select
            value={formData.report_type}
            onChange={(e) => handleChange('report_type', e.target.value)}
            className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
          >
            <option value="investigation">Investigasi</option>
            <option value="analysis">Analisis</option>
            <option value="breaking">Breaking News</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase text-slate-500 mb-2">
            Prioritas
          </label>
          <select
            value={formData.priority}
            onChange={(e) => handleChange('priority', e.target.value)}
            className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
          >
            <option value="low">Rendah</option>
            <option value="medium">Sedang</option>
            <option value="high">Tinggi</option>
            <option value="urgent">Urgent</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase text-slate-500 mb-2">
            Template
          </label>
          <select
            value={formData.template}
            onChange={(e) => handleChange('template', e.target.value)}
            className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
          >
            <option value="investigation">Investigasi</option>
            <option value="analysis">Analisis</option>
            <option value="breaking">Breaking News</option>
          </select>
        </div>
      </div>

      {/* Summary */}
      <Textarea
        label="Ringkasan"
        value={formData.summary || ''}
        onChange={(e) => handleChange('summary', e.target.value)}
        placeholder="Ringkasan singkat laporan (opsional)"
        rows={3}
      />

      {/* Content */}
      <Textarea
        label="Konten Laporan *"
        value={formData.content}
        onChange={(e) => handleChange('content', e.target.value)}
        error={errors.content}
        placeholder="Tulis konten laporan di sini..."
        rows={15}
        className="font-mono text-sm"
      />

      {/* Issues Count */}
      <Input
        type="number"
        label="Jumlah Isu Terdeteksi"
        value={formData.issues_count?.toString() || '0'}
        onChange={(e) => handleChange('issues_count', parseInt(e.target.value) || 0)}
        icon={<AlertCircle size={18} />}
        min="0"
      />

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-6 border-t border-slate-200">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Batal
        </Button>
        <Button type="submit" variant="primary" loading={loading} icon={<Save size={18} />}>
          Simpan Laporan
        </Button>
      </div>
    </form>
  );
};

export default ReportForm;
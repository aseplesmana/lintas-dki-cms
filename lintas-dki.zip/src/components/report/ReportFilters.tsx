import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { ReportFilters as Filters } from '../../types/report.types';
import Input from '../common/Input';

interface ReportFiltersProps {
  filters: Filters;
  onFilterChange: (filters: Filters) => void;
  onReset: () => void;
}

const ReportFilters: React.FC<ReportFiltersProps> = ({
  filters,
  onFilterChange,
  onReset,
}) => {
  const handleChange = (key: keyof Filters, value: string) => {
    onFilterChange({ ...filters, [key]: value });
  };

  const hasActiveFilters = Object.values(filters).some((v) => v !== undefined && v !== '');

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter size={20} className="text-slate-600" />
          <h3 className="font-bold text-slate-900">Filter Laporan</h3>
        </div>
        {hasActiveFilters && (
          <button
            onClick={onReset}
            className="text-sm text-red-600 hover:text-red-700 font-medium flex items-center gap-1"
          >
            <X size={16} />
            Reset
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Search */}
        <Input
          type="text"
          placeholder="Cari judul atau konten..."
          value={filters.search || ''}
          onChange={(e) => handleChange('search', e.target.value)}
          icon={<Search size={18} />}
        />

        {/* Report Type */}
        <select
          value={filters.report_type || ''}
          onChange={(e) => handleChange('report_type', e.target.value)}
          className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
        >
          <option value="">Semua Tipe</option>
          <option value="daily">Harian</option>
          <option value="weekly">Mingguan</option>
          <option value="monthly">Bulanan</option>
          <option value="special">Khusus</option>
        </select>

        {/* Priority */}
        <select
          value={filters.priority || ''}
          onChange={(e) => handleChange('priority', e.target.value)}
          className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
        >
          <option value="">Semua Prioritas</option>
          <option value="low">Rendah</option>
          <option value="medium">Sedang</option>
          <option value="high">Tinggi</option>
        </select>

        {/* Template */}
        <select
          value={filters.template || ''}
          onChange={(e) => handleChange('template', e.target.value)}
          className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
        >
          <option value="">Semua Template</option>
          <option value="investigation">Investigasi</option>
          <option value="analysis">Analisis</option>
          <option value="breaking">Breaking News</option>
        </select>
      </div>

      {/* Date Range */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          type="date"
          label="Dari Tanggal"
          value={filters.startDate || ''}
          onChange={(e) => handleChange('startDate', e.target.value)}
        />
        <Input
          type="date"
          label="Sampai Tanggal"
          value={filters.endDate || ''}
          onChange={(e) => handleChange('endDate', e.target.value)}
        />
      </div>
    </div>
  );
};

export default ReportFilters;
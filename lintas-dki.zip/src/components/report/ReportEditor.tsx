import React, { useState } from 'react';
import { Save, Eye, Download, Sparkles } from 'lucide-react';
import Button from '../common/Button';
import Textarea from '../common/Textarea';

interface ReportEditorProps {
  initialContent: string;
  onSave: (content: string) => void;
  onPreview?: () => void;
  onDownload?: () => void;
  onAIEnhance?: (content: string) => Promise<string>;
  loading?: boolean;
}

const ReportEditor: React.FC<ReportEditorProps> = ({
  initialContent,
  onSave,
  onPreview,
  onDownload,
  onAIEnhance,
  loading = false,
}) => {
  const [content, setContent] = useState(initialContent);
  const [enhancing, setEnhancing] = useState(false);

  const handleAIEnhance = async () => {
    if (!onAIEnhance) return;

    setEnhancing(true);
    try {
      const enhanced = await onAIEnhance(content);
      setContent(enhanced);
    } catch (error) {
      console.error('Error enhancing content:', error);
      alert('Gagal enhance konten dengan AI');
    } finally {
      setEnhancing(false);
    }
  };

  const wordCount = content.split(/\s+/).filter(Boolean).length;
  const lineCount = content.split('\n').length;

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex items-center justify-between bg-white p-4 rounded-lg border border-slate-200">
        <div className="flex items-center gap-4">
          <div className="text-sm text-slate-600">
            <span className="font-medium">{wordCount}</span> kata
          </div>
          <div className="text-sm text-slate-600">
            <span className="font-medium">{lineCount}</span> baris
          </div>
        </div>

        <div className="flex gap-2">
          {onAIEnhance && (
            <Button
              variant="outline"
              size="sm"
              icon={<Sparkles size={16} />}
              onClick={handleAIEnhance}
              loading={enhancing}
            >
              AI Enhance
            </Button>
          )}
          {onPreview && (
            <Button variant="outline" size="sm" icon={<Eye size={16} />} onClick={onPreview}>
              Preview
            </Button>
          )}
          {onDownload && (
            <Button variant="outline" size="sm" icon={<Download size={16} />} onClick={onDownload}>
              Download
            </Button>
          )}
          <Button
            variant="primary"
            size="sm"
            icon={<Save size={16} />}
            onClick={() => onSave(content)}
            loading={loading}
          >
            Simpan
          </Button>
        </div>
      </div>

      {/* Editor */}
      <div className="bg-white rounded-lg border border-slate-200 p-6">
        <Textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Tulis atau edit konten laporan di sini..."
          rows={25}
          className="font-mono text-sm"
        />
      </div>

      {/* Tips */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-bold text-blue-900 mb-2">💡 Tips Editor:</h4>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Gunakan format markdown untuk styling text</li>
          <li>• AI Enhance akan memperbaiki grammar dan struktur kalimat</li>
          <li>• Preview untuk melihat hasil akhir sebelum menyimpan</li>
          <li>• Download untuk export laporan dalam format PDF atau TXT</li>
        </ul>
      </div>
    </div>
  );
};

export default ReportEditor;
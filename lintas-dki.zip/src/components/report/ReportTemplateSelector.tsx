import React from 'react';
import { FileText, Search, TrendingUp, CheckCircle } from 'lucide-react';

interface Template {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

interface ReportTemplateSelectorProps {
  selectedTemplate: string;
  onSelect: (templateId: string) => void;
}

const ReportTemplateSelector: React.FC<ReportTemplateSelectorProps> = ({
  selectedTemplate,
  onSelect,
}) => {
  const templates: Template[] = [
    {
      id: 'investigation',
      name: 'Laporan Investigasi',
      description: 'Format lengkap untuk laporan investigasi mendalam dengan analisis detail',
      icon: <Search size={24} />,
      color: 'from-blue-500 to-indigo-600',
    },
    {
      id: 'analysis',
      name: 'Laporan Analisis',
      description: 'Template untuk analisis data dan tren dengan visualisasi',
      icon: <TrendingUp size={24} />,
      color: 'from-purple-500 to-pink-600',
    },
    {
      id: 'breaking',
      name: 'Breaking News Report',
      description: 'Format cepat untuk laporan berita terkini yang urgent',
      icon: <FileText size={24} />,
      color: 'from-red-500 to-orange-600',
    },
  ];

  return (
    <div className="space-y-4">
      <h3 className="font-bold text-slate-900 text-lg">Pilih Template Laporan</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {templates.map((template) => {
          const isSelected = selectedTemplate === template.id;

          return (
            <button
              key={template.id}
              onClick={() => onSelect(template.id)}
              className={`relative p-6 rounded-xl border-2 transition-all duration-200 text-left ${
                isSelected
                  ? 'border-blue-500 bg-blue-50 shadow-lg scale-105'
                  : 'border-slate-200 hover:border-slate-300 hover:shadow-md'
              }`}
            >
              {/* Selected Badge */}
              {isSelected && (
                <div className="absolute top-3 right-3 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                  <CheckCircle size={16} className="text-white" />
                </div>
              )}

              {/* Icon */}
              <div className={`w-12 h-12 rounded-lg bg-gradient-to-br ${template.color} flex items-center justify-center text-white mb-4`}>
                {template.icon}
              </div>

              {/* Content */}
              <h4 className="font-bold text-slate-900 mb-2">{template.name}</h4>
              <p className="text-sm text-slate-600">{template.description}</p>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ReportTemplateSelector;
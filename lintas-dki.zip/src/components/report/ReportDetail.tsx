import React from 'react';
import { Calendar, User, FileText, Download, Edit, Trash2, AlertCircle, Clock } from 'lucide-react';
import { Report } from '../../types/report.types';
import { formatDate } from '../../utils/date.utils';
import Button from '../common/Button';

interface ReportDetailProps {
  report: Report;
  onEdit?: () => void;
  onDelete?: () => void;
  onDownload?: () => void;
}

const ReportDetail: React.FC<ReportDetailProps> = ({
  report,
  onEdit,
  onDelete,
  onDownload,
}) => {
  const typeColors: Record<string, string> = {
    investigation: 'bg-blue-100 text-blue-700',
    analysis: 'bg-purple-100 text-purple-700',
    breaking: 'bg-red-100 text-red-700',
  };

  const priorityColors: Record<string, string> = {
    low: 'bg-slate-100 text-slate-700',
    medium: 'bg-yellow-100 text-yellow-700',
    high: 'bg-red-100 text-red-700',
    urgent: 'bg-red-200 text-red-800',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-8">
        <div className="flex items-start justify-between mb-6">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <span className={`px-3 py-1 rounded-full text-xs font-bold ${typeColors[report.report_type] || 'bg-slate-100 text-slate-700'}`}>
                {report.report_type.toUpperCase()}
              </span>
              {report.priority && (
                <span className={`px-3 py-1 rounded-full text-xs font-bold ${priorityColors[report.priority] || 'bg-slate-100 text-slate-700'}`}>
                  {report.priority.toUpperCase()}
                </span>
              )}
              {report.template && (
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700">
                  {report.template.toUpperCase()}
                </span>
              )}
            </div>
            <h1 className="text-3xl font-bold text-slate-900 mb-4">{report.title}</h1>
            
            {report.summary && (
              <p className="text-lg text-slate-600 mb-4">{report.summary}</p>
            )}

            <div className="flex flex-wrap gap-4 text-sm text-slate-600">
              <div className="flex items-center gap-2">
                <Calendar size={16} />
                <span>Tanggal: {formatDate(report.report_date)}</span>
              </div>
              <div className="flex items-center gap-2">
                <User size={16} />
                <span>Oleh: {report.author?.full_name || 'Unknown'}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock size={16} />
                <span>Dibuat: {formatDate(report.created_at)}</span>
              </div>
              {report.issues_count !== undefined && (
                <div className="flex items-center gap-2">
                  <AlertCircle size={16} className="text-orange-500" />
                  <span>{report.issues_count} isu terdeteksi</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex gap-2">
            {onDownload && (
              <Button variant="outline" icon={<Download size={18} />} onClick={onDownload}>
                Download
              </Button>
            )}
            {onEdit && (
              <Button variant="outline" icon={<Edit size={18} />} onClick={onEdit}>
                Edit
              </Button>
            )}
            {onDelete && (
              <Button variant="outline" icon={<Trash2 size={18} />} onClick={onDelete}>
                Hapus
              </Button>
            )}
          </div>
        </div>

        {/* Articles Count */}
        {report.articles && report.articles.length > 0 && (
          <div className="bg-slate-50 rounded-lg p-4 flex items-center gap-3">
            <FileText size={20} className="text-slate-600" />
            <div>
              <p className="font-medium text-slate-900">
                {report.articles.length} Artikel Terkait
              </p>
              <p className="text-sm text-slate-600">
                Laporan ini menganalisis {report.articles.length} artikel berita
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="bg-white rounded-xl border border-slate-200 p-8">
        <h2 className="text-xl font-bold text-slate-900 mb-4">Konten Laporan</h2>
        <div className="prose prose-slate max-w-none">
          <pre className="whitespace-pre-wrap font-sans text-slate-700 leading-relaxed">
            {report.content}
          </pre>
        </div>
      </div>

      {/* Metadata */}
      {report.metadata && Object.keys(report.metadata).length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-8">
          <h2 className="text-xl font-bold text-slate-900 mb-4">Metadata</h2>
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(report.metadata).map(([key, value]) => (
              <div key={key} className="bg-slate-50 rounded-lg p-4">
                <p className="text-xs font-bold uppercase text-slate-500 mb-1">{key}</p>
                <p className="text-sm text-slate-900">{String(value)}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ReportDetail;
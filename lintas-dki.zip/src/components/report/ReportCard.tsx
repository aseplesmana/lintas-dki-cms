import React from 'react';
import { FileText, Calendar, User, Download, Edit, Trash2, MoreVertical, AlertCircle } from 'lucide-react';
import { Report } from '../../types/report.types';
import { formatDate, getRelativeTime } from '../../utils/date.utils';
import { truncateText } from '../../utils/format.utils';

interface ReportCardProps {
  report: Report;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onDownload?: (id: string) => void;
  onClick?: (id: string) => void;
}

const ReportCard: React.FC<ReportCardProps> = ({ report, onEdit, onDelete, onDownload, onClick }) => {
  const [showMenu, setShowMenu] = React.useState(false);

  const typeColors: Record<string, string> = {
    investigation: 'bg-blue-100 text-blue-700',
    analysis: 'bg-purple-100 text-purple-700',
    breaking: 'bg-red-100 text-red-700',
  };

  const priorityColors: Record<string, string> = {
    low: 'bg-slate-100 text-slate-700',
    medium: 'bg-yellow-100 text-yellow-700',
    high: 'bg-red-100 text-red-700',
    urgent: 'bg-red-200 text-red-800',
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-200 group">
      {/* Header */}
      <div 
        className="p-5 border-b border-slate-100 cursor-pointer hover:bg-slate-50 transition"
        onClick={() => onClick?.(report.id)}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span className={`px-2 py-1 rounded text-xs font-bold ${typeColors[report.report_type] || 'bg-slate-100 text-slate-700'}`}>
                {report.report_type.toUpperCase()}
              </span>
              {report.priority && (
                <span className={`px-2 py-1 rounded text-xs font-bold ${priorityColors[report.priority] || 'bg-slate-100 text-slate-700'}`}>
                  {report.priority.toUpperCase()}
                </span>
              )}
            </div>
            <h3 className="font-bold text-lg text-slate-900 mb-1 hover:text-blue-600 transition">
              {report.title}
            </h3>
            <p className="text-sm text-slate-600">
              {formatDate(report.report_date)}
            </p>
          </div>

          {/* Actions Menu */}
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
              className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-200 transition opacity-0 group-hover:opacity-100"
            >
              <MoreVertical size={16} />
            </button>

            {showMenu && (
              <div className="absolute top-full right-0 mt-2 bg-white rounded-lg shadow-xl border border-slate-200 py-1 min-w-[140px] z-10">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit?.(report.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-slate-100 flex items-center gap-2"
                >
                  <Edit size={14} />
                  Edit
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDownload?.(report.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-slate-100 flex items-center gap-2"
                >
                  <Download size={14} />
                  Download
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete?.(report.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-red-50 text-red-600 flex items-center gap-2"
                >
                  <Trash2 size={14} />
                  Hapus
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Summary */}
        {report.summary && (
          <p className="text-sm text-slate-600 line-clamp-2 mb-3">
            {truncateText(report.summary, 150)}
          </p>
        )}

        {/* Issues Count */}
        {report.issues_count !== undefined && (
          <div className="flex items-center gap-2 text-sm">
            <AlertCircle size={16} className="text-orange-500" />
            <span className="text-slate-600">
              <strong className="text-slate-900">{report.issues_count}</strong> isu terdeteksi
            </span>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-5 py-3 bg-slate-50 flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <User size={14} />
            <span>{report.author?.full_name || 'Unknown'}</span>
          </div>
          <div className="flex items-center gap-1">
            <FileText size={14} />
            <span>{report.articles?.length || 0} artikel</span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Calendar size={14} />
          <span>{getRelativeTime(report.created_at)}</span>
        </div>
      </div>
    </div>
  );
};

export default ReportCard;
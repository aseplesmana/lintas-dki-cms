import React from 'react';
import { Article } from '../../types/article.types';
import ArticleCard from './ArticleCard';
import Spinner from '../common/Spinner';

interface ArticleListProps {
  articles: Article[];
  loading?: boolean;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onClick?: (id: string) => void;
}

const ArticleList: React.FC<ArticleListProps> = ({
  articles,
  loading = false,
  onEdit,
  onDelete,
  onClick,
}) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Spinner size={48} />
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-24 h-24 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-4xl">📝</span>
        </div>
        <h3 className="text-xl font-bold text-slate-900 mb-2">Belum Ada Artikel</h3>
        <p className="text-slate-600">Mulai buat artikel pertama Anda sekarang!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {articles.map((article) => (
        <ArticleCard
          key={article.id}
          article={article}
          onEdit={onEdit}
          onDelete={onDelete}
          onClick={onClick}
        />
      ))}
    </div>
  );
};

export default ArticleList;
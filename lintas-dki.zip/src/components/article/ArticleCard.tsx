import React from 'react';
import { Eye, Calendar, User, Edit, Trash2, MoreVertical } from 'lucide-react';
import { Article } from '../../types/article.types';
import { getRelativeTime } from '../../utils/date.utils';
import { truncateText } from '../../utils/format.utils';

interface ArticleCardProps {
  article: Article;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onClick?: (id: string) => void;
}

const ArticleCard: React.FC<ArticleCardProps> = ({ article, onEdit, onDelete, onClick }) => {
  const [showMenu, setShowMenu] = React.useState(false);

  const statusColors = {
    draft: 'bg-slate-100 text-slate-700',
    published: 'bg-green-100 text-green-700',
    scheduled: 'bg-blue-100 text-blue-700',
    archived: 'bg-red-100 text-red-700',
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-200 group">
      {/* Featured Image */}
      <div 
        className="h-48 bg-slate-200 relative overflow-hidden cursor-pointer"
        onClick={() => onClick?.(article.id)}
      >
        {article.featured_image ? (
          <img
            src={article.featured_image}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-400">
            <span className="text-6xl">📰</span>
          </div>
        )}
        
        {/* Status Badge */}
        <div className="absolute top-3 left-3">
          <span className={`px-3 py-1 rounded-full text-xs font-bold ${statusColors[article.status]}`}>
            {article.status.toUpperCase()}
          </span>
        </div>

        {/* Featured Badge */}
        {article.is_featured && (
          <div className="absolute top-3 right-3">
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-yellow-400 text-yellow-900">
              ⭐ FEATURED
            </span>
          </div>
        )}

        {/* Actions Menu */}
        <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
              className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-lg hover:bg-slate-100 transition"
            >
              <MoreVertical size={16} />
            </button>

            {showMenu && (
              <div className="absolute bottom-full right-0 mb-2 bg-white rounded-lg shadow-xl border border-slate-200 py-1 min-w-[120px] z-10">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit?.(article.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-slate-100 flex items-center gap-2"
                >
                  <Edit size={14} />
                  Edit
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete?.(article.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-red-50 text-red-600 flex items-center gap-2"
                >
                  <Trash2 size={14} />
                  Hapus
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Category */}
        {article.category && (
          <div className="mb-2">
            <span
              className="inline-block px-2 py-1 rounded text-xs font-bold"
              style={{ backgroundColor: `${article.category.color}20`, color: article.category.color }}
            >
              {article.category.icon} {article.category.name}
            </span>
          </div>
        )}

        {/* Title */}
        <h3
          className="font-bold text-lg text-slate-900 mb-2 line-clamp-2 cursor-pointer hover:text-blue-600 transition"
          onClick={() => onClick?.(article.id)}
        >
          {article.title}
        </h3>

        {/* Excerpt */}
        {article.excerpt && (
          <p className="text-sm text-slate-600 mb-4 line-clamp-2">
            {truncateText(article.excerpt, 120)}
          </p>
        )}

        {/* Meta Info */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-4 border-t border-slate-100">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1">
              <User size={14} />
              <span>{article.author?.full_name || 'Unknown'}</span>
            </div>
            <div className="flex items-center gap-1">
              <Eye size={14} />
              <span>{article.views}</span>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Calendar size={14} />
            <span>{getRelativeTime(article.created_at)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ArticleCard;
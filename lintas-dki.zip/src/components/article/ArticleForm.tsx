import React, { useState, useEffect } from 'react';
import { Save, Image as ImageIcon } from 'lucide-react';
import { CreateArticleDTO } from '../../types/article.types';
import { Category } from '../../types/category.types';
import Input from '../common/Input';
import Textarea from '../common/Textarea';
import Button from '../common/Button';
import { generateSlug } from '../../utils/slug.utils';

interface ArticleFormProps {
  initialData?: Partial<CreateArticleDTO>;
  categories: Category[];
  onSubmit: (data: CreateArticleDTO) => void;
  onCancel: () => void;
  loading?: boolean;
}

const ArticleForm: React.FC<ArticleFormProps> = ({
  initialData,
  categories,
  onSubmit,
  onCancel,
  loading = false,
}) => {
  const [formData, setFormData] = useState<CreateArticleDTO>({
    title: initialData?.title || '',
    slug: initialData?.slug || '',
    content: initialData?.content || '',
    excerpt: initialData?.excerpt || '',
    category_id: initialData?.category_id || '',
    featured_image: initialData?.featured_image || '',
    status: initialData?.status || 'draft',
    is_featured: initialData?.is_featured || false,
    tags: initialData?.tags || [],
    meta_title: initialData?.meta_title || '',
    meta_description: initialData?.meta_description || '',
  });

  const [tagInput, setTagInput] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Auto-generate slug from title
  useEffect(() => {
    if (formData.title && !initialData?.slug) {
      setFormData((prev) => ({
        ...prev,
        slug: generateSlug(formData.title),
      }));
    }
  }, [formData.title, initialData?.slug]);

  const handleChange = (field: keyof CreateArticleDTO, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !formData.tags?.includes(tagInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        tags: [...(prev.tags || []), tagInput.trim()],
      }));
      setTagInput('');
    }
  };

  const handleRemoveTag = (tag: string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags?.filter((t) => t !== tag),
    }));
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.title.trim()) newErrors.title = 'Judul wajib diisi';
    if (!formData.slug.trim()) newErrors.slug = 'Slug wajib diisi';
    if (!formData.content.trim()) newErrors.content = 'Konten wajib diisi';
    if (!formData.category_id) newErrors.category_id = 'Kategori wajib dipilih';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Title & Slug */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Input
          label="Judul Artikel *"
          value={formData.title}
          onChange={(e) => handleChange('title', e.target.value)}
          error={errors.title}
          placeholder="Masukkan judul artikel"
        />
        <Input
          label="Slug *"
          value={formData.slug}
          onChange={(e) => handleChange('slug', e.target.value)}
          error={errors.slug}
          placeholder="url-friendly-slug"
        />
      </div>

      {/* Content */}
      <Textarea
        label="Konten *"
        value={formData.content}
        onChange={(e) => handleChange('content', e.target.value)}
        error={errors.content}
        placeholder="Tulis konten artikel di sini..."
        rows={12}
      />

      {/* Excerpt */}
      <Textarea
        label="Ringkasan"
        value={formData.excerpt || ''}
        onChange={(e) => handleChange('excerpt', e.target.value)}
        placeholder="Ringkasan singkat artikel (opsional)"
        rows={3}
      />

      {/* Category & Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-xs font-bold uppercase text-slate-500 mb-2">
            Kategori *
          </label>
          <select
            value={formData.category_id || ''}
            onChange={(e) => handleChange('category_id', e.target.value)}
            className={`w-full p-3 border ${
              errors.category_id ? 'border-red-500' : 'border-slate-300'
            } rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition`}
          >
            <option value="">Pilih Kategori</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.icon} {cat.name}
              </option>
            ))}
          </select>
          {errors.category_id && <p className="mt-1 text-xs text-red-600">{errors.category_id}</p>}
        </div>

        <div>
          <label className="block text-xs font-bold uppercase text-slate-500 mb-2">Status</label>
          <select
            value={formData.status}
            onChange={(e) => handleChange('status', e.target.value)}
            className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="scheduled">Scheduled</option>
          </select>
        </div>
      </div>

      {/* Featured Image */}
      <Input
        label="URL Gambar Utama"
        value={formData.featured_image || ''}
        onChange={(e) => handleChange('featured_image', e.target.value)}
        placeholder="/images/photo1765053657.jpg"
        icon={<ImageIcon size={18} />}
      />

      {/* Tags */}
      <div>
        <label className="block text-xs font-bold uppercase text-slate-500 mb-2">Tags</label>
        <div className="flex gap-2 mb-2">
          <input
            type="text"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), handleAddTag())}
            placeholder="Tambah tag dan tekan Enter"
            className="flex-1 p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
          />
          <Button type="button" onClick={handleAddTag} variant="secondary">
            Tambah
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          {formData.tags?.map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm flex items-center gap-2"
            >
              {tag}
              <button
                type="button"
                onClick={() => handleRemoveTag(tag)}
                className="hover:text-blue-900"
              >
                ×
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Featured Checkbox */}
      <label className="flex items-center gap-2 cursor-pointer">
        <input
          type="checkbox"
          checked={formData.is_featured}
          onChange={(e) => handleChange('is_featured', e.target.checked)}
          className="rounded border-slate-300"
        />
        <span className="text-sm font-medium text-slate-700">Jadikan artikel unggulan</span>
      </label>

      {/* SEO Meta */}
      <div className="border-t border-slate-200 pt-6">
        <h3 className="font-bold text-slate-900 mb-4">SEO Meta</h3>
        <div className="space-y-4">
          <Input
            label="Meta Title"
            value={formData.meta_title || ''}
            onChange={(e) => handleChange('meta_title', e.target.value)}
            placeholder="Judul untuk SEO (opsional)"
          />
          <Textarea
            label="Meta Description"
            value={formData.meta_description || ''}
            onChange={(e) => handleChange('meta_description', e.target.value)}
            placeholder="Deskripsi untuk SEO (opsional)"
            rows={2}
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex justify-end gap-3 pt-6 border-t border-slate-200">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Batal
        </Button>
        <Button type="submit" variant="primary" loading={loading} icon={<Save size={18} />}>
          Simpan Artikel
        </Button>
      </div>
    </form>
  );
};

export default ArticleForm;
import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { ArticleFilters as Filters } from '../../types/article.types';
import { Category } from '../../types/category.types';
import Input from '../common/Input';

interface ArticleFiltersProps {
  filters: Filters;
  categories: Category[];
  onFilterChange: (filters: Filters) => void;
  onReset: () => void;
}

const ArticleFilters: React.FC<ArticleFiltersProps> = ({
  filters,
  categories,
  onFilterChange,
  onReset,
}) => {
  const handleChange = (key: keyof Filters, value: any) => {
    onFilterChange({ ...filters, [key]: value });
  };

  const hasActiveFilters = Object.values(filters).some((v) => v !== undefined && v !== '');

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Filter size={20} className="text-slate-600" />
          <h3 className="font-bold text-slate-900">Filter Artikel</h3>
        </div>
        {hasActiveFilters && (
          <button
            onClick={onReset}
            className="text-sm text-red-600 hover:text-red-700 font-medium flex items-center gap-1"
          >
            <X size={16} />
            Reset
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Search */}
        <Input
          type="text"
          placeholder="Cari judul atau konten..."
          value={filters.search || ''}
          onChange={(e) => handleChange('search', e.target.value)}
          icon={<Search size={18} />}
        />

        {/* Category */}
        <select
          value={filters.category || ''}
          onChange={(e) => handleChange('category', e.target.value)}
          className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
        >
          <option value="">Semua Kategori</option>
          {categories.map((cat) => (
            <option key={cat.id} value={cat.id}>
              {cat.icon} {cat.name}
            </option>
          ))}
        </select>

        {/* Status */}
        <select
          value={filters.status || ''}
          onChange={(e) => handleChange('status', e.target.value as any)}
          className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
        >
          <option value="">Semua Status</option>
          <option value="draft">Draft</option>
          <option value="published">Published</option>
          <option value="scheduled">Scheduled</option>
          <option value="archived">Archived</option>
        </select>

        {/* Featured */}
        <select
          value={filters.is_featured === undefined ? '' : filters.is_featured.toString()}
          onChange={(e) =>
            handleChange('is_featured', e.target.value === '' ? undefined : e.target.value === 'true')
          }
          className="w-full p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 transition"
        >
          <option value="">Semua Artikel</option>
          <option value="true">Featured</option>
          <option value="false">Non-Featured</option>
        </select>
      </div>

      {/* Date Range */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          type="date"
          label="Dari Tanggal"
          value={filters.startDate || ''}
          onChange={(e) => handleChange('startDate', e.target.value)}
        />
        <Input
          type="date"
          label="Sampai Tanggal"
          value={filters.endDate || ''}
          onChange={(e) => handleChange('endDate', e.target.value)}
        />
      </div>
    </div>
  );
};

export default ArticleFilters;
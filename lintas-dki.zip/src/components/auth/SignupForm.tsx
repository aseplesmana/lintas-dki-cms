import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserPlus, Mail, Lock, User, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../common/Button';
import Input from '../common/Input';

const SignupForm: React.FC = () => {
  const navigate = useNavigate();
  const { signUp } = useAuth();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const validateForm = () => {
    if (formData.password.length < 8) {
      setError('Password minimal 8 karakter');
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Password tidak cocok');
      return false;
    }
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!validateForm()) return;

    setLoading(true);
    try {
      await signUp(formData.email, formData.password, formData.fullName);
      navigate('/admin/dashboard');
    } catch (err: any) {
      setError(err.message || 'Pendaftaran gagal. Silakan coba lagi.');
    } finally {
      setLoading(false);
    }
  };

  const passwordStrength = formData.password.length >= 8 ? 'strong' : formData.password.length >= 6 ? 'medium' : 'weak';

  return (
    <div className="w-full max-w-md">
      <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <UserPlus className="text-green-600" size={32} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Buat Akun Baru</h2>
          <p className="text-slate-500 mt-2">Daftar untuk mengakses Lintas DKI CMS</p>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertCircle className="text-red-600 shrink-0 mt-0.5" size={20} />
            <p className="text-sm text-red-800">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <Input
            type="text"
            name="fullName"
            label="Nama Lengkap"
            placeholder="John Doe"
            value={formData.fullName}
            onChange={handleChange}
            icon={<User size={18} />}
            required
          />

          <Input
            type="email"
            name="email"
            label="Email"
            placeholder="nama@email.com"
            value={formData.email}
            onChange={handleChange}
            icon={<Mail size={18} />}
            required
          />

          <div>
            <Input
              type="password"
              name="password"
              label="Password"
              placeholder="Minimal 8 karakter"
              value={formData.password}
              onChange={handleChange}
              icon={<Lock size={18} />}
              required
            />
            {formData.password && (
              <div className="mt-2">
                <div className="flex gap-1 mb-1">
                  <div className={`h-1 flex-1 rounded ${passwordStrength === 'weak' ? 'bg-red-500' : passwordStrength === 'medium' ? 'bg-yellow-500' : 'bg-green-500'}`}></div>
                  <div className={`h-1 flex-1 rounded ${passwordStrength === 'medium' || passwordStrength === 'strong' ? 'bg-yellow-500' : 'bg-slate-200'}`}></div>
                  <div className={`h-1 flex-1 rounded ${passwordStrength === 'strong' ? 'bg-green-500' : 'bg-slate-200'}`}></div>
                </div>
                <p className="text-xs text-slate-500">
                  {passwordStrength === 'weak' && 'Password lemah'}
                  {passwordStrength === 'medium' && 'Password sedang'}
                  {passwordStrength === 'strong' && 'Password kuat'}
                </p>
              </div>
            )}
          </div>

          <Input
            type="password"
            name="confirmPassword"
            label="Konfirmasi Password"
            placeholder="Ulangi password"
            value={formData.confirmPassword}
            onChange={handleChange}
            icon={<Lock size={18} />}
            required
          />

          <div className="flex items-start gap-2">
            <input type="checkbox" required className="mt-1 rounded border-slate-300" />
            <label className="text-sm text-slate-600">
              Saya setuju dengan{' '}
              <a href="/terms" className="text-blue-600 hover:text-blue-700 font-medium">
                Syarat & Ketentuan
              </a>{' '}
              dan{' '}
              <a href="/privacy" className="text-blue-600 hover:text-blue-700 font-medium">
                Kebijakan Privasi
              </a>
            </label>
          </div>

          <Button
            type="submit"
            variant="primary"
            size="lg"
            loading={loading}
            className="w-full"
          >
            Daftar
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-slate-600">
            Sudah punya akun?{' '}
            <a href="/login" className="text-blue-600 hover:text-blue-700 font-bold">
              Masuk di sini
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default SignupForm;
import React, { useState } from 'react';
import { User, Mail, Save, Camera } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../common/Button';
import Input from '../common/Input';

const ProfileForm: React.FC = () => {
  const { user } = useAuth();
  const [formData, setFormData] = useState({
    fullName: user?.full_name || '',
    email: user?.email || '',
    avatarUrl: user?.avatar_url || '',
  });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setSuccess(false);

    try {
      // TODO: Implement profile update via authService
      // await authService.updateProfile(user!.id, {
      //   full_name: formData.fullName,
      //   avatar_url: formData.avatarUrl,
      // });
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (error) {
      console.error('Profile update error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8">
      <h2 className="text-xl font-bold text-slate-900 mb-6">Profil Saya</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Avatar */}
        <div className="flex items-center gap-6">
          <div className="relative">
            <div className="w-24 h-24 rounded-full bg-slate-200 flex items-center justify-center overflow-hidden">
              {formData.avatarUrl ? (
                <img src={formData.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <User size={40} className="text-slate-400" />
              )}
            </div>
            <button
              type="button"
              className="absolute bottom-0 right-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white hover:bg-blue-700 transition"
            >
              <Camera size={16} />
            </button>
          </div>
          <div>
            <h3 className="font-bold text-slate-900">{formData.fullName}</h3>
            <p className="text-sm text-slate-500">{user?.role === 'admin' ? 'Administrator' : 'Editor'}</p>
            <p className="text-xs text-slate-400 mt-1">Bergabung sejak {new Date(user?.created_at || '').toLocaleDateString('id-ID')}</p>
          </div>
        </div>

        {/* Form Fields */}
        <Input
          type="text"
          name="fullName"
          label="Nama Lengkap"
          value={formData.fullName}
          onChange={handleChange}
          icon={<User size={18} />}
          required
        />

        <Input
          type="email"
          name="email"
          label="Email"
          value={formData.email}
          onChange={handleChange}
          icon={<Mail size={18} />}
          disabled
        />

        <Input
          type="url"
          name="avatarUrl"
          label="Avatar URL"
          value={formData.avatarUrl}
          onChange={handleChange}
          placeholder="/images/Avatar.jpg"
        />

        {/* Success Message */}
        {success && (
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-sm text-green-800 font-medium">✓ Profil berhasil diperbarui!</p>
          </div>
        )}

        {/* Submit Button */}
        <div className="flex justify-end gap-3">
          <Button
            type="button"
            variant="ghost"
            onClick={() => window.history.back()}
          >
            Batal
          </Button>
          <Button
            type="submit"
            variant="primary"
            loading={loading}
            icon={<Save size={18} />}
          >
            Simpan Perubahan
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ProfileForm;
import React, { useState } from 'react';
import { Save, Folder } from 'lucide-react';
import { CreateCategoryDTO } from '../../types/category.types';
import Input from '../common/Input';
import Textarea from '../common/Textarea';
import Button from '../common/Button';

interface CategoryFormProps {
  initialData?: Partial<CreateCategoryDTO>;
  onSubmit: (data: CreateCategoryDTO) => void;
  onCancel: () => void;
  loading?: boolean;
}

const CategoryForm: React.FC<CategoryFormProps> = ({
  initialData,
  onSubmit,
  onCancel,
  loading = false,
}) => {
  const [formData, setFormData] = useState<CreateCategoryDTO>({
    name: initialData?.name || '',
    slug: initialData?.slug || '',
    description: initialData?.description || '',
    order: initialData?.order || 0,
    is_active: initialData?.is_active !== false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (field: keyof CreateCategoryDTO, value: string | number | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }

    // Auto-generate slug from name
    if (field === 'name' && typeof value === 'string') {
      const slug = value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      setFormData((prev) => ({ ...prev, slug }));
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) newErrors.name = 'Nama kategori wajib diisi';
    if (!formData.slug.trim()) newErrors.slug = 'Slug wajib diisi';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validate()) {
      onSubmit(formData);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Input
        label="Nama Kategori *"
        value={formData.name}
        onChange={(e) => handleChange('name', e.target.value)}
        error={errors.name}
        placeholder="Masukkan nama kategori"
        icon={<Folder size={18} />}
      />

      <Input
        label="Slug *"
        value={formData.slug}
        onChange={(e) => handleChange('slug', e.target.value)}
        error={errors.slug}
        placeholder="kategori-slug"
      />

      <Textarea
        label="Deskripsi"
        value={formData.description || ''}
        onChange={(e) => handleChange('description', e.target.value)}
        placeholder="Deskripsi kategori (opsional)"
        rows={4}
      />

      <Input
        type="number"
        label="Urutan"
        value={formData.order?.toString() || '0'}
        onChange={(e) => handleChange('order', parseInt(e.target.value) || 0)}
        min="0"
      />

      <div className="flex items-center gap-2">
        <input
          type="checkbox"
          id="is_active"
          checked={formData.is_active}
          onChange={(e) => handleChange('is_active', e.target.checked)}
          className="w-4 h-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500"
        />
        <label htmlFor="is_active" className="text-sm font-medium text-slate-700">
          Aktif
        </label>
      </div>

      <div className="flex justify-end gap-3 pt-6 border-t border-slate-200">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Batal
        </Button>
        <Button type="submit" variant="primary" loading={loading} icon={<Save size={18} />}>
          Simpan Kategori
        </Button>
      </div>
    </form>
  );
};

export default CategoryForm;
import React from 'react';
import { Folder, Edit, Trash2, MoreVertical } from 'lucide-react';
import { Category } from '../../types/category.types';

interface CategoryCardProps {
  category: Category;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onClick?: (id: string) => void;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category, onEdit, onDelete, onClick }) => {
  const [showMenu, setShowMenu] = React.useState(false);

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-200 group">
      <div 
        className="p-5 cursor-pointer hover:bg-slate-50 transition"
        onClick={() => onClick?.(category.id)}
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3 flex-1">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Folder size={24} className="text-blue-600" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-lg text-slate-900 mb-1 truncate">
                {category.name}
              </h3>
              <p className="text-sm text-slate-600 truncate">{category.slug}</p>
            </div>
          </div>

          <div className="relative">
            <button
              onClick={(e) => {
                e.stopPropagation();
                setShowMenu(!showMenu);
              }}
              className="w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-200 transition opacity-0 group-hover:opacity-100"
            >
              <MoreVertical size={16} />
            </button>

            {showMenu && (
              <div className="absolute top-full right-0 mt-2 bg-white rounded-lg shadow-xl border border-slate-200 py-1 min-w-[140px] z-10">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit?.(category.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-slate-100 flex items-center gap-2"
                >
                  <Edit size={14} />
                  Edit
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete?.(category.id);
                    setShowMenu(false);
                  }}
                  className="w-full px-4 py-2 text-left text-sm hover:bg-red-50 text-red-600 flex items-center gap-2"
                >
                  <Trash2 size={14} />
                  Hapus
                </button>
              </div>
            )}
          </div>
        </div>

        {category.description && (
          <p className="text-sm text-slate-600 line-clamp-2 mb-3">
            {category.description}
          </p>
        )}

        <div className="flex items-center justify-between text-xs">
          <span className={`px-2 py-1 rounded-full ${category.is_active ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'}`}>
            {category.is_active ? 'Aktif' : 'Tidak Aktif'}
          </span>
          {category.article_count !== undefined && (
            <span className="text-slate-600">
              {category.article_count} artikel
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoryCard;
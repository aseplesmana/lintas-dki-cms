import React from 'react';
import { Category } from '../../types/category.types';
import CategoryCard from './CategoryCard';
import Spinner from '../common/Spinner';

interface CategoryListProps {
  categories: Category[];
  loading?: boolean;
  onEdit?: (id: string) => void;
  onDelete?: (id: string) => void;
  onClick?: (id: string) => void;
}

const CategoryList: React.FC<CategoryListProps> = ({
  categories,
  loading = false,
  onEdit,
  onDelete,
  onClick,
}) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Spinner size="lg" />
      </div>
    );
  }

  if (categories.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
        <p className="text-slate-600">Belum ada kategori. Buat kategori pertama Anda!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {categories.map((category) => (
        <CategoryCard
          key={category.id}
          category={category}
          onEdit={onEdit}
          onDelete={onDelete}
          onClick={onClick}
        />
      ))}
    </div>
  );
};

export default CategoryList;
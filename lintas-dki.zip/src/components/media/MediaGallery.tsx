import React from 'react';
import { MediaFile } from '../../types/media.types';
import MediaCard from './MediaCard';
import Spinner from '../common/Spinner';

interface MediaGalleryProps {
  media: MediaFile[];
  loading?: boolean;
  onDelete?: (path: string) => void;
  onSelect?: (media: MediaFile) => void;
}

const MediaGallery: React.FC<MediaGalleryProps> = ({
  media,
  loading = false,
  onDelete,
  onSelect,
}) => {
  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Spinner size="lg" />
      </div>
    );
  }

  if (media.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
        <p className="text-slate-600">Belum ada file. Upload file pertama Anda!</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
      {media.map((item) => (
        <MediaCard
          key={item.id}
          media={item}
          onDelete={onDelete}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
};

export default MediaGallery;
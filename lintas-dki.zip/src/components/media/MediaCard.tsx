import React from 'react';
import { FileText, Image, Video, Music, File, Trash2, Copy } from 'lucide-react';
import { MediaFile } from '../../types/media.types';
import { formatDate } from '../../utils/date.utils';

interface MediaCardProps {
  media: MediaFile;
  onDelete?: (path: string) => void;
  onSelect?: (media: MediaFile) => void;
}

const MediaCard: React.FC<MediaCardProps> = ({ media, onDelete, onSelect }) => {
  const getFileIcon = () => {
    if (media.type.startsWith('image/')) return <Image size={24} />;
    if (media.type.startsWith('video/')) return <Video size={24} />;
    if (media.type.startsWith('audio/')) return <Music size={24} />;
    if (media.type.includes('pdf')) return <FileText size={24} />;
    return <File size={24} />;
  };

  const copyUrl = () => {
    navigator.clipboard.writeText(media.url);
    alert('URL berhasil disalin!');
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-200 group">
      <div
        className="aspect-square bg-slate-100 flex items-center justify-center cursor-pointer"
        onClick={() => onSelect?.(media)}
      >
        {media.type.startsWith('image/') ? (
          <img
            src={media.url}
            alt={media.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="text-slate-400">{getFileIcon()}</div>
        )}
      </div>

      <div className="p-4">
        <h3 className="font-medium text-sm text-slate-900 truncate mb-1">
          {media.name}
        </h3>
        <p className="text-xs text-slate-600 mb-2">
          {(media.size / 1024 / 1024).toFixed(2)} MB
        </p>
        <p className="text-xs text-slate-500 mb-3">
          {formatDate(media.created_at)}
        </p>

        <div className="flex gap-2">
          <button
            onClick={copyUrl}
            className="flex-1 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-medium transition flex items-center justify-center gap-1"
          >
            <Copy size={14} />
            Copy URL
          </button>
          {onDelete && (
            <button
              onClick={() => onDelete(media.path)}
              className="px-3 py-2 bg-red-100 hover:bg-red-200 text-red-600 rounded-lg text-xs font-medium transition"
            >
              <Trash2 size={14} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MediaCard;
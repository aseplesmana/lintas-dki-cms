import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Bell, User, LogOut, Settings, Menu } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';

interface HeaderProps {
  onMenuToggle?: () => void;
  showMenuButton?: boolean;
}

const Header: React.FC<HeaderProps> = ({ onMenuToggle, showMenuButton = false }) => {
  const { user, signOut } = useAuth();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);

  const handleSignOut = async () => {
    await signOut();
    setShowUserMenu(false);
  };

  return (
    <header className="bg-white border-b border-slate-200 px-6 py-4 sticky top-0 z-40">
      <div className="flex items-center justify-between">
        {/* Left Section */}
        <div className="flex items-center gap-4">
          {showMenuButton && (
            <button
              onClick={onMenuToggle}
              className="p-2 hover:bg-slate-100 rounded-lg transition lg:hidden"
              aria-label="Toggle menu"
            >
              <Menu size={20} />
            </button>
          )}

          {/* Search Bar */}
          <div className="hidden md:flex items-center gap-2 bg-slate-100 px-4 py-2 rounded-lg w-96">
            <Search size={18} className="text-slate-400" />
            <input
              type="text"
              placeholder="Cari artikel, laporan..."
              className="bg-transparent outline-none text-sm w-full"
            />
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-3">
          {/* Search Icon (Mobile) */}
          <button className="md:hidden p-2 hover:bg-slate-100 rounded-lg transition">
            <Search size={20} />
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="relative p-2 hover:bg-slate-100 rounded-lg transition"
            >
              <Bell size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </button>

            {showNotifications && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setShowNotifications(false)}
                ></div>
                <div className="absolute top-full right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-20">
                  <div className="px-4 py-2 border-b border-slate-200">
                    <h3 className="font-bold text-slate-900">Notifikasi</h3>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    <div className="px-4 py-3 hover:bg-slate-50 cursor-pointer">
                      <p className="text-sm font-medium text-slate-900">Artikel baru dipublikasi</p>
                      <p className="text-xs text-slate-600 mt-1">5 menit yang lalu</p>
                    </div>
                    <div className="px-4 py-3 hover:bg-slate-50 cursor-pointer">
                      <p className="text-sm font-medium text-slate-900">Laporan menunggu review</p>
                      <p className="text-xs text-slate-600 mt-1">1 jam yang lalu</p>
                    </div>
                    <div className="px-4 py-3 hover:bg-slate-50 cursor-pointer">
                      <p className="text-sm font-medium text-slate-900">Komentar baru pada artikel</p>
                      <p className="text-xs text-slate-600 mt-1">2 jam yang lalu</p>
                    </div>
                  </div>
                  <div className="px-4 py-2 border-t border-slate-200">
                    <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                      Lihat Semua
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 px-3 py-2 hover:bg-slate-100 rounded-lg transition"
            >
              <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center">
                <User size={16} />
              </div>
              <span className="text-sm font-medium hidden md:block">{user?.full_name || user?.email}</span>
            </button>

            {showUserMenu && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setShowUserMenu(false)}
                ></div>
                <div className="absolute top-full right-0 mt-2 w-56 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-20">
                  <div className="px-4 py-3 border-b border-slate-200">
                    <p className="font-medium text-slate-900">{user?.full_name || user?.email}</p>
                    <p className="text-xs text-slate-600">{user?.email}</p>
                    <span className="inline-block mt-1 px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded-full">
                      {user?.role}
                    </span>
                  </div>
                  <Link
                    to="/admin/profile"
                    className="flex items-center gap-2 px-4 py-2 hover:bg-slate-50 text-sm"
                    onClick={() => setShowUserMenu(false)}
                  >
                    <User size={16} />
                    Profil Saya
                  </Link>
                  <Link
                    to="/admin/settings"
                    className="flex items-center gap-2 px-4 py-2 hover:bg-slate-50 text-sm"
                    onClick={() => setShowUserMenu(false)}
                  >
                    <Settings size={16} />
                    Pengaturan
                  </Link>
                  <div className="border-t border-slate-200 my-2"></div>
                  <button
                    onClick={handleSignOut}
                    className="w-full flex items-center gap-2 px-4 py-2 hover:bg-red-50 text-red-600 text-sm"
                  >
                    <LogOut size={16} />
                    Keluar
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
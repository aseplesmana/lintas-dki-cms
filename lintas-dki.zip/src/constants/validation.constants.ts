export const VALIDATION_RULES = {
  TITLE: {
    MIN_LENGTH: 10,
    MAX_LENGTH: 200,
  },
  SLUG: {
    MIN_LENGTH: 5,
    MAX_LENGTH: 200,
    PATTERN: /^[a-z0-9]+(?:-[a-z0-9]+)*$/,
  },
  CONTENT: {
    MIN_LENGTH: 100,
    MAX_LENGTH: 50000,
  },
  EXCERPT: {
    MIN_LENGTH: 50,
    MAX_LENGTH: 500,
  },
  META_DESCRIPTION: {
    MIN_LENGTH: 50,
    MAX_LENGTH: 160,
  },
  EMAIL: {
    PATTERN: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  },
  PASSWORD: {
    MIN_LENGTH: 8,
    MAX_LENGTH: 100,
    PATTERN: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/,
  },
  FULL_NAME: {
    MIN_LENGTH: 3,
    MAX_LENGTH: 100,
  },
  TAG_NAME: {
    MIN_LENGTH: 2,
    MAX_LENGTH: 50,
  },
  CATEGORY_NAME: {
    MIN_LENGTH: 3,
    MAX_LENGTH: 50,
  },
} as const;

export const ERROR_MESSAGES = {
  REQUIRED_FIELD: 'Field ini wajib diisi',
  INVALID_EMAIL: 'Format email tidak valid',
  INVALID_PASSWORD: 'Password harus minimal 8 karakter dengan huruf besar, kecil, dan angka',
  PASSWORD_MISMATCH: 'Password tidak cocok',
  MIN_LENGTH: (field: string, min: number) => `${field} minimal ${min} karakter`,
  MAX_LENGTH: (field: string, max: number) => `${field} maksimal ${max} karakter`,
  INVALID_FORMAT: (field: string) => `Format ${field} tidak valid`,
  NETWORK_ERROR: 'Terjadi kesalahan jaringan. Silakan coba lagi.',
  UNAUTHORIZED: 'Anda tidak memiliki akses ke halaman ini',
  NOT_FOUND: 'Data tidak ditemukan',
  SERVER_ERROR: 'Terjadi kesalahan server. Silakan coba lagi nanti.',
} as const;
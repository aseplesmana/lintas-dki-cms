export const ROUTES = {
  // Public routes
  HOME: '/',
  ARTICLES: '/articles',
  ARTICLE_DETAIL: '/articles/:slug',
  REPORTS: '/reports',
  REPORT_DETAIL: '/reports/:slug',
  CATEGORY: '/category/:slug',
  TAG: '/tag/:slug',
  SEARCH: '/search',
  
  // Auth routes
  LOGIN: '/login',
  SIGNUP: '/signup',
  RESET_PASSWORD: '/reset-password',
  
  // Admin routes
  ADMIN: '/admin',
  ADMIN_DASHBOARD: '/admin/dashboard',
  ADMIN_ARTICLES: '/admin/articles',
  ADMIN_ARTICLE_NEW: '/admin/articles/new',
  ADMIN_ARTICLE_EDIT: '/admin/articles/:id/edit',
  ADMIN_REPORTS: '/admin/reports',
  ADMIN_REPORT_NEW: '/admin/reports/new',
  ADMIN_REPORT_EDIT: '/admin/reports/:id/edit',
  ADMIN_CATEGORIES: '/admin/categories',
  ADMIN_MEDIA: '/admin/media',
  ADMIN_MONITORING: '/admin/monitoring',
  ADMIN_AI_TOOLS: '/admin/ai-tools',
  ADMIN_USERS: '/admin/users',
  ADMIN_SETTINGS: '/admin/settings',
  ADMIN_PROFILE: '/admin/profile',
  
  // Error routes
  NOT_FOUND: '/404',
} as const;

export const PUBLIC_ROUTES = [
  ROUTES.HOME,
  ROUTES.ARTICLES,
  ROUTES.ARTICLE_DETAIL,
  ROUTES.REPORTS,
  ROUTES.REPORT_DETAIL,
  ROUTES.CATEGORY,
  ROUTES.TAG,
  ROUTES.SEARCH,
  ROUTES.LOGIN,
  ROUTES.SIGNUP,
  ROUTES.RESET_PASSWORD,
] as const;

export const AUTH_ROUTES = [
  ROUTES.LOGIN,
  ROUTES.SIGNUP,
  ROUTES.RESET_PASSWORD,
] as const;

export const ADMIN_ROUTES = [
  ROUTES.ADMIN,
  ROUTES.ADMIN_DASHBOARD,
  ROUTES.ADMIN_ARTICLES,
  ROUTES.ADMIN_ARTICLE_NEW,
  ROUTES.ADMIN_ARTICLE_EDIT,
  ROUTES.ADMIN_REPORTS,
  ROUTES.ADMIN_REPORT_NEW,
  ROUTES.ADMIN_REPORT_EDIT,
  ROUTES.ADMIN_CATEGORIES,
  ROUTES.ADMIN_MEDIA,
  ROUTES.ADMIN_MONITORING,
  ROUTES.ADMIN_AI_TOOLS,
  ROUTES.ADMIN_USERS,
  ROUTES.ADMIN_SETTINGS,
  ROUTES.ADMIN_PROFILE,
] as const;
export const API_ENDPOINTS = {
  // Auth
  AUTH_LOGIN: '/auth/login',
  AUTH_LOGOUT: '/auth/logout',
  AUTH_REGISTER: '/auth/register',
  AUTH_RESET_PASSWORD: '/auth/reset-password',
  
  // Articles
  ARTICLES: '/api/articles',
  ARTICLE_BY_ID: (id: string) => `/api/articles/${id}`,
  ARTICLE_BY_SLUG: (slug: string) => `/api/articles/slug/${slug}`,
  ARTICLE_PUBLISH: (id: string) => `/api/articles/${id}/publish`,
  ARTICLES_SEARCH: '/api/articles/search',
  
  // Reports
  REPORTS: '/api/reports',
  REPORT_BY_ID: (id: string) => `/api/reports/${id}`,
  REPORT_BY_SLUG: (slug: string) => `/api/reports/slug/${slug}`,
  
  // Categories
  CATEGORIES: '/api/categories',
  CATEGORY_BY_ID: (id: string) => `/api/categories/${id}`,
  CATEGORY_ARTICLES: (slug: string) => `/api/categories/${slug}/articles`,
  
  // Tags
  TAGS: '/api/tags',
  TAG_BY_ID: (id: string) => `/api/tags/${id}`,
  TAG_ARTICLES: (slug: string) => `/api/tags/${slug}/articles`,
  
  // Media
  MEDIA_UPLOAD: '/api/media/upload',
  MEDIA: '/api/media',
  MEDIA_BY_ID: (id: string) => `/api/media/${id}`,
  
  // AI Services
  AI_GENERATE_ARTICLE: '/api/ai/generate-article',
  AI_SUMMARIZE: '/api/ai/summarize',
  AI_CLASSIFY: '/api/ai/classify',
  AI_GENERATE_REPORT: '/api/ai/generate-report',
  AI_CHAT: '/api/ai/chat',
  
  // Analytics
  ANALYTICS_DASHBOARD: '/api/analytics/dashboard',
  ANALYTICS_ARTICLE: (id: string) => `/api/analytics/articles/${id}`,
  ANALYTICS_TRACK: '/api/analytics/track',
  
  // Users
  USERS: '/api/users',
  USER_BY_ID: (id: string) => `/api/users/${id}`,
  USER_ROLE: (id: string) => `/api/users/${id}/role`,
  
  // Monitoring
  MONITORING: '/api/monitoring',
  MONITORING_BY_ID: (id: string) => `/api/monitoring/${id}`,
  MONITORING_PROCESS: (id: string) => `/api/monitoring/${id}/process`,
} as const;

export const SUPABASE_FUNCTIONS = {
  AI_CHAT: 'ai-chat',
  AI_CLASSIFY: 'ai-classify',
  AI_GENERATE_ARTICLE: 'ai-generate-article',
  AI_GENERATE_REPORT: 'ai-generate-report',
  AI_SUMMARIZE: 'ai-summarize',
  MEDIA_PROCESS: 'media-process',
  MEDIA_SCRAPE: 'media-scrape',
} as const;
import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import ReportDetail from '../../components/report/ReportDetail';
import Button from '../../components/common/Button';
import Spinner from '../../components/common/Spinner';
import { Report } from '../../types/report.types';
import { reportService } from '../../services/supabase/report.service';

const ReportDetailPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [report, setReport] = useState<Report | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReport();
  }, [id]);

  const loadReport = async () => {
    if (!id) return;

    try {
      const data = await reportService.getReportById(id);
      setReport(data);
    } catch (error) {
      console.error('Error loading report:', error);
      alert('Gagal memuat laporan');
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    navigate(`/admin/reports/${id}/edit`);
  };

  const handleDelete = async () => {
    if (!id) return;

    if (window.confirm('Yakin ingin menghapus laporan ini?')) {
      try {
        await reportService.deleteReport(id);
        alert('Laporan berhasil dihapus!');
        navigate('/admin/reports');
      } catch (error) {
        console.error('Error deleting report:', error);
        alert('Gagal menghapus laporan');
      }
    }
  };

  const handleDownload = () => {
    if (!report) return;

    const blob = new Blob([report.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.title}-${report.report_date}.txt`;
    a.click();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Spinner size={48} />
      </div>
    );
  }

  if (!report) {
    return (
      <div className="text-center py-12">
        <h3 className="text-xl font-bold text-slate-900 mb-2">Laporan Tidak Ditemukan</h3>
        <p className="text-slate-600 mb-6">Laporan yang Anda cari tidak ada atau telah dihapus.</p>
        <Button variant="primary" onClick={() => navigate('/admin/reports')}>
          Kembali ke Daftar Laporan
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" icon={<ArrowLeft size={18} />} onClick={() => navigate('/admin/reports')}>
          Kembali
        </Button>
      </div>

      {/* Report Detail */}
      <ReportDetail
        report={report}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onDownload={handleDownload}
      />
    </div>
  );
};

export default ReportDetailPage;
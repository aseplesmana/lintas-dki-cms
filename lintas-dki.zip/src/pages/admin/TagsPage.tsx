import React, { useState, useEffect } from 'react';
import { PlusCircle, Search } from 'lucide-react';
import TagList from '../../components/tag/TagList';
import TagForm from '../../components/tag/TagForm';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import { Tag, CreateTagDTO, TagFilters } from '../../types/tag.types';
import { tagService } from '../../services/supabase/tag.service';

const TagsPage: React.FC = () => {
  const [tags, setTags] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingTag, setEditingTag] = useState<Tag | null>(null);
  const [filters, setFilters] = useState<TagFilters>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadTags();
  }, []);

  const loadTags = async () => {
    setLoading(true);
    try {
      const data = await tagService.getTags();
      setTags(data);
    } catch (error) {
      console.error('Error loading tags:', error);
      alert('Gagal memuat tag');
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = () => {
    setEditingTag(null);
    setShowModal(true);
  };

  const handleEdit = async (id: string) => {
    try {
      const tag = await tagService.getTagById(id);
      setEditingTag(tag);
      setShowModal(true);
    } catch (error) {
      console.error('Error loading tag:', error);
      alert('Gagal memuat tag');
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Yakin ingin menghapus tag ini?')) {
      try {
        await tagService.deleteTag(id);
        loadTags();
      } catch (error) {
        console.error('Error deleting tag:', error);
        alert('Gagal menghapus tag');
      }
    }
  };

  const handleSubmit = async (data: CreateTagDTO) => {
    setSubmitting(true);
    try {
      if (editingTag) {
        await tagService.updateTag(editingTag.id, data);
      } else {
        await tagService.createTag(data);
      }
      setShowModal(false);
      loadTags();
    } catch (error) {
      console.error('Error saving tag:', error);
      alert('Gagal menyimpan tag');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredTags = tags.filter((tag) => {
    if (filters.search) {
      const search = filters.search.toLowerCase();
      return (
        tag.name.toLowerCase().includes(search) ||
        tag.slug.toLowerCase().includes(search)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Manajemen Tag</h1>
          <p className="text-slate-600 mt-1">Kelola tag artikel Anda</p>
        </div>
        <Button variant="primary" icon={<PlusCircle size={18} />} onClick={handleCreate}>
          Tag Baru
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total Tag</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{tags.length}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total Penggunaan</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">
            {tags.reduce((sum, tag) => sum + (tag.article_count || 0), 0)}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <Input
          placeholder="Cari tag..."
          value={filters.search || ''}
          onChange={(e) => setFilters({ ...filters, search: e.target.value })}
          icon={<Search size={18} />}
        />
      </div>

      {/* Tag List */}
      <TagList
        tags={filteredTags}
        loading={loading}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      {/* Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingTag ? 'Edit Tag' : 'Tag Baru'}
      >
        <TagForm
          initialData={editingTag || undefined}
          onSubmit={handleSubmit}
          onCancel={() => setShowModal(false)}
          loading={submitting}
        />
      </Modal>
    </div>
  );
};

export default TagsPage;
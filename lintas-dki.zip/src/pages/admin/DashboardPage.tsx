import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import DashboardStats from '../../components/dashboard/DashboardStats';
import ContentChart from '../../components/dashboard/ContentChart';
import ViewsChart from '../../components/dashboard/ViewsChart';
import QuickActions from '../../components/dashboard/QuickActions';
import RecentActivity from '../../components/dashboard/RecentActivity';
import Spinner from '../../components/common/Spinner';

const DashboardPage: React.FC = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalArticles: 0,
    totalReports: 0,
    totalViews: 0,
    activeUsers: 0,
    articlesChange: 0,
    reportsChange: 0,
    viewsChange: 0,
    usersChange: 0,
  });

  const [contentData, setContentData] = useState({
    labels: [] as string[],
    articles: [] as number[],
    reports: [] as number[],
  });

  const [viewsData, setViewsData] = useState({
    labels: [] as string[],
    views: [] as number[],
  });

  const [activities, setActivities] = useState<any[]>([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // TODO: Fetch real data from Supabase
      // For now, using mock data
      
      // Mock stats
      setStats({
        totalArticles: 156,
        totalReports: 42,
        totalViews: 12450,
        activeUsers: 8,
        articlesChange: 12.5,
        reportsChange: 8.3,
        viewsChange: 15.7,
        usersChange: -2.1,
      });

      // Mock content chart data
      setContentData({
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun'],
        articles: [12, 19, 15, 25, 22, 30],
        reports: [5, 8, 6, 10, 9, 12],
      });

      // Mock views chart data
      const days = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
      setViewsData({
        labels: days,
        views: [1200, 1450, 1350, 1800, 1650, 2100, 1900],
      });

      // Mock activities
      setActivities([
        {
          id: '1',
          type: 'article',
          title: 'Artikel baru dipublikasikan',
          description: 'Prabowo Dorong Kepala Daerah Dipilih DPRD',
          timestamp: '5 menit lalu',
          user: 'Admin',
        },
        {
          id: '2',
          type: 'report',
          title: 'Laporan monitoring dibuat',
          description: 'Laporan Monitoring 6 Desember 2025',
          timestamp: '15 menit lalu',
          user: 'Editor',
        },
        {
          id: '3',
          type: 'view',
          title: 'Artikel trending',
          description: 'OECD Perkirakan Ekonomi RI Tumbuh 5%',
          timestamp: '1 jam lalu',
        },
        {
          id: '4',
          type: 'user',
          title: 'Pengguna baru bergabung',
          description: 'John Doe bergabung sebagai Editor',
          timestamp: '2 jam lalu',
        },
      ]);

      setLoading(false);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Spinner size={48} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 text-white">
        <h1 className="text-3xl font-bold mb-2">
          Selamat Datang, {user?.full_name}! 👋
        </h1>
        <p className="text-blue-100">
          Berikut ringkasan aktivitas dan performa konten Anda hari ini.
        </p>
      </div>

      {/* Stats Cards */}
      <DashboardStats stats={stats} />

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <ContentChart data={contentData} />
        <ViewsChart data={viewsData} />
      </div>

      {/* Quick Actions & Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <QuickActions />
        <div className="lg:col-span-2">
          <RecentActivity activities={activities} />
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
import React, { useState } from 'react';
import { Eye, TrendingUp, AlertCircle, Calendar, Search } from 'lucide-react';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';

const MonitoringPage: React.FC = () => {
  const [dateRange, setDateRange] = useState({
    start: new Date().toISOString().split('T')[0],
    end: new Date().toISOString().split('T')[0],
  });

  // Mock data for demonstration
  const stats = {
    totalArticles: 1234,
    totalViews: 45678,
    avgEngagement: 78,
    trendingTopics: 12,
  };

  const trendingArticles = [
    {
      id: '1',
      title: 'Breaking News: Major Development in Jakarta',
      views: 5432,
      engagement: 85,
      sentiment: 'positive',
    },
    {
      id: '2',
      title: 'Economic Update: Market Analysis',
      views: 4321,
      engagement: 72,
      sentiment: 'neutral',
    },
    {
      id: '3',
      title: 'Political Commentary: Latest Updates',
      views: 3210,
      engagement: 68,
      sentiment: 'negative',
    },
  ];

  const sentimentColors = {
    positive: 'bg-green-100 text-green-700',
    neutral: 'bg-blue-100 text-blue-700',
    negative: 'bg-red-100 text-red-700',
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Media Monitoring</h1>
        <p className="text-slate-600 mt-1">Monitor performa dan tren artikel Anda</p>
      </div>

      {/* Date Range Filter */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <div className="flex items-center gap-4">
          <Calendar size={18} className="text-slate-400" />
          <Input
            type="date"
            value={dateRange.start}
            onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
            className="flex-1"
          />
          <span className="text-slate-600">-</span>
          <Input
            type="date"
            value={dateRange.end}
            onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
            className="flex-1"
          />
          <Button variant="primary">Apply</Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-slate-500 font-bold uppercase">Total Artikel</p>
            <Eye size={20} className="text-slate-400" />
          </div>
          <p className="text-3xl font-bold text-slate-900">{stats.totalArticles}</p>
          <p className="text-xs text-green-600 mt-1">+12% dari bulan lalu</p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-slate-500 font-bold uppercase">Total Views</p>
            <TrendingUp size={20} className="text-slate-400" />
          </div>
          <p className="text-3xl font-bold text-slate-900">{stats.totalViews.toLocaleString()}</p>
          <p className="text-xs text-green-600 mt-1">+18% dari bulan lalu</p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-slate-500 font-bold uppercase">Avg Engagement</p>
            <AlertCircle size={20} className="text-slate-400" />
          </div>
          <p className="text-3xl font-bold text-slate-900">{stats.avgEngagement}%</p>
          <p className="text-xs text-green-600 mt-1">+5% dari bulan lalu</p>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs text-slate-500 font-bold uppercase">Trending Topics</p>
            <TrendingUp size={20} className="text-slate-400" />
          </div>
          <p className="text-3xl font-bold text-slate-900">{stats.trendingTopics}</p>
          <p className="text-xs text-slate-600 mt-1">Topik populer hari ini</p>
        </div>
      </div>

      {/* Trending Articles */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-200">
          <h2 className="text-xl font-bold text-slate-900">Artikel Trending</h2>
          <p className="text-sm text-slate-600 mt-1">Artikel dengan performa terbaik</p>
        </div>
        <div className="divide-y divide-slate-200">
          {trendingArticles.map((article) => (
            <div key={article.id} className="p-6 hover:bg-slate-50 transition">
              <div className="flex items-start justify-between mb-3">
                <h3 className="font-medium text-slate-900 flex-1">{article.title}</h3>
                <span
                  className={`px-2 py-1 rounded-full text-xs font-bold ${
                    sentimentColors[article.sentiment as keyof typeof sentimentColors]
                  }`}
                >
                  {article.sentiment}
                </span>
              </div>
              <div className="flex items-center gap-6 text-sm text-slate-600">
                <div className="flex items-center gap-2">
                  <Eye size={16} />
                  <span>{article.views.toLocaleString()} views</span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp size={16} />
                  <span>{article.engagement}% engagement</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-6">
        <h2 className="text-xl font-bold text-slate-900 mb-4">Pencarian Lanjutan</h2>
        <div className="space-y-4">
          <Input
            placeholder="Cari artikel, topik, atau keyword..."
            icon={<Search size={18} />}
          />
          <div className="flex gap-3">
            <select className="flex-1 p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">Semua Kategori</option>
              <option value="politik">Politik</option>
              <option value="ekonomi">Ekonomi</option>
              <option value="olahraga">Olahraga</option>
            </select>
            <select className="flex-1 p-3 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500">
              <option value="">Semua Sentiment</option>
              <option value="positive">Positive</option>
              <option value="neutral">Neutral</option>
              <option value="negative">Negative</option>
            </select>
            <Button variant="primary">Search</Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonitoringPage;
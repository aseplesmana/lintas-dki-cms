import React, { useState } from 'react';
import { PlusCircle, Search, Edit, Trash2, Shield } from 'lucide-react';
import Button from '../../components/common/Button';
import Input from '../../components/common/Input';
import Spinner from '../../components/common/Spinner';

interface User {
  id: string;
  full_name: string;
  email: string;
  role: 'admin' | 'editor' | 'writer';
  status: 'active' | 'inactive';
  last_login: string;
  created_at: string;
}

const UsersPage: React.FC = () => {
  const [loading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Mock data
  const users: User[] = [
    {
      id: '1',
      full_name: 'Admin User',
      email: 'admin@lintasdki.com',
      role: 'admin',
      status: 'active',
      last_login: '2024-01-15T10:30:00Z',
      created_at: '2023-01-01T00:00:00Z',
    },
    {
      id: '2',
      full_name: 'Editor User',
      email: 'editor@lintasdki.com',
      role: 'editor',
      status: 'active',
      last_login: '2024-01-14T15:20:00Z',
      created_at: '2023-02-01T00:00:00Z',
    },
    {
      id: '3',
      full_name: 'Writer User',
      email: 'writer@lintasdki.com',
      role: 'writer',
      status: 'active',
      last_login: '2024-01-13T09:15:00Z',
      created_at: '2023-03-01T00:00:00Z',
    },
  ];

  const roleColors = {
    admin: 'bg-red-100 text-red-700',
    editor: 'bg-blue-100 text-blue-700',
    writer: 'bg-green-100 text-green-700',
  };

  const statusColors = {
    active: 'bg-green-100 text-green-700',
    inactive: 'bg-slate-100 text-slate-700',
  };

  const filteredUsers = users.filter((user) => {
    if (searchQuery) {
      const search = searchQuery.toLowerCase();
      return (
        user.full_name.toLowerCase().includes(search) ||
        user.email.toLowerCase().includes(search)
      );
    }
    return true;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Manajemen Pengguna</h1>
          <p className="text-slate-600 mt-1">Kelola pengguna dan hak akses</p>
        </div>
        <Button variant="primary" icon={<PlusCircle size={18} />}>
          Tambah Pengguna
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total Pengguna</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{users.length}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Admin</p>
          <p className="text-2xl font-bold text-red-600 mt-1">
            {users.filter((u) => u.role === 'admin').length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Editor</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">
            {users.filter((u) => u.role === 'editor').length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Writer</p>
          <p className="text-2xl font-bold text-green-600 mt-1">
            {users.filter((u) => u.role === 'writer').length}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <Input
          placeholder="Cari pengguna..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          icon={<Search size={18} />}
        />
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-bold uppercase text-slate-500">
                Pengguna
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold uppercase text-slate-500">
                Role
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold uppercase text-slate-500">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-bold uppercase text-slate-500">
                Last Login
              </th>
              <th className="px-6 py-3 text-right text-xs font-bold uppercase text-slate-500">
                Aksi
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {filteredUsers.map((user) => (
              <tr key={user.id} className="hover:bg-slate-50 transition">
                <td className="px-6 py-4">
                  <div>
                    <p className="font-medium text-slate-900">{user.full_name}</p>
                    <p className="text-sm text-slate-600">{user.email}</p>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-bold ${
                      roleColors[user.role]
                    }`}
                  >
                    {user.role.toUpperCase()}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-bold ${
                      statusColors[user.status]
                    }`}
                  >
                    {user.status === 'active' ? 'Aktif' : 'Tidak Aktif'}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm text-slate-600">
                  {new Date(user.last_login).toLocaleDateString('id-ID')}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      className="p-2 hover:bg-slate-200 rounded-lg transition"
                      title="Manage Permissions"
                    >
                      <Shield size={16} />
                    </button>
                    <button
                      className="p-2 hover:bg-slate-200 rounded-lg transition"
                      title="Edit"
                    >
                      <Edit size={16} />
                    </button>
                    <button
                      className="p-2 hover:bg-red-100 text-red-600 rounded-lg transition"
                      title="Delete"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default UsersPage;
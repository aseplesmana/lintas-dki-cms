import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Sparkles } from 'lucide-react';
import ReportForm from '../../components/report/ReportForm';
import ReportTemplateSelector from '../../components/report/ReportTemplateSelector';
import ReportGenerator from '../../components/report/ReportGenerator';
import Button from '../../components/common/Button';
import { CreateReportDTO, ReportTemplate } from '../../types/report.types';
import { reportService } from '../../services/supabase/report.service';

const CreateReportPage: React.FC = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<'template' | 'generator' | 'form'>('template');
  const [selectedTemplate, setSelectedTemplate] = useState<ReportTemplate>('investigation');
  const [saving, setSaving] = useState(false);

  const handleTemplateSelect = (templateId: string) => {
    setSelectedTemplate(templateId as ReportTemplate);
  };

  const handleUseAI = () => {
    setStep('generator');
  };

  const handleManualCreate = () => {
    setStep('form');
  };

  const handleSubmit = async (data: CreateReportDTO) => {
    setSaving(true);
    try {
      const reportData: CreateReportDTO = {
        ...data,
        report_type: selectedTemplate,
      };
      await reportService.createReport(reportData);
      alert('Laporan berhasil dibuat!');
      navigate('/admin/reports');
    } catch (error) {
      console.error('Error creating report:', error);
      alert('Gagal membuat laporan');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    if (window.confirm('Yakin ingin membatalkan? Perubahan tidak akan disimpan.')) {
      navigate('/admin/reports');
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" icon={<ArrowLeft size={18} />} onClick={() => navigate('/admin/reports')}>
          Kembali
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Buat Laporan Baru</h1>
          <p className="text-slate-600 mt-1">
            {step === 'template' && 'Pilih template laporan'}
            {step === 'generator' && 'Generate laporan dengan AI'}
            {step === 'form' && 'Lengkapi informasi laporan'}
          </p>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-xl border border-slate-200 p-8">
        {step === 'template' && (
          <div className="space-y-6">
            <ReportTemplateSelector
              selectedTemplate={selectedTemplate}
              onSelect={handleTemplateSelect}
            />

            <div className="flex justify-end gap-3 pt-6 border-t border-slate-200">
              <Button variant="outline" onClick={handleCancel}>
                Batal
              </Button>
              <Button variant="secondary" onClick={handleManualCreate}>
                Buat Manual
              </Button>
              <Button variant="primary" icon={<Sparkles size={18} />} onClick={handleUseAI}>
                Gunakan AI Generator
              </Button>
            </div>
          </div>
        )}

        {step === 'generator' && (
          <div className="space-y-6">
            <ReportGenerator />
            
            <div className="flex justify-end gap-3 pt-6 border-t border-slate-200">
              <Button variant="outline" onClick={() => setStep('template')}>
                Kembali
              </Button>
              <Button variant="primary" onClick={() => setStep('form')}>
                Lanjut ke Form
              </Button>
            </div>
          </div>
        )}

        {step === 'form' && (
          <ReportForm
            initialData={{
              report_type: selectedTemplate,
            }}
            onSubmit={handleSubmit}
            onCancel={handleCancel}
            loading={saving}
          />
        )}
      </div>
    </div>
  );
};

export default CreateReportPage;
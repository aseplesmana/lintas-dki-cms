import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import ReportForm from '../../components/report/ReportForm';
import ReportEditor from '../../components/report/ReportEditor';
import Button from '../../components/common/Button';
import Spinner from '../../components/common/Spinner';
import { CreateReportDTO } from '../../types/report.types';
import { reportService } from '../../services/supabase/report.service';

const EditReportPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [mode, setMode] = useState<'form' | 'editor'>('form');
  const [initialData, setInitialData] = useState<Partial<CreateReportDTO>>();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadReport();
  }, [id]);

  const loadReport = async () => {
    if (!id) return;

    try {
      const report = await reportService.getReportById(id);
      setInitialData({
        title: report.title,
        content: report.content,
        summary: report.summary,
        report_type: report.report_type,
        report_date: report.report_date,
        priority: report.priority,
        template: report.template,
        issues_count: report.issues_count,
        metadata: report.metadata,
      });
    } catch (error) {
      console.error('Error loading report:', error);
      alert('Gagal memuat laporan');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (data: CreateReportDTO) => {
    if (!id) return;

    setSaving(true);
    try {
      await reportService.updateReport(id, { ...data, id });
      alert('Laporan berhasil diperbarui!');
      navigate('/admin/reports');
    } catch (error) {
      console.error('Error updating report:', error);
      alert('Gagal memperbarui laporan');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveContent = async (content: string) => {
    if (!id || !initialData) return;

    setSaving(true);
    try {
      await reportService.updateReport(id, { ...initialData as CreateReportDTO, content, id });
      alert('Konten berhasil disimpan!');
      setInitialData((prev) => ({ ...prev, content }));
    } catch (error) {
      console.error('Error saving content:', error);
      alert('Gagal menyimpan konten');
    } finally {
      setSaving(false);
    }
  };

  const handleDownload = () => {
    if (!initialData?.content) return;

    const blob = new Blob([initialData.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${initialData.title || 'report'}-${initialData.report_date}.txt`;
    a.click();
  };

  const handleCancel = () => {
    if (window.confirm('Yakin ingin membatalkan? Perubahan tidak akan disimpan.')) {
      navigate('/admin/reports');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Spinner size={48} />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" icon={<ArrowLeft size={18} />} onClick={() => navigate('/admin/reports')}>
            Kembali
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Edit Laporan</h1>
            <p className="text-slate-600 mt-1">Perbarui informasi dan konten laporan</p>
          </div>
        </div>

        {/* Mode Toggle */}
        <div className="flex gap-2 bg-slate-100 p-1 rounded-lg">
          <button
            onClick={() => setMode('form')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition ${
              mode === 'form'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Form Mode
          </button>
          <button
            onClick={() => setMode('editor')}
            className={`px-4 py-2 rounded-md text-sm font-medium transition ${
              mode === 'editor'
                ? 'bg-white text-slate-900 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Editor Mode
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="bg-white rounded-xl border border-slate-200 p-8">
        {mode === 'form' ? (
          <ReportForm
            initialData={initialData}
            onSubmit={handleSubmit}
            onCancel={handleCancel}
            loading={saving}
          />
        ) : (
          <ReportEditor
            initialContent={initialData?.content || ''}
            onSave={handleSaveContent}
            onDownload={handleDownload}
            loading={saving}
          />
        )}
      </div>
    </div>
  );
};

export default EditReportPage;
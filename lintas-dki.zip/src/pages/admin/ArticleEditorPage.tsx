import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import ArticleForm from '../../components/article/ArticleForm';
import Button from '../../components/common/Button';
import Spinner from '../../components/common/Spinner';
import { CreateArticleDTO } from '../../types/article.types';
import { Category } from '../../types/category.types';
import { articleService } from '../../services/supabase/article.service';
import { categoryService } from '../../services/supabase/category.service';

const ArticleEditorPage: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const isEditMode = !!id;

  const [categories, setCategories] = useState<Category[]>([]);
  const [initialData, setInitialData] = useState<Partial<CreateArticleDTO>>();
  const [loading, setLoading] = useState(isEditMode);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    loadData();
  }, [id]);

  const loadData = async () => {
    try {
      const categoriesData = await categoryService.getCategories();
      setCategories(categoriesData);

      if (isEditMode && id) {
        const article = await articleService.getArticleById(id);
        
        // Extract tag names from article tags
        const tagNames = article.tags?.map((articleTag: any) => {
          // Handle both nested and flat tag structures
          return articleTag.tag?.name || articleTag.name || '';
        }).filter(Boolean) || [];

        setInitialData({
          title: article.title,
          slug: article.slug,
          content: article.content,
          excerpt: article.excerpt,
          category_id: article.category_id,
          featured_image: article.featured_image,
          status: article.status,
          is_featured: article.is_featured,
          meta_title: article.meta_title,
          meta_description: article.meta_description,
          tags: tagNames,
        });
      }
    } catch (error) {
      console.error('Error loading data:', error);
      alert('Gagal memuat data');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (data: CreateArticleDTO) => {
    setSaving(true);
    try {
      if (isEditMode && id) {
        await articleService.updateArticle(id, { ...data, id });
        alert('Artikel berhasil diperbarui!');
      } else {
        await articleService.createArticle(data);
        alert('Artikel berhasil dibuat!');
      }
      navigate('/admin/articles');
    } catch (error) {
      console.error('Error saving article:', error);
      alert('Gagal menyimpan artikel');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    if (window.confirm('Yakin ingin membatalkan? Perubahan tidak akan disimpan.')) {
      navigate('/admin/articles');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Spinner size={48} />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" icon={<ArrowLeft size={18} />} onClick={() => navigate('/admin/articles')}>
          Kembali
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-slate-900">
            {isEditMode ? 'Edit Artikel' : 'Artikel Baru'}
          </h1>
          <p className="text-slate-600 mt-1">
            {isEditMode ? 'Perbarui artikel yang sudah ada' : 'Buat artikel berita baru'}
          </p>
        </div>
      </div>

      {/* Form */}
      <div className="bg-white rounded-xl border border-slate-200 p-8">
        <ArticleForm
          initialData={initialData}
          categories={categories}
          onSubmit={handleSubmit}
          onCancel={handleCancel}
          loading={saving}
        />
      </div>
    </div>
  );
};

export default ArticleEditorPage;
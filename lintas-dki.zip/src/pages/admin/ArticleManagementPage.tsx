import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, Download, Upload } from 'lucide-react';
import ArticleList from '../../components/article/ArticleList';
import ArticleFilters from '../../components/article/ArticleFilters';
import Button from '../../components/common/Button';
import { Article, ArticleFilters as Filters } from '../../types/article.types';
import { Category } from '../../types/category.types';
import { articleService } from '../../services/supabase/article.service';
import { categoryService } from '../../services/supabase/category.service';

const ArticleManagementPage: React.FC = () => {
  const navigate = useNavigate();
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<Filters>({});

  useEffect(() => {
    loadData();
  }, [filters]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [articlesData, categoriesData] = await Promise.all([
        articleService.getArticles(filters, { page: 1, limit: 50 }),
        categoryService.getCategories(),
      ]);
      setArticles(articlesData.data);
      setCategories(categoriesData);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (id: string) => {
    navigate(`/admin/articles/${id}/edit`);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Yakin ingin menghapus artikel ini?')) {
      try {
        await articleService.deleteArticle(id);
        loadData();
      } catch (error) {
        console.error('Error deleting article:', error);
        alert('Gagal menghapus artikel');
      }
    }
  };

  const handleArticleClick = (id: string) => {
    navigate(`/admin/articles/${id}`);
  };

  const handleResetFilters = () => {
    setFilters({});
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Manajemen Artikel</h1>
          <p className="text-slate-600 mt-1">Kelola semua artikel berita Anda</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" icon={<Download size={18} />}>
            Export
          </Button>
          <Button variant="outline" icon={<Upload size={18} />}>
            Import
          </Button>
          <Button
            variant="primary"
            icon={<PlusCircle size={18} />}
            onClick={() => navigate('/admin/articles/new')}
          >
            Artikel Baru
          </Button>
        </div>
      </div>

      {/* Filters */}
      <ArticleFilters
        filters={filters}
        categories={categories}
        onFilterChange={setFilters}
        onReset={handleResetFilters}
      />

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total Artikel</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{articles.length}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Published</p>
          <p className="text-2xl font-bold text-green-600 mt-1">
            {articles.filter((a) => a.status === 'published').length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Draft</p>
          <p className="text-2xl font-bold text-slate-600 mt-1">
            {articles.filter((a) => a.status === 'draft').length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Featured</p>
          <p className="text-2xl font-bold text-yellow-600 mt-1">
            {articles.filter((a) => a.is_featured).length}
          </p>
        </div>
      </div>

      {/* Article List */}
      <ArticleList
        articles={articles}
        loading={loading}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onClick={handleArticleClick}
      />
    </div>
  );
};

export default ArticleManagementPage;
import React, { useState, useEffect } from 'react';
import { Upload, Search, Image, Video, FileText, Filter } from 'lucide-react';
import MediaGallery from '../../components/media/MediaGallery';
import MediaUploader from '../../components/media/MediaUploader';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import { MediaFile, MediaFilters } from '../../types/media.types';
import { mediaService } from '../../services/supabase/media.service';

const MediaPage: React.FC = () => {
  const [media, setMedia] = useState<MediaFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [filters, setFilters] = useState<MediaFilters>({});
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadMedia();
  }, []);

  const loadMedia = async () => {
    setLoading(true);
    try {
      const data = await mediaService.getFiles(filters);
      setMedia(data);
    } catch (error) {
      console.error('Error loading media:', error);
      alert('Gagal memuat media');
    } finally {
      setLoading(false);
    }
  };

  const handleUpload = async (files: File[]) => {
    setUploading(true);
    try {
      for (const file of files) {
        await mediaService.uploadFile({ file });
      }
      setShowUploadModal(false);
      loadMedia();
    } catch (error) {
      console.error('Error uploading files:', error);
      alert('Gagal upload file');
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (path: string) => {
    if (window.confirm('Yakin ingin menghapus file ini?')) {
      try {
        await mediaService.deleteFile(path);
        loadMedia();
      } catch (error) {
        console.error('Error deleting file:', error);
        alert('Gagal menghapus file');
      }
    }
  };

  const handleFilterType = (type: string) => {
    setFilters({ ...filters, type: filters.type === type ? undefined : type });
  };

  useEffect(() => {
    loadMedia();
  }, [filters]);

  const stats = {
    total: media.length,
    images: media.filter((m) => m.type.startsWith('image/')).length,
    videos: media.filter((m) => m.type.startsWith('video/')).length,
    documents: media.filter((m) => m.type.includes('pdf') || m.type.includes('document')).length,
    totalSize: media.reduce((sum, m) => sum + m.size, 0),
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Media Library</h1>
          <p className="text-slate-600 mt-1">Kelola file media Anda</p>
        </div>
        <Button
          variant="primary"
          icon={<Upload size={18} />}
          onClick={() => setShowUploadModal(true)}
        >
          Upload File
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total File</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{stats.total}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Gambar</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">{stats.images}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Video</p>
          <p className="text-2xl font-bold text-purple-600 mt-1">{stats.videos}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Dokumen</p>
          <p className="text-2xl font-bold text-orange-600 mt-1">{stats.documents}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total Size</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">
            {(stats.totalSize / 1024 / 1024).toFixed(0)} MB
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-4">
        <div className="flex items-center gap-2">
          <Filter size={18} className="text-slate-400" />
          <span className="text-sm font-medium text-slate-700">Filter:</span>
          <Button
            variant={filters.type === 'image' ? 'primary' : 'ghost'}
            size="sm"
            icon={<Image size={16} />}
            onClick={() => handleFilterType('image')}
          >
            Gambar
          </Button>
          <Button
            variant={filters.type === 'video' ? 'primary' : 'ghost'}
            size="sm"
            icon={<Video size={16} />}
            onClick={() => handleFilterType('video')}
          >
            Video
          </Button>
          <Button
            variant={filters.type === 'application' ? 'primary' : 'ghost'}
            size="sm"
            icon={<FileText size={16} />}
            onClick={() => handleFilterType('application')}
          >
            Dokumen
          </Button>
        </div>
        <Input
          placeholder="Cari file..."
          value={filters.search || ''}
          onChange={(e) => setFilters({ ...filters, search: e.target.value })}
          icon={<Search size={18} />}
        />
      </div>

      {/* Media Gallery */}
      <MediaGallery media={media} loading={loading} onDelete={handleDelete} />

      {/* Upload Modal */}
      <Modal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        title="Upload File"
        size="lg"
      >
        {uploading ? (
          <div className="text-center py-8">
            <p className="text-slate-600">Uploading files...</p>
          </div>
        ) : (
          <MediaUploader onUpload={handleUpload} multiple={true} maxSize={10} />
        )}
      </Modal>
    </div>
  );
};

export default MediaPage;
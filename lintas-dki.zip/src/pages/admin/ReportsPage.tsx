import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, Download, Upload } from 'lucide-react';
import ReportList from '../../components/report/ReportList';
import ReportFilters from '../../components/report/ReportFilters';
import Button from '../../components/common/Button';
import { Report, ReportFilters as Filters } from '../../types/report.types';
import { reportService } from '../../services/supabase/report.service';

const ReportsPage: React.FC = () => {
  const navigate = useNavigate();
  const [reports, setReports] = useState<Report[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState<Filters>({});

  useEffect(() => {
    loadReports();
  }, [filters]);

  const loadReports = async () => {
    setLoading(true);
    try {
      const data = await reportService.getReports(filters, { page: 1, limit: 50 });
      setReports(data.data);
    } catch (error) {
      console.error('Error loading reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (id: string) => {
    navigate(`/admin/reports/${id}/edit`);
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Yakin ingin menghapus laporan ini?')) {
      try {
        await reportService.deleteReport(id);
        loadReports();
      } catch (error) {
        console.error('Error deleting report:', error);
        alert('Gagal menghapus laporan');
      }
    }
  };

  const handleDownload = async (id: string) => {
    try {
      const report = await reportService.getReportById(id);
      const blob = new Blob([report.content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${report.title}-${report.report_date}.txt`;
      a.click();
    } catch (error) {
      console.error('Error downloading report:', error);
      alert('Gagal download laporan');
    }
  };

  const handleReportClick = (id: string) => {
    navigate(`/admin/reports/${id}`);
  };

  const handleResetFilters = () => {
    setFilters({});
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Manajemen Laporan</h1>
          <p className="text-slate-600 mt-1">Kelola semua laporan monitoring media Anda</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" icon={<Download size={18} />}>
            Export
          </Button>
          <Button variant="outline" icon={<Upload size={18} />}>
            Import
          </Button>
          <Button
            variant="primary"
            icon={<PlusCircle size={18} />}
            onClick={() => navigate('/admin/reports/new')}
          >
            Laporan Baru
          </Button>
        </div>
      </div>

      {/* Filters */}
      <ReportFilters
        filters={filters}
        onFilterChange={setFilters}
        onReset={handleResetFilters}
      />

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total Laporan</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{reports.length}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Investigasi</p>
          <p className="text-2xl font-bold text-blue-600 mt-1">
            {reports.filter((r) => r.report_type === 'investigation').length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Analisis</p>
          <p className="text-2xl font-bold text-purple-600 mt-1">
            {reports.filter((r) => r.report_type === 'analysis').length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Prioritas Tinggi</p>
          <p className="text-2xl font-bold text-red-600 mt-1">
            {reports.filter((r) => r.priority === 'high' || r.priority === 'urgent').length}
          </p>
        </div>
      </div>

      {/* Report List */}
      <ReportList
        reports={reports}
        loading={loading}
        onEdit={handleEdit}
        onDelete={handleDelete}
        onDownload={handleDownload}
        onClick={handleReportClick}
      />
    </div>
  );
};

export default ReportsPage;
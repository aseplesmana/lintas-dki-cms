import React, { useState, useEffect } from 'react';
import { PlusCircle, Search } from 'lucide-react';
import CategoryList from '../../components/category/CategoryList';
import CategoryForm from '../../components/category/CategoryForm';
import Button from '../../components/common/Button';
import Modal from '../../components/common/Modal';
import Input from '../../components/common/Input';
import { Category, CreateCategoryDTO, CategoryFilters } from '../../types/category.types';
import { categoryService } from '../../services/supabase/category.service';

const CategoriesPage: React.FC = () => {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [filters, setFilters] = useState<CategoryFilters>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    setLoading(true);
    try {
      const data = await categoryService.getCategories();
      setCategories(data);
    } catch (error) {
      console.error('Error loading categories:', error);
      alert('Gagal memuat kategori');
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = () => {
    setEditingCategory(null);
    setShowModal(true);
  };

  const handleEdit = async (id: string) => {
    try {
      const category = await categoryService.getCategoryById(id);
      setEditingCategory(category);
      setShowModal(true);
    } catch (error) {
      console.error('Error loading category:', error);
      alert('Gagal memuat kategori');
    }
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Yakin ingin menghapus kategori ini?')) {
      try {
        await categoryService.deleteCategory(id);
        loadCategories();
      } catch (error) {
        console.error('Error deleting category:', error);
        alert('Gagal menghapus kategori');
      }
    }
  };

  const handleSubmit = async (data: CreateCategoryDTO) => {
    setSubmitting(true);
    try {
      if (editingCategory) {
        await categoryService.updateCategory(editingCategory.id, data);
      } else {
        await categoryService.createCategory(data);
      }
      setShowModal(false);
      loadCategories();
    } catch (error) {
      console.error('Error saving category:', error);
      alert('Gagal menyimpan kategori');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredCategories = categories.filter((cat) => {
    if (filters.search) {
      const search = filters.search.toLowerCase();
      return (
        cat.name.toLowerCase().includes(search) ||
        cat.slug.toLowerCase().includes(search)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Manajemen Kategori</h1>
          <p className="text-slate-600 mt-1">Kelola kategori artikel Anda</p>
        </div>
        <Button variant="primary" icon={<PlusCircle size={18} />} onClick={handleCreate}>
          Kategori Baru
        </Button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Total Kategori</p>
          <p className="text-2xl font-bold text-slate-900 mt-1">{categories.length}</p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Kategori Aktif</p>
          <p className="text-2xl font-bold text-green-600 mt-1">
            {categories.filter((c) => c.is_active).length}
          </p>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <p className="text-xs text-slate-500 font-bold uppercase">Kategori Tidak Aktif</p>
          <p className="text-2xl font-bold text-slate-600 mt-1">
            {categories.filter((c) => !c.is_active).length}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <Input
          placeholder="Cari kategori..."
          value={filters.search || ''}
          onChange={(e) => setFilters({ ...filters, search: e.target.value })}
          icon={<Search size={18} />}
        />
      </div>

      {/* Category List */}
      <CategoryList
        categories={filteredCategories}
        loading={loading}
        onEdit={handleEdit}
        onDelete={handleDelete}
      />

      {/* Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingCategory ? 'Edit Kategori' : 'Kategori Baru'}
      >
        <CategoryForm
          initialData={editingCategory || undefined}
          onSubmit={handleSubmit}
          onCancel={() => setShowModal(false)}
          loading={submitting}
        />
      </Modal>
    </div>
  );
};

export default CategoriesPage;
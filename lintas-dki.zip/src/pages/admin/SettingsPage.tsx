import React, { useState } from 'react';
import { Save, Settings, Globe, Bell, Shield, Database } from 'lucide-react';
import Input from '../../components/common/Input';
import Textarea from '../../components/common/Textarea';
import Button from '../../components/common/Button';

const SettingsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('general');
  const [saving, setSaving] = useState(false);

  const [generalSettings, setGeneralSettings] = useState({
    siteName: 'Lintas DKI',
    siteDescription: 'Portal Berita Terpercaya Jakarta',
    siteUrl: 'https://lintasdki.com',
    contactEmail: 'redaksi@lintasdki.com',
  });

  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: false,
    articlePublished: true,
    commentReceived: true,
    reportGenerated: true,
  });

  const handleSave = async () => {
    setSaving(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    setSaving(false);
    alert('Pengaturan berhasil disimpan!');
  };

  const tabs = [
    { id: 'general', label: 'Umum', icon: Settings },
    { id: 'site', label: 'Website', icon: Globe },
    { id: 'notifications', label: 'Notifikasi', icon: Bell },
    { id: 'security', label: 'Keamanan', icon: Shield },
    { id: 'database', label: 'Database', icon: Database },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900">Pengaturan</h1>
        <p className="text-slate-600 mt-1">Kelola pengaturan aplikasi Anda</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-xl border border-slate-200 p-2">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                    activeTab === tab.id
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon size={18} />
                  <span className="font-medium text-sm">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-xl border border-slate-200 p-6">
            {activeTab === 'general' && (
              <div className="space-y-6">
                <h2 className="text-xl font-bold text-slate-900">Pengaturan Umum</h2>
                <Input
                  label="Nama Situs"
                  value={generalSettings.siteName}
                  onChange={(e) =>
                    setGeneralSettings({ ...generalSettings, siteName: e.target.value })
                  }
                />
                <Textarea
                  label="Deskripsi Situs"
                  value={generalSettings.siteDescription}
                  onChange={(e) =>
                    setGeneralSettings({ ...generalSettings, siteDescription: e.target.value })
                  }
                  rows={3}
                />
                <Input
                  label="URL Situs"
                  value={generalSettings.siteUrl}
                  onChange={(e) =>
                    setGeneralSettings({ ...generalSettings, siteUrl: e.target.value })
                  }
                />
                <Input
                  label="Email Kontak"
                  type="email"
                  value={generalSettings.contactEmail}
                  onChange={(e) =>
                    setGeneralSettings({ ...generalSettings, contactEmail: e.target.value })
                  }
                />
              </div>
            )}

            {activeTab === 'site' && (
              <div className="space-y-6">
                <h2 className="text-xl font-bold text-slate-900">Pengaturan Website</h2>
                <p className="text-slate-600">
                  Kelola tampilan dan perilaku website Anda
                </p>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium text-slate-900">Mode Maintenance</p>
                      <p className="text-sm text-slate-600">Aktifkan mode maintenance</p>
                    </div>
                    <input type="checkbox" className="w-5 h-5 text-blue-600 rounded" />
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium text-slate-900">Komentar Publik</p>
                      <p className="text-sm text-slate-600">Izinkan komentar pada artikel</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-5 h-5 text-blue-600 rounded" />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'notifications' && (
              <div className="space-y-6">
                <h2 className="text-xl font-bold text-slate-900">Pengaturan Notifikasi</h2>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium text-slate-900">Email Notifications</p>
                      <p className="text-sm text-slate-600">Terima notifikasi via email</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={notificationSettings.emailNotifications}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          emailNotifications: e.target.checked,
                        })
                      }
                      className="w-5 h-5 text-blue-600 rounded"
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium text-slate-900">Artikel Dipublikasi</p>
                      <p className="text-sm text-slate-600">Notifikasi saat artikel dipublikasi</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={notificationSettings.articlePublished}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          articlePublished: e.target.checked,
                        })
                      }
                      className="w-5 h-5 text-blue-600 rounded"
                    />
                  </div>
                  <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                    <div>
                      <p className="font-medium text-slate-900">Laporan Dibuat</p>
                      <p className="text-sm text-slate-600">Notifikasi saat laporan dibuat</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={notificationSettings.reportGenerated}
                      onChange={(e) =>
                        setNotificationSettings({
                          ...notificationSettings,
                          reportGenerated: e.target.checked,
                        })
                      }
                      className="w-5 h-5 text-blue-600 rounded"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-6">
                <h2 className="text-xl font-bold text-slate-900">Pengaturan Keamanan</h2>
                <p className="text-slate-600">
                  Kelola keamanan akun dan aplikasi Anda
                </p>
                <div className="space-y-4">
                  <Button variant="outline" className="w-full justify-start">
                    Ubah Password
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Two-Factor Authentication
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Session Management
                  </Button>
                  <Button variant="outline" className="w-full justify-start text-red-600">
                    Logout dari Semua Device
                  </Button>
                </div>
              </div>
            )}

            {activeTab === 'database' && (
              <div className="space-y-6">
                <h2 className="text-xl font-bold text-slate-900">Pengaturan Database</h2>
                <p className="text-slate-600">
                  Kelola database dan backup data
                </p>
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                    <p className="font-medium text-blue-900">Database Status</p>
                    <p className="text-sm text-blue-700 mt-1">Connected to Supabase</p>
                  </div>
                  <Button variant="outline" className="w-full justify-start">
                    Backup Database
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    Restore Database
                  </Button>
                  <Button variant="outline" className="w-full justify-start text-red-600">
                    Clear Cache
                  </Button>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-3 pt-6 border-t border-slate-200 mt-6">
              <Button variant="ghost">Reset</Button>
              <Button
                variant="primary"
                icon={<Save size={18} />}
                onClick={handleSave}
                loading={saving}
              >
                Simpan Perubahan
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
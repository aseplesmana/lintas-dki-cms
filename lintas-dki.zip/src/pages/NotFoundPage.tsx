import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search } from 'lucide-react';
import Button from '../components/common/Button';

const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center px-4">
      <div className="max-w-2xl w-full text-center">
        <div className="mb-8">
          <h1 className="text-9xl font-bold text-blue-600 mb-4">404</h1>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            Halaman Tidak Ditemukan
          </h2>
          <p className="text-lg text-slate-600 mb-8">
            Maaf, halaman yang Anda cari tidak dapat ditemukan. Halaman mungkin telah dipindahkan atau dihapus.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/">
            <Button variant="primary" icon={<Home size={18} />}>
              Kembali ke Beranda
            </Button>
          </Link>
          <Link to="/search">
            <Button variant="outline" icon={<Search size={18} />}>
              Cari Artikel
            </Button>
          </Link>
        </div>

        <div className="mt-12 p-6 bg-white rounded-xl border border-slate-200">
          <h3 className="font-bold text-slate-900 mb-4">Halaman Populer:</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
            <Link to="/" className="text-blue-600 hover:text-blue-700 transition">
              → Beranda
            </Link>
            <Link to="/about" className="text-blue-600 hover:text-blue-700 transition">
              → Tentang Kami
            </Link>
            <Link to="/contact" className="text-blue-600 hover:text-blue-700 transition">
              → Kontak
            </Link>
            <Link to="/search" className="text-blue-600 hover:text-blue-700 transition">
              → Pencarian
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFoundPage;
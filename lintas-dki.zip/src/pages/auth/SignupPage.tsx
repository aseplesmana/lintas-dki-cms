import React from 'react';
import SignupForm from '../../components/auth/SignupForm';

const SignupPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Left Side - Branding */}
        <div className="hidden lg:block">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-green-600 to-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl">
                L
              </div>
              <div>
                <h1 className="text-3xl font-black text-slate-900">
                  LINTAS <span className="text-green-600">DKI</span>
                </h1>
                <p className="text-sm text-slate-500 font-bold">Content Management System</p>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-4xl font-bold text-slate-900 leading-tight">
                Bergabung dengan Tim Redaksi
              </h2>
              <p className="text-lg text-slate-600">
                Mulai kelola konten berita dengan sistem CMS yang mudah digunakan.
              </p>
            </div>

            <div className="bg-white rounded-xl p-6 border border-slate-200 shadow-sm">
              <h3 className="font-bold text-slate-900 mb-4">Fitur untuk Anda:</h3>
              <ul className="space-y-3">
                {[
                  'Akses ke editor artikel',
                  'Dashboard analytics personal',
                  'Kolaborasi dengan tim redaksi',
                  'Notifikasi real-time',
                  'Media library unlimited',
                ].map((feature, idx) => (
                  <li key={idx} className="flex items-center gap-2 text-slate-700">
                    <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-green-600 text-xs">✓</span>
                    </div>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right Side - Signup Form */}
        <div className="flex items-center justify-center">
          <SignupForm />
        </div>
      </div>
    </div>
  );
};

export default SignupPage;
import React from 'react';
import LoginForm from '../../components/auth/LoginForm';

const LoginPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        {/* Left Side - Branding */}
        <div className="hidden lg:block">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl">
                L
              </div>
              <div>
                <h1 className="text-3xl font-black text-slate-900">
                  LINTAS <span className="text-blue-600">DKI</span>
                </h1>
                <p className="text-sm text-slate-500 font-bold">Content Management System</p>
              </div>
            </div>

            <div className="space-y-4">
              <h2 className="text-4xl font-bold text-slate-900 leading-tight">
                Kelola Konten Berita dengan Mudah
              </h2>
              <p className="text-lg text-slate-600">
                Platform CMS modern dengan AI untuk otomasi pembuatan artikel, 
                klasifikasi konten, dan laporan monitoring media.
              </p>
            </div>

            <div className="space-y-3">
              {[
                { icon: '📝', text: 'Editor Artikel dengan AI Assistant' },
                { icon: '📊', text: 'Dashboard Analytics Real-time' },
                { icon: '🤖', text: 'Auto-generate Laporan Monitoring' },
                { icon: '🔒', text: 'Keamanan Tingkat Enterprise' },
              ].map((feature, idx) => (
                <div key={idx} className="flex items-center gap-3 text-slate-700">
                  <span className="text-2xl">{feature.icon}</span>
                  <span className="font-medium">{feature.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side - Login Form */}
        <div className="flex items-center justify-center">
          <LoginForm />
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
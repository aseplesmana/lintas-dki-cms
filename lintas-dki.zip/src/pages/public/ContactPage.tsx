import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Clock } from 'lucide-react';
import Breadcrumb from '../../components/layout/Breadcrumb';
import Input from '../../components/common/Input';
import Textarea from '../../components/common/Textarea';
import Button from '../../components/common/Button';

const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setSubmitting(false);
    alert('Pesan Anda berhasil dikirim! Kami akan segera menghubungi Anda.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const contactInfo = [
    {
      icon: <Mail size={24} />,
      title: 'Email',
      value: 'redaksi@lintasdki.com',
      link: 'mailto:redaksi@lintasdki.com',
    },
    {
      icon: <Phone size={24} />,
      title: 'Telepon',
      value: '+62 21 1234 5678',
      link: 'tel:+622112345678',
    },
    {
      icon: <MapPin size={24} />,
      title: 'Alamat',
      value: 'Jl. Sudirman No. 123, Jakarta Pusat 10220',
      link: 'https://maps.google.com',
    },
    {
      icon: <Clock size={24} />,
      title: 'Jam Operasional',
      value: 'Senin - Jumat: 09.00 - 17.00 WIB',
      link: null,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: 'Beranda', path: '/' },
          { label: 'Kontak' },
        ]}
      />

      {/* Header */}
      <div className="bg-white rounded-xl shadow-lg p-8 text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Hubungi Kami</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Ada pertanyaan, saran, atau kritik? Kami siap mendengarkan Anda. Hubungi kami melalui
          formulir di bawah atau kontak langsung.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Contact Info */}
        <div className="lg:col-span-1 space-y-4">
          {contactInfo.map((info, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-slate-200 p-6 hover:shadow-lg transition"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0 text-blue-600">
                  {info.icon}
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-slate-900 mb-1">{info.title}</h3>
                  {info.link ? (
                    <a
                      href={info.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-700 transition"
                    >
                      {info.value}
                    </a>
                  ) : (
                    <p className="text-slate-600">{info.value}</p>
                  )}
                </div>
              </div>
            </div>
          ))}

          {/* Social Media */}
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-6 text-white">
            <h3 className="font-bold mb-4">Ikuti Kami</h3>
            <div className="flex gap-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition"
              >
                <span className="sr-only">Facebook</span>
                F
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition"
              >
                <span className="sr-only">Twitter</span>
                T
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition"
              >
                <span className="sr-only">Instagram</span>
                I
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition"
              >
                <span className="sr-only">YouTube</span>
                Y
              </a>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-lg p-8 space-y-6">
            <h2 className="text-2xl font-bold text-slate-900 mb-6">Kirim Pesan</h2>

            <Input
              label="Nama Lengkap *"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Masukkan nama lengkap Anda"
              required
            />

            <Input
              type="email"
              label="Email *"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="email@example.com"
              required
            />

            <Input
              label="Subjek *"
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              placeholder="Subjek pesan Anda"
              required
            />

            <Textarea
              label="Pesan *"
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              placeholder="Tulis pesan Anda di sini..."
              rows={6}
              required
            />

            <Button
              type="submit"
              variant="primary"
              icon={<Send size={18} />}
              loading={submitting}
              className="w-full"
            >
              Kirim Pesan
            </Button>
          </form>
        </div>
      </div>

      {/* Map */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="aspect-[21/9] bg-slate-200">
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3966.521260322283!2d106.8195613!3d-6.1944491!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69f5d2e764b12d%3A0x3d2ad6e1e0e9bcc8!2sJakarta!5e0!3m2!1sen!2sid!4v1234567890"
            width="100%"
            height="100%"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Lintas DKI Location"
          />
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
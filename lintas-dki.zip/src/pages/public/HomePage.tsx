import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Clock, Eye, ArrowRight } from 'lucide-react';
import { Article } from '../../types/article.types';
import { Category } from '../../types/category.types';
import { articleService } from '../../services/supabase/article.service';
import { categoryService } from '../../services/supabase/category.service';
import { formatDate } from '../../utils/date.utils';
import NewsletterSubscribe from '../../components/public/NewsletterSubscribe';
import Spinner from '../../components/common/Spinner';

const HomePage: React.FC = () => {
  const [featuredArticles, setFeaturedArticles] = useState<Article[]>([]);
  const [latestArticles, setLatestArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [articlesResponse, cats] = await Promise.all([
        articleService.getArticles({ status: 'published' }, { page: 1, limit: 10 }),
        categoryService.getCategories(),
      ]);

      const articles = articlesResponse.data;
      setFeaturedArticles(articles.slice(0, 3));
      setLatestArticles(articles.slice(3, 10));
      setCategories(cats.filter((c) => c.is_active).slice(0, 6));
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-12">
      {/* Hero Section - Featured Articles */}
      <section>
        <div className="flex items-center gap-2 mb-6">
          <TrendingUp size={24} className="text-blue-600" />
          <h2 className="text-3xl font-bold text-slate-900">Berita Utama</h2>
        </div>

        {featuredArticles.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Main Featured */}
            <Link
              to={`/article/${featuredArticles[0].slug}`}
              className="lg:row-span-2 group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition"
            >
              {featuredArticles[0].featured_image && (
                <div className="relative w-full h-64 lg:h-80 bg-slate-100 overflow-hidden">
                  <img
                    src={featuredArticles[0].featured_image}
                    alt={featuredArticles[0].title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                    <span className="inline-block px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full mb-3">
                      {featuredArticles[0].category?.name}
                    </span>
                    <h3 className="text-2xl font-bold mb-2 line-clamp-2">
                      {featuredArticles[0].title}
                    </h3>
                    <div className="flex items-center gap-4 text-sm text-white/90">
                      <div className="flex items-center gap-1">
                        <Clock size={16} />
                        <span>{formatDate(featuredArticles[0].published_at || featuredArticles[0].created_at)}</span>
                      </div>
                      {featuredArticles[0].views !== undefined && (
                        <div className="flex items-center gap-1">
                          <Eye size={16} />
                          <span>{featuredArticles[0].views}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
              <div className="p-6">
                <p className="text-slate-600 line-clamp-3">
                  {featuredArticles[0].excerpt}
                </p>
              </div>
            </Link>

            {/* Secondary Featured */}
            <div className="space-y-6">
              {featuredArticles.slice(1, 3).map((article) => (
                <Link
                  key={article.id}
                  to={`/article/${article.slug}`}
                  className="group bg-white rounded-xl overflow-hidden shadow hover:shadow-lg transition flex flex-col sm:flex-row gap-0 sm:gap-4"
                >
                  {article.featured_image && (
                    <div className="relative w-full sm:w-48 h-48 sm:h-auto flex-shrink-0 bg-slate-100 overflow-hidden">
                      <img
                        src={article.featured_image}
                        alt={article.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                      />
                    </div>
                  )}
                  <div className="p-4 flex-1 flex flex-col justify-center">
                    <span className="inline-block px-2 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full mb-2 w-fit">
                      {article.category?.name}
                    </span>
                    <h3 className="font-bold text-lg text-slate-900 line-clamp-2 group-hover:text-blue-600 transition mb-2">
                      {article.title}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <div className="flex items-center gap-1">
                        <Clock size={14} />
                        <span>{formatDate(article.published_at || article.created_at)}</span>
                      </div>
                      {article.views !== undefined && (
                        <div className="flex items-center gap-1">
                          <Eye size={14} />
                          <span>{article.views}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Categories Section */}
      {categories.length > 0 && (
        <section>
          <h2 className="text-3xl font-bold text-slate-900 mb-6">Kategori</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/category/${category.slug}`}
                className="bg-white rounded-xl border border-slate-200 p-6 text-center hover:shadow-lg hover:border-blue-300 transition group"
              >
                <h3 className="font-bold text-slate-900 group-hover:text-blue-600 transition">
                  {category.name}
                </h3>
                {category.article_count !== undefined && (
                  <p className="text-sm text-slate-600 mt-1">
                    {category.article_count} artikel
                  </p>
                )}
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Latest Articles */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-3xl font-bold text-slate-900">Berita Terbaru</h2>
          <Link
            to="/search"
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 font-medium transition"
          >
            Lihat Semua
            <ArrowRight size={20} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {latestArticles.map((article) => (
            <Link
              key={article.id}
              to={`/article/${article.slug}`}
              className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition"
            >
              {article.featured_image && (
                <div className="relative w-full h-48 bg-slate-100 overflow-hidden">
                  <img
                    src={article.featured_image}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                </div>
              )}
              <div className="p-4">
                <span className="inline-block px-2 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-full mb-2">
                  {article.category?.name}
                </span>
                <h3 className="font-bold text-slate-900 line-clamp-2 group-hover:text-blue-600 transition mb-2">
                  {article.title}
                </h3>
                <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                  {article.excerpt}
                </p>
                <div className="flex items-center gap-4 text-xs text-slate-500">
                  <div className="flex items-center gap-1">
                    <Clock size={14} />
                    <span>{formatDate(article.published_at || article.created_at)}</span>
                  </div>
                  {article.views !== undefined && (
                    <div className="flex items-center gap-1">
                      <Eye size={14} />
                      <span>{article.views}</span>
                    </div>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Newsletter */}
      <section>
        <NewsletterSubscribe />
      </section>
    </div>
  );
};

export default HomePage;
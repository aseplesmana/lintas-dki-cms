import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Clock, Eye, Filter } from 'lucide-react';
import { Article } from '../../types/article.types';
import { Category } from '../../types/category.types';
import { articleService } from '../../services/supabase/article.service';
import { categoryService } from '../../services/supabase/category.service';
import { formatDate } from '../../utils/date.utils';
import Breadcrumb from '../../components/layout/Breadcrumb';
import Spinner from '../../components/common/Spinner';

const CategoryPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [category, setCategory] = useState<Category | null>(null);
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'latest' | 'popular'>('latest');

  useEffect(() => {
    if (slug) {
      loadData();
    }
  }, [slug, sortBy]);

  const loadData = async () => {
    setLoading(true);
    try {
      const cat = await categoryService.getCategoryBySlug(slug!);
      setCategory(cat);

      const articlesResponse = await articleService.getArticles(
        { category: cat.id, status: 'published' },
        { page: 1, limit: 100 }
      );

      // Sort articles
      const sorted = [...articlesResponse.data].sort((a, b) => {
        if (sortBy === 'popular') {
          return (b.views || 0) - (a.views || 0);
        }
        return new Date(b.published_at || b.created_at).getTime() - 
               new Date(a.published_at || a.created_at).getTime();
      });

      setArticles(sorted);
    } catch (error) {
      console.error('Error loading category:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!category) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Kategori Tidak Ditemukan</h1>
        <p className="text-slate-600 mb-6">Kategori yang Anda cari tidak tersedia.</p>
        <Link to="/" className="text-blue-600 hover:text-blue-700 font-medium">
          Kembali ke Beranda
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: 'Beranda', path: '/' },
          { label: category.name },
        ]}
      />

      {/* Category Header */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h1 className="text-4xl font-bold text-slate-900 mb-2">{category.name}</h1>
        {category.description && (
          <p className="text-lg text-slate-600">{category.description}</p>
        )}
        <p className="text-sm text-slate-500 mt-4">
          {articles.length} artikel ditemukan
        </p>
      </div>

      {/* Filter */}
      <div className="bg-white rounded-xl border border-slate-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Filter size={18} className="text-slate-400" />
            <span className="text-sm font-medium text-slate-700">Urutkan:</span>
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'latest' | 'popular')}
            className="px-4 py-2 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="latest">Terbaru</option>
            <option value="popular">Terpopuler</option>
          </select>
        </div>
      </div>

      {/* Articles Grid */}
      {articles.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center">
          <p className="text-slate-600">Belum ada artikel dalam kategori ini.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article) => (
            <Link
              key={article.id}
              to={`/article/${article.slug}`}
              className="group bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition"
            >
              {article.featured_image && (
                <div className="aspect-video bg-slate-100 overflow-hidden">
                  <img
                    src={article.featured_image}
                    alt={article.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                  />
                </div>
              )}
              <div className="p-4">
                <h3 className="font-bold text-slate-900 line-clamp-2 group-hover:text-blue-600 transition mb-2">
                  {article.title}
                </h3>
                <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                  {article.excerpt}
                </p>
                <div className="flex items-center gap-4 text-xs text-slate-500">
                  <div className="flex items-center gap-1">
                    <Clock size={14} />
                    <span>{formatDate(article.published_at || article.created_at)}</span>
                  </div>
                  {article.views !== undefined && (
                    <div className="flex items-center gap-1">
                      <Eye size={14} />
                      <span>{article.views}</span>
                    </div>
                  )}
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};

export default CategoryPage;
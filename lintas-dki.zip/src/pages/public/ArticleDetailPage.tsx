import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Clock, Eye, User, Tag as TagIcon } from 'lucide-react';
import { Article } from '../../types/article.types';
import { articleService } from '../../services/supabase/article.service';
import { formatDate } from '../../utils/date.utils';
import Breadcrumb from '../../components/layout/Breadcrumb';
import SocialShare from '../../components/public/SocialShare';
import CommentSection from '../../components/public/CommentSection';
import RelatedArticles from '../../components/public/RelatedArticles';
import Spinner from '../../components/common/Spinner';

const ArticleDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [article, setArticle] = useState<Article | null>(null);
  const [relatedArticles, setRelatedArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (slug) {
      loadArticle();
    }
  }, [slug]);

  const loadArticle = async () => {
    setLoading(true);
    try {
      const data = await articleService.getArticleBySlug(slug!);
      setArticle(data);

      // Load related articles from same category
      if (data.category_id) {
        const relatedResponse = await articleService.getArticles(
          { category: data.category_id, status: 'published' },
          { page: 1, limit: 4 }
        );
        setRelatedArticles(relatedResponse.data);
      }
    } catch (error) {
      console.error('Error loading article:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Spinner size="lg" />
      </div>
    );
  }

  if (!article) {
    return (
      <div className="text-center py-20">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Artikel Tidak Ditemukan</h1>
        <p className="text-slate-600 mb-6">Artikel yang Anda cari tidak tersedia.</p>
        <Link to="/" className="text-blue-600 hover:text-blue-700 font-medium">
          Kembali ke Beranda
        </Link>
      </div>
    );
  }

  const currentUrl = window.location.href;

  return (
    <div className="space-y-8">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: 'Beranda', path: '/' },
          { label: article.category?.name || 'Artikel', path: `/category/${article.category?.slug}` },
          { label: article.title },
        ]}
      />

      {/* Article Header */}
      <article className="bg-white rounded-xl shadow-lg overflow-hidden">
        {/* Featured Image */}
        {article.featured_image && (
          <div className="aspect-[21/9] bg-slate-100">
            <img
              src={article.featured_image}
              alt={article.title}
              className="w-full h-full object-cover"
            />
          </div>
        )}

        <div className="p-8 lg:p-12">
          {/* Category */}
          {article.category && (
            <Link
              to={`/category/${article.category.slug}`}
              className="inline-block px-3 py-1 bg-blue-100 text-blue-700 text-sm font-bold rounded-full mb-4 hover:bg-blue-200 transition"
            >
              {article.category.name}
            </Link>
          )}

          {/* Title */}
          <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-4">
            {article.title}
          </h1>

          {/* Excerpt */}
          {article.excerpt && (
            <p className="text-xl text-slate-600 mb-6">{article.excerpt}</p>
          )}

          {/* Meta Info */}
          <div className="flex flex-wrap items-center gap-6 text-sm text-slate-600 mb-6 pb-6 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <User size={18} />
              <span>{article.author?.full_name || 'Admin'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock size={18} />
              <span>{formatDate(article.published_at || article.created_at)}</span>
            </div>
            {article.views !== undefined && (
              <div className="flex items-center gap-2">
                <Eye size={18} />
                <span>{article.views} views</span>
              </div>
            )}
          </div>

          {/* Social Share */}
          <div className="mb-8">
            <SocialShare
              url={currentUrl}
              title={article.title}
              description={article.excerpt}
            />
          </div>

          {/* Content */}
          <div
            className="prose prose-lg max-w-none mb-8"
            dangerouslySetInnerHTML={{ __html: article.content }}
          />

          {/* Tags */}
          {article.tags && article.tags.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 pt-6 border-t border-slate-200">
              <TagIcon size={18} className="text-slate-400" />
              {article.tags.map((tag) => (
                <span
                  key={tag.id}
                  className="px-3 py-1 rounded-full text-sm font-medium text-white"
                  style={{ backgroundColor: tag.color || '#3B82F6' }}
                >
                  {tag.name}
                </span>
              ))}
            </div>
          )}
        </div>
      </article>

      {/* Related Articles */}
      {relatedArticles.length > 0 && (
        <RelatedArticles articles={relatedArticles} currentArticleId={article.id} />
      )}

      {/* Comments */}
      <CommentSection articleId={article.id} />
    </div>
  );
};

export default ArticleDetailPage;
import React from 'react';
import { Users, Target, Award, Heart } from 'lucide-react';
import Breadcrumb from '../../components/layout/Breadcrumb';

const AboutPage: React.FC = () => {
  const values = [
    {
      icon: <Target size={32} />,
      title: 'Akurat & Terpercaya',
      description: 'Menyajikan berita yang akurat, berimbang, dan dapat dipertanggungjawabkan.',
    },
    {
      icon: <Users size={32} />,
      title: 'Independen',
      description: 'Bebas dari kepentingan politik dan komersial dalam pemberitaan.',
    },
    {
      icon: <Award size={32} />,
      title: 'Profesional',
      description: 'Mengedepankan etika jurnalistik dan standar profesional tinggi.',
    },
    {
      icon: <Heart size={32} />,
      title: 'Peduli Masyarakat',
      description: 'Mengangkat isu-isu yang penting bagi masyarakat Jakarta.',
    },
  ];

  const team = [
    {
      name: 'Ahmad Wijaya',
      role: 'Pemimpin Redaksi',
      image: 'https://ui-avatars.com/api/?name=Ahmad+Wijaya&size=200',
    },
    {
      name: 'Siti Nurhaliza',
      role: 'Editor Senior',
      image: 'https://ui-avatars.com/api/?name=Siti+Nurhaliza&size=200',
    },
    {
      name: 'Budi Santoso',
      role: 'Reporter Senior',
      image: 'https://ui-avatars.com/api/?name=Budi+Santoso&size=200',
    },
    {
      name: 'Dewi Lestari',
      role: 'Fotografer',
      image: 'https://ui-avatars.com/api/?name=Dewi+Lestari&size=200',
    },
  ];

  return (
    <div className="space-y-12">
      {/* Breadcrumb */}
      <Breadcrumb
        items={[
          { label: 'Beranda', path: '/' },
          { label: 'Tentang Kami' },
        ]}
      />

      {/* Hero Section */}
      <div className="bg-white rounded-xl shadow-lg p-8 lg:p-12">
        <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
          Tentang Lintas DKI
        </h1>
        <p className="text-xl text-slate-600 leading-relaxed mb-6">
          Lintas DKI adalah portal berita terpercaya yang menyajikan informasi terkini seputar
          Jakarta dan sekitarnya. Kami berkomitmen untuk memberikan berita yang akurat,
          berimbang, dan dapat dipertanggungjawabkan kepada masyarakat.
        </p>
        <p className="text-lg text-slate-600 leading-relaxed">
          Sejak didirikan, kami telah menjadi sumber informasi utama bagi warga Jakarta yang
          ingin mengetahui perkembangan terkini di ibu kota. Dengan tim jurnalis profesional
          dan berpengalaman, kami senantiasa menghadirkan berita yang relevan dan bermanfaat.
        </p>
      </div>

      {/* Vision & Mission */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl p-8 text-white">
          <h2 className="text-3xl font-bold mb-4">Visi</h2>
          <p className="text-lg text-blue-100 leading-relaxed">
            Menjadi portal berita digital terdepan dan terpercaya di Jakarta yang memberikan
            informasi berkualitas untuk mencerdaskan masyarakat.
          </p>
        </div>
        <div className="bg-gradient-to-br from-slate-700 to-slate-800 rounded-xl p-8 text-white">
          <h2 className="text-3xl font-bold mb-4">Misi</h2>
          <ul className="space-y-2 text-lg text-slate-100">
            <li>• Menyajikan berita yang akurat dan terpercaya</li>
            <li>• Mengangkat isu-isu penting bagi masyarakat</li>
            <li>• Menjaga independensi dan profesionalisme</li>
            <li>• Memanfaatkan teknologi untuk jangkauan luas</li>
          </ul>
        </div>
      </div>

      {/* Values */}
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Nilai-Nilai Kami</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((value, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-slate-200 p-6 text-center hover:shadow-lg transition"
            >
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 text-blue-600">
                {value.icon}
              </div>
              <h3 className="font-bold text-slate-900 mb-2">{value.title}</h3>
              <p className="text-sm text-slate-600">{value.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Team */}
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-8 text-center">Tim Kami</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {team.map((member, index) => (
            <div
              key={index}
              className="bg-white rounded-xl border border-slate-200 overflow-hidden hover:shadow-lg transition"
            >
              <img
                src={member.image}
                alt={member.name}
                className="w-full aspect-square object-cover"
              />
              <div className="p-4 text-center">
                <h3 className="font-bold text-slate-900 mb-1">{member.name}</h3>
                <p className="text-sm text-slate-600">{member.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div>
            <p className="text-4xl font-bold text-blue-600 mb-2">10+</p>
            <p className="text-slate-600">Tahun Pengalaman</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-blue-600 mb-2">50+</p>
            <p className="text-slate-600">Jurnalis Profesional</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-blue-600 mb-2">1M+</p>
            <p className="text-slate-600">Pembaca Bulanan</p>
          </div>
          <div>
            <p className="text-4xl font-bold text-blue-600 mb-2">10K+</p>
            <p className="text-slate-600">Artikel Diterbitkan</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;
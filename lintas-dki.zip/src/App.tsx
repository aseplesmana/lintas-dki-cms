import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import ProtectedRoute from './components/auth/ProtectedRoute';
import AdminLayout from './components/layout/AdminLayout';
import PublicLayout from './components/layout/PublicLayout';
import ErrorBoundary from './components/ErrorBoundary';

// Auth Pages
import LoginPage from './pages/auth/LoginPage';
import SignupPage from './pages/auth/SignupPage';
import ResetPasswordPage from './pages/auth/ResetPasswordPage';

// Admin Pages
import DashboardPage from './pages/admin/DashboardPage';
import ArticleManagementPage from './pages/admin/ArticleManagementPage';
import ArticleEditorPage from './pages/admin/ArticleEditorPage';
import ReportsPage from './pages/admin/ReportsPage';
import CreateReportPage from './pages/admin/CreateReportPage';
import EditReportPage from './pages/admin/EditReportPage';
import ReportDetailPage from './pages/admin/ReportDetailPage';
import CategoriesPage from './pages/admin/CategoriesPage';
import TagsPage from './pages/admin/TagsPage';
import MediaPage from './pages/admin/MediaPage';
import MonitoringPage from './pages/admin/MonitoringPage';
import SettingsPage from './pages/admin/SettingsPage';
import UsersPage from './pages/admin/UsersPage';

// Public Pages
import HomePage from './pages/public/HomePage';
import ArticleDetailPage from './pages/public/ArticleDetailPage';
import CategoryPage from './pages/public/CategoryPage';
import SearchPage from './pages/public/SearchPage';
import AboutPage from './pages/public/AboutPage';
import ContactPage from './pages/public/ContactPage';

// 404 Page
import NotFoundPage from './pages/NotFoundPage';

function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            {/* Auth Routes */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />

            {/* Public Routes */}
            <Route path="/" element={<PublicLayout />}>
              <Route index element={<HomePage />} />
              <Route path="article/:slug" element={<ArticleDetailPage />} />
              <Route path="category/:slug" element={<CategoryPage />} />
              <Route path="search" element={<SearchPage />} />
              <Route path="about" element={<AboutPage />} />
              <Route path="contact" element={<ContactPage />} />
            </Route>

            {/* Protected Admin Routes */}
            <Route
              path="/admin"
              element={
                <ProtectedRoute>
                  <AdminLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<Navigate to="/admin/dashboard" replace />} />
              <Route path="dashboard" element={<DashboardPage />} />
              
              {/* Articles */}
              <Route path="articles" element={<ArticleManagementPage />} />
              <Route path="articles/new" element={<ArticleEditorPage />} />
              <Route path="articles/:id/edit" element={<ArticleEditorPage />} />
              
              {/* Reports */}
              <Route path="reports" element={<ReportsPage />} />
              <Route path="reports/new" element={<CreateReportPage />} />
              <Route path="reports/:id" element={<ReportDetailPage />} />
              <Route path="reports/:id/edit" element={<EditReportPage />} />

              {/* Categories & Tags */}
              <Route path="categories" element={<CategoriesPage />} />
              <Route path="tags" element={<TagsPage />} />

              {/* Media */}
              <Route path="media" element={<MediaPage />} />

              {/* Monitoring */}
              <Route path="monitoring" element={<MonitoringPage />} />

              {/* Settings */}
              <Route path="settings" element={<SettingsPage />} />

              {/* Users */}
              <Route path="users" element={<UsersPage />} />
            </Route>

            {/* 404 Not Found */}
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}

export default App;
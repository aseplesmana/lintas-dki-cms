export interface MediaFile {
  id: string;
  name: string;
  path: string;
  url: string;
  type: string;
  size: number;
  uploaded_by: string;
  created_at: string;
  metadata?: Record<string, unknown>;
}

export interface UploadMediaDTO {
  file: File;
  folder?: string;
}

export interface MediaFilters {
  search?: string;
  type?: string;
}
export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  parent_id?: string;
  order?: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  article_count?: number;
  parent?: Category;
  color?: string;
  icon?: string;
}

export interface CreateCategoryDTO {
  name: string;
  slug: string;
  description?: string;
  parent_id?: string;
  order?: number;
  is_active?: boolean;
}

export interface UpdateCategoryDTO {
  name?: string;
  slug?: string;
  description?: string;
  parent_id?: string;
  order?: number;
  is_active?: boolean;
}

export interface CategoryFilters {
  search?: string;
  parent_id?: string;
  is_active?: boolean;
}
export type AIGenerationType = 'article' | 'summary' | 'classification' | 'report' | 'assistant';

export interface AIGeneration {
  id: string;
  user_id?: string;
  generation_type: AIGenerationType;
  input_prompt: string;
  output_content: string;
  model_used: string;
  tokens_used: number;
  cost: number;
  metadata: Record<string, any>;
  created_at: string;
}

export interface GenerateArticleParams {
  topic: string;
  category: string;
  keywords?: string[];
  tone?: 'formal' | 'informal';
  length?: 'short' | 'medium' | 'long';
}

export interface GenerateArticleResponse {
  title: string;
  content: string;
  excerpt: string;
  suggestedTags: string[];
  metadata: {
    wordCount: number;
    readingTime: number;
  };
}

export interface SummarizeParams {
  content: string;
  maxLength?: number;
  style?: 'bullet_points' | 'paragraph' | 'executive';
}

export interface SummarizeResponse {
  summary: string;
  keyPoints: string[];
  originalLength: number;
  summaryLength: number;
  compressionRatio: number;
}

export interface ClassifyParams {
  title: string;
  content: string;
  categories?: string[];
}

export interface ClassifyResponse {
  category: string;
  confidence: number;
  reasoning: string;
  suggestedTags: string[];
  sentiment?: 'positive' | 'neutral' | 'negative';
}

export interface GenerateReportParams {
  template: 'investigation' | 'analysis' | 'breaking';
  date: string;
  articles: any[];
  piketNames?: string[];
}

export interface GenerateReportResponse {
  title: string;
  content: string;
  sections: Record<string, string>;
  wordCount: number;
}

export interface ChatParams {
  message: string;
  context?: string[];
}

export interface ChatResponse {
  reply: string;
  suggestions?: string[];
}
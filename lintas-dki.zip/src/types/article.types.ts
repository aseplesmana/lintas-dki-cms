import { Status } from './common.types';
import { Category } from './category.types';
import { Tag } from './tag.types';
import { User } from './user.types';

export interface Article {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt?: string;
  category_id?: string;
  author_id?: string;
  featured_image?: string;
  status: Status;
  published_at?: string;
  scheduled_at?: string;
  views: number;
  is_featured: boolean;
  meta_title?: string;
  meta_description?: string;
  created_at: string;
  updated_at: string;
  
  // Relations
  category?: Category;
  author?: User;
  tags?: Tag[];
}

export interface CreateArticleDTO {
  title: string;
  slug: string;
  content: string;
  excerpt?: string;
  category_id?: string;
  featured_image?: string;
  status?: Status;
  published_at?: string;
  scheduled_at?: string;
  is_featured?: boolean;
  meta_title?: string;
  meta_description?: string;
  tags?: string[];
}

export interface UpdateArticleDTO extends Partial<CreateArticleDTO> {
  id: string;
}

export interface ArticleFilters {
  search?: string;
  category?: string;
  status?: Status;
  author?: string;
  is_featured?: boolean;
  startDate?: string;
  endDate?: string;
}
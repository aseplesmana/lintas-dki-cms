export type SentimentType = 'positive' | 'neutral' | 'negative';
export type SourceType = 'website' | 'instagram' | 'facebook' | 'twitter' | 'tiktok';

export interface MediaMonitoring {
  id: string;
  source_name: string;
  source_url: string;
  source_type: SourceType;
  title: string;
  content?: string;
  published_date?: string;
  scraped_at: string;
  category_id?: string;
  sentiment: SentimentType;
  is_processed: boolean;
  created_at: string;
}

export interface CreateMonitoringDTO {
  source_name: string;
  source_url: string;
  source_type: SourceType;
  title: string;
  content?: string;
  published_date?: string;
  category_id?: string;
  sentiment?: SentimentType;
}

export interface MonitoringFilters {
  source_type?: SourceType;
  source_name?: string;
  category?: string;
  sentiment?: SentimentType;
  is_processed?: boolean;
  startDate?: string;
  endDate?: string;
}

export interface MonitoringSource {
  name: string;
  url: string;
  category: string;
}
export type Status = 'draft' | 'published' | 'scheduled' | 'archived';

export type UserRole = 'admin' | 'editor';

export interface PaginationParams {
  page: number;
  limit: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

export interface FilterParams {
  search?: string;
  category?: string;
  status?: Status;
  startDate?: string;
  endDate?: string;
  author?: string;
}

export interface SortParams {
  field: string;
  order: 'asc' | 'desc';
}
import { UserRole } from './common.types';

export interface User {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  avatar_url?: string;
  created_at: string;
  updated_at: string;
  last_login?: string;
}

export interface CreateUserDTO {
  email: string;
  password: string;
  full_name: string;
  role?: UserRole;
}

export interface UpdateUserDTO {
  full_name?: string;
  avatar_url?: string;
  role?: UserRole;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface AuthState {
  user: User | null;
  loading: boolean;
  error: string | null;
}
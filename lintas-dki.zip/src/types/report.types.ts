import { Status } from './common.types';
import { Category } from './category.types';
import { User } from './user.types';

export type ReportType = 'investigation' | 'analysis' | 'breaking';
export type ReportPriority = 'low' | 'medium' | 'high' | 'urgent';
export type ReportTemplate = 'investigation' | 'analysis' | 'breaking';

export interface Report {
  id: string;
  title: string;
  slug: string;
  content: string;
  summary?: string;
  category_id?: string;
  author_id?: string;
  report_type: ReportType;
  featured_image?: string;
  status: Status;
  published_at?: string;
  priority: ReportPriority;
  source_urls: string[];
  report_date: string;
  piket_names: string[];
  template?: ReportTemplate;
  article_ids?: string[];
  articles?: any[];
  issues_count?: number;
  metadata?: Record<string, any>;
  created_at: string;
  updated_at: string;
  
  // Relations
  category?: Category;
  author?: User;
}

export interface CreateReportDTO {
  title: string;
  slug: string;
  content: string;
  summary?: string;
  category_id?: string;
  report_type?: ReportType;
  featured_image?: string;
  status?: Status;
  published_at?: string;
  priority?: ReportPriority;
  source_urls?: string[];
  report_date?: string;
  piket_names?: string[];
  template?: ReportTemplate;
  article_ids?: string[];
  issues_count?: number;
  metadata?: Record<string, any>;
}

export interface UpdateReportDTO extends Partial<CreateReportDTO> {
  id: string;
}

export interface ReportFilters {
  search?: string;
  report_type?: string;
  priority?: string;
  template?: string;
  startDate?: string;
  endDate?: string;
}

export interface ReportItem {
  time: string;
  source: string;
  mediaType: string;
  content: string;
  link: string;
}

export interface ReportSection {
  category: string;
  items: ReportItem[];
}

export interface GenerateReportParams {
  date: string;
  articles?: Article[];
  piketNames?: string[];
}

interface Article {
  title: string;
  category: string;
  source: string;
  mediaType: string;
  time: string;
  summary: string;
  content?: string;
  link: string;
  date: string;
}
export interface Tag {
  id: string;
  name: string;
  slug: string;
  color?: string;
  created_at: string;
  updated_at: string;
  article_count?: number;
}

export interface CreateTagDTO {
  name: string;
  slug: string;
  color?: string;
}

export interface UpdateTagDTO {
  name?: string;
  slug?: string;
  color?: string;
}

export interface TagFilters {
  search?: string;
}
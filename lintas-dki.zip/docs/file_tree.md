# File Structure - Lintas DKI CMS

```
lintas-dki/
├── public/
│   ├── favicon.ico
│   ├── logo.png
│   └── robots.txt
│
├── src/
│   ├── assets/
│   │   ├── images/
│   │   │   ├── placeholder-article.jpg
│   │   │   ├── placeholder-user.jpg
│   │   │   └── logo-full.png
│   │   └── icons/
│   │       ├── category-politik.svg
│   │       ├── category-ekonomi.svg
│   │       ├── category-hankam.svg
│   │       └── category-sosbud.svg
│   │
│   ├── components/
│   │   ├── common/
│   │   │   ├── Button.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Textarea.tsx
│   │   │   ├── Select.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── Toast.tsx
│   │   │   ├── Spinner.tsx
│   │   │   ├── Badge.tsx
│   │   │   ├── Card.tsx
│   │   │   ├── Dropdown.tsx
│   │   │   ├── Pagination.tsx
│   │   │   ├── SearchBar.tsx
│   │   │   ├── ConfirmDialog.tsx
│   │   │   └── EmptyState.tsx
│   │   │
│   │   ├── layout/
│   │   │   ├── Header.tsx
│   │   │   ├── Footer.tsx
│   │   │   ├── Sidebar.tsx
│   │   │   ├── MainLayout.tsx
│   │   │   ├── AdminLayout.tsx
│   │   │   └── AuthLayout.tsx
│   │   │
│   │   ├── auth/
│   │   │   ├── LoginForm.tsx
│   │   │   ├── SignupForm.tsx
│   │   │   ├── ResetPasswordForm.tsx
│   │   │   ├── ProfileForm.tsx
│   │   │   └── ProtectedRoute.tsx
│   │   │
│   │   ├── article/
│   │   │   ├── ArticleCard.tsx
│   │   │   ├── ArticleList.tsx
│   │   │   ├── ArticleGrid.tsx
│   │   │   ├── ArticleDetail.tsx
│   │   │   ├── ArticleEditor.tsx
│   │   │   ├── ArticleForm.tsx
│   │   │   ├── ArticlePreview.tsx
│   │   │   ├── ArticleFilters.tsx
│   │   │   ├── RelatedArticles.tsx
│   │   │   └── FeaturedArticle.tsx
│   │   │
│   │   ├── report/
│   │   │   ├── ReportCard.tsx
│   │   │   ├── ReportList.tsx
│   │   │   ├── ReportDetail.tsx
│   │   │   ├── ReportEditor.tsx
│   │   │   ├── ReportForm.tsx
│   │   │   ├── ReportFilters.tsx
│   │   │   └── ReportTemplateSelector.tsx
│   │   │
│   │   ├── category/
│   │   │   ├── CategoryCard.tsx
│   │   │   ├── CategoryList.tsx
│   │   │   ├── CategoryFilter.tsx
│   │   │   ├── CategoryForm.tsx
│   │   │   └── CategoryBadge.tsx
│   │   │
│   │   ├── tag/
│   │   │   ├── TagInput.tsx
│   │   │   ├── TagList.tsx
│   │   │   ├── TagCloud.tsx
│   │   │   └── TagBadge.tsx
│   │   │
│   │   ├── media/
│   │   │   ├── ImageUploader.tsx
│   │   │   ├── ImageGallery.tsx
│   │   │   ├── MediaLibrary.tsx
│   │   │   └── ImageCropper.tsx
│   │   │
│   │   ├── ai/
│   │   │   ├── AIPanel.tsx
│   │   │   ├── ArticleGenerator.tsx
│   │   │   ├── ContentSummarizer.tsx
│   │   │   ├── IssueClassifier.tsx
│   │   │   ├── ReportGenerator.tsx
│   │   │   ├── AIAssistant.tsx
│   │   │   ├── AIGenerationHistory.tsx
│   │   │   ├── TokenUsageDisplay.tsx
│   │   │   └── AILoadingState.tsx
│   │   │
│   │   ├── monitoring/
│   │   │   ├── MonitoringList.tsx
│   │   │   ├── MonitoringCard.tsx
│   │   │   ├── MonitoringFilters.tsx
│   │   │   ├── SourceManager.tsx
│   │   │   └── SentimentBadge.tsx
│   │   │
│   │   ├── dashboard/
│   │   │   ├── DashboardStats.tsx
│   │   │   ├── RecentActivity.tsx
│   │   │   ├── QuickActions.tsx
│   │   │   ├── ContentChart.tsx
│   │   │   ├── ViewsChart.tsx
│   │   │   └── AIUsageChart.tsx
│   │   │
│   │   └── editor/
│   │       ├── RichTextEditor.tsx
│   │       ├── MarkdownEditor.tsx
│   │       ├── EditorToolbar.tsx
│   │       ├── EditorPreview.tsx
│   │       └── EditorSidebar.tsx
│   │
│   ├── contexts/
│   │   ├── AuthContext.tsx
│   │   ├── ArticleContext.tsx
│   │   ├── ReportContext.tsx
│   │   ├── CategoryContext.tsx
│   │   ├── TagContext.tsx
│   │   ├── AIContext.tsx
│   │   ├── MonitoringContext.tsx
│   │   └── ToastContext.tsx
│   │
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useArticles.ts
│   │   ├── useReports.ts
│   │   ├── useCategories.ts
│   │   ├── useTags.ts
│   │   ├── useAI.ts
│   │   ├── useMonitoring.ts
│   │   ├── useStorage.ts
│   │   ├── useDebounce.ts
│   │   ├── useLocalStorage.ts
│   │   ├── useMediaQuery.ts
│   │   └── useInfiniteScroll.ts
│   │
│   ├── services/
│   │   ├── supabase/
│   │   │   ├── client.ts
│   │   │   ├── auth.service.ts
│   │   │   ├── article.service.ts
│   │   │   ├── report.service.ts
│   │   │   ├── category.service.ts
│   │   │   ├── tag.service.ts
│   │   │   ├── storage.service.ts
│   │   │   └── monitoring.service.ts
│   │   │
│   │   ├── ai/
│   │   │   ├── ai.service.ts
│   │   │   ├── openai.client.ts
│   │   │   ├── anthropic.client.ts
│   │   │   └── ai.types.ts
│   │   │
│   │   └── api/
│   │       ├── api.client.ts
│   │       ├── api.types.ts
│   │       └── api.utils.ts
│   │
│   ├── utils/
│   │   ├── date.utils.ts
│   │   ├── string.utils.ts
│   │   ├── slug.utils.ts
│   │   ├── validation.utils.ts
│   │   ├── format.utils.ts
│   │   ├── storage.utils.ts
│   │   └── error.utils.ts
│   │
│   ├── types/
│   │   ├── user.types.ts
│   │   ├── article.types.ts
│   │   ├── report.types.ts
│   │   ├── category.types.ts
│   │   ├── tag.types.ts
│   │   ├── monitoring.types.ts
│   │   ├── ai.types.ts
│   │   └── common.types.ts
│   │
│   ├── constants/
│   │   ├── routes.ts
│   │   ├── api.constants.ts
│   │   ├── app.constants.ts
│   │   └── validation.constants.ts
│   │
│   ├── styles/
│   │   ├── globals.css
│   │   ├── tailwind.css
│   │   └── editor.css
│   │
│   ├── pages/
│   │   ├── public/
│   │   │   ├── HomePage.tsx
│   │   │   ├── ArticleListPage.tsx
│   │   │   ├── ArticleDetailPage.tsx
│   │   │   ├── ReportListPage.tsx
│   │   │   ├── ReportDetailPage.tsx
│   │   │   ├── CategoryPage.tsx
│   │   │   ├── SearchPage.tsx
│   │   │   └── NotFoundPage.tsx
│   │   │
│   │   ├── auth/
│   │   │   ├── LoginPage.tsx
│   │   │   ├── SignupPage.tsx
│   │   │   └── ResetPasswordPage.tsx
│   │   │
│   │   └── admin/
│   │       ├── DashboardPage.tsx
│   │       ├── ArticleManagementPage.tsx
│   │       ├── ArticleEditorPage.tsx
│   │       ├── ReportManagementPage.tsx
│   │       ├── ReportEditorPage.tsx
│   │       ├── MediaMonitoringPage.tsx
│   │       ├── AIToolsPage.tsx
│   │       ├── CategoryManagementPage.tsx
│   │       ├── UserManagementPage.tsx
│   │       ├── ProfilePage.tsx
│   │       └── SettingsPage.tsx
│   │
│   ├── routes/
│   │   ├── index.tsx
│   │   ├── PublicRoutes.tsx
│   │   ├── AdminRoutes.tsx
│   │   └── AuthRoutes.tsx
│   │
│   ├── App.tsx
│   ├── main.tsx
│   └── vite-env.d.ts
│
├── supabase/
│   ├── migrations/
│   │   ├── 20250101000000_initial_schema.sql
│   │   ├── 20250101000001_create_users_table.sql
│   │   ├── 20250101000002_create_categories_table.sql
│   │   ├── 20250101000003_create_articles_table.sql
│   │   ├── 20250101000004_create_reports_table.sql
│   │   ├── 20250101000005_create_tags_table.sql
│   │   ├── 20250101000006_create_article_tags_table.sql
│   │   ├── 20250101000007_create_media_monitoring_table.sql
│   │   ├── 20250101000008_create_ai_generations_table.sql
│   │   ├── 20250101000009_create_rls_policies.sql
│   │   └── 20250101000010_create_indexes.sql
│   │
│   ├── functions/
│   │   ├── ai-generate-article/
│   │   │   ├── index.ts
│   │   │   └── deno.json
│   │   ├── ai-summarize/
│   │   │   ├── index.ts
│   │   │   └── deno.json
│   │   ├── ai-classify/
│   │   │   ├── index.ts
│   │   │   └── deno.json
│   │   ├── ai-generate-report/
│   │   │   ├── index.ts
│   │   │   └── deno.json
│   │   ├── ai-chat/
│   │   │   ├── index.ts
│   │   │   └── deno.json
│   │   ├── media-scrape/
│   │   │   ├── index.ts
│   │   │   └── deno.json
│   │   └── media-process/
│   │       ├── index.ts
│   │       └── deno.json
│   │
│   ├── seed/
│   │   ├── seed.sql
│   │   └── sample-data.sql
│   │
│   └── config.toml
│
├── docs/
│   ├── prd.md
│   ├── system_design.md
│   ├── architect.plantuml
│   ├── class_diagram.plantuml
│   ├── sequence_diagram.plantuml
│   ├── er_diagram.plantuml
│   ├── ui_navigation.plantuml
│   ├── file_tree.md
│   ├── api-documentation.md
│   ├── deployment-guide.md
│   └── user-manual.md
│
├── tests/
│   ├── unit/
│   │   ├── components/
│   │   ├── hooks/
│   │   ├── services/
│   │   └── utils/
│   │
│   ├── integration/
│   │   ├── auth.test.ts
│   │   ├── article.test.ts
│   │   ├── report.test.ts
│   │   └── ai.test.ts
│   │
│   └── e2e/
│       ├── auth.spec.ts
│       ├── article-creation.spec.ts
│       ├── report-creation.spec.ts
│       └── ai-generation.spec.ts
│
├── .env.example
├── .env.local
├── .gitignore
├── .eslintrc.json
├── .prettierrc
├── package.json
├── package-lock.json
├── tsconfig.json
├── tsconfig.node.json
├── vite.config.ts
├── tailwind.config.js
├── postcss.config.js
├── playwright.config.ts
└── README.md
```

## Key Directories Explanation

### `/src/components/`
Organized by feature and reusability:
- **common/**: Reusable UI components (buttons, inputs, modals)
- **layout/**: Layout components (header, footer, sidebar)
- **auth/**: Authentication-related components
- **article/**: Article-specific components
- **report/**: Report-specific components
- **ai/**: AI tools components
- **monitoring/**: Media monitoring components
- **dashboard/**: Dashboard widgets
- **editor/**: Rich text editor components

### `/src/contexts/`
React Context providers untuk global state management

### `/src/hooks/`
Custom React hooks untuk reusable logic

### `/src/services/`
Service layer untuk external API calls:
- **supabase/**: Supabase database operations
- **ai/**: AI service integrations (OpenAI, Anthropic)
- **api/**: Generic API client utilities

### `/src/utils/`
Utility functions untuk common operations

### `/src/types/`
TypeScript type definitions dan interfaces

### `/src/pages/`
Page components organized by access level:
- **public/**: Public-facing pages
- **auth/**: Authentication pages
- **admin/**: Protected admin pages

### `/supabase/`
Supabase-specific files:
- **migrations/**: Database schema migrations
- **functions/**: Edge Functions untuk AI dan scraping
- **seed/**: Sample data untuk development

### `/docs/`
Project documentation:
- Architecture diagrams (PlantUML)
- API documentation
- User manuals
- Deployment guides

### `/tests/`
Test files organized by type:
- **unit/**: Unit tests untuk components, hooks, services
- **integration/**: Integration tests untuk features
- **e2e/**: End-to-end tests dengan Playwright

## File Naming Conventions

- **Components**: PascalCase (e.g., `ArticleCard.tsx`)
- **Hooks**: camelCase dengan `use` prefix (e.g., `useArticles.ts`)
- **Services**: camelCase dengan `.service` suffix (e.g., `article.service.ts`)
- **Utils**: camelCase dengan `.utils` suffix (e.g., `date.utils.ts`)
- **Types**: camelCase dengan `.types` suffix (e.g., `article.types.ts`)
- **Constants**: camelCase (e.g., `routes.ts`)
- **Pages**: PascalCase dengan `Page` suffix (e.g., `HomePage.tsx`)

## Import Path Aliases

Configure in `tsconfig.json`:
```json
{
  "compilerOptions": {
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"],
      "@components/*": ["src/components/*"],
      "@hooks/*": ["src/hooks/*"],
      "@services/*": ["src/services/*"],
      "@utils/*": ["src/utils/*"],
      "@types/*": ["src/types/*"],
      "@constants/*": ["src/constants/*"],
      "@contexts/*": ["src/contexts/*"],
      "@pages/*": ["src/pages/*"]
    }
  }
}
```

## Scalability Considerations

1. **Component Organization**: Feature-based organization allows easy addition of new features
2. **Service Layer**: Abstraction allows easy switching of backend services
3. **Type Safety**: TypeScript ensures type safety across the application
4. **Testing Structure**: Organized test structure supports comprehensive testing
5. **Documentation**: Comprehensive documentation supports team collaboration
6. **Edge Functions**: Serverless functions allow independent scaling of AI operations
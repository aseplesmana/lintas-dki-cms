# System Design - Lintas DKI CMS dengan AI Integration

## 1. Implementation Approach

### 1.1 Teknologi Stack
**Frontend:**
- React 18.2 dengan Vite sebagai build tool
- TypeScript untuk type safety
- Tailwind CSS untuk styling
- React Router v6 untuk routing
- Context API untuk state management
- Lucide React untuk icons
- React Hook Form untuk form handling
- TanStack Query (React Query) untuk data fetching dan caching

**Backend & Infrastructure:**
- Supabase sebagai Backend-as-a-Service (BaaS)
  - PostgreSQL database dengan Row Level Security (RLS)
  - Supabase Auth untuk authentication
  - Supabase Storage untuk media files
  - Supabase Edge Functions untuk serverless API
  - Realtime subscriptions untuk live updates

**AI Integration:**
- OpenAI GPT-4 Turbo untuk:
  - Article generation
  - Issue classification
  - Report generation
- Anthropic Claude 3 Sonnet untuk:
  - Content summarization
  - AI assistant chat

**Development Tools:**
- ESLint untuk code quality
- Prettier untuk code formatting
- Playwright untuk E2E testing

### 1.2 Arsitektur Pattern
- **Frontend:** Component-based architecture dengan separation of concerns
- **State Management:** Context API dengan custom hooks
- **Data Layer:** Repository pattern untuk abstraksi Supabase operations
- **API Layer:** Edge Functions sebagai middleware untuk AI services
- **Security:** Row Level Security (RLS) policies di database level

### 1.3 Fitur Utama yang Akan Diimplementasikan

**Phase 1 - Core Infrastructure (Week 1-2):**
1. Setup Supabase project dan database schema
2. Implement authentication system dengan role-based access
3. Create base UI components dan layout
4. Setup routing dan protected routes

**Phase 2 - Content Management (Week 3-4):**
1. Article CRUD operations dengan rich text editor
2. Report CRUD operations dengan template support
3. Category dan tag management
4. Media upload dan management
5. Content preview dan publishing workflow

**Phase 3 - AI Integration (Week 5-6):**
1. AI article generator dengan customizable prompts
2. Content summarizer dengan multiple styles
3. Issue classifier dengan confidence scoring
4. Report generator dengan templates
5. AI assistant untuk admin support

**Phase 4 - Advanced Features (Week 7-8):**
1. Media monitoring dan scraping system
2. Analytics dashboard dengan statistics
3. Search functionality dengan full-text search
4. SEO optimization features
5. Performance optimization dan caching

### 1.4 Challenges & Solutions

**Challenge 1: AI Cost Management**
- Solution: Implement token tracking, usage limits per user, dan caching untuk repeated queries

**Challenge 2: Real-time Collaboration**
- Solution: Gunakan Supabase Realtime untuk live updates dan conflict resolution

**Challenge 3: Content Security**
- Solution: Implement comprehensive RLS policies dan input sanitization

**Challenge 4: Performance dengan Large Content**
- Solution: Implement pagination, lazy loading, dan CDN untuk media files

## 2. User & UI Interaction Behaviors

### 2.1 Public User Interactions
1. **Homepage Navigation:**
   - View featured articles dan breaking news
   - Browse articles by category (Politik, Ekonomi, Hankam, Sosbud)
   - Search articles dengan keyword
   - Click article untuk read full content

2. **Article Reading:**
   - Read full article dengan responsive layout
   - View related articles
   - Share article ke social media
   - View article metadata (author, date, category, tags)

3. **Report Browsing:**
   - Filter reports by type (Investigation, Analysis, Breaking)
   - Filter by priority level
   - Download report as PDF
   - View source links

### 2.2 Admin/Editor Interactions

**Authentication Flow:**
1. Login dengan email/password
2. Role-based redirect (Admin → Full Dashboard, Editor → Content Management)
3. Session management dengan auto-refresh

**Content Creation Flow:**
1. Navigate to "Create Article" atau "Create Report"
2. Choose to start from scratch atau use AI generator
3. If using AI:
   - Enter prompt dengan context
   - Select category, tone, dan length
   - Review generated content
   - Edit dan refine content
4. Fill in metadata (title, excerpt, category, tags)
5. Upload featured image
6. Preview content
7. Save as draft atau publish immediately

**AI Tools Interaction:**
1. **Article Generator:**
   - Open AI panel dari editor
   - Enter detailed prompt
   - Select parameters (category, tone, length)
   - Click "Generate"
   - Review generated content dengan preview
   - Apply to editor atau regenerate

2. **Content Summarizer:**
   - Paste atau select long content
   - Choose summary style (bullet points, paragraph, executive)
   - Set max length dengan slider
   - Click "Summarize"
   - Copy summary atau apply to excerpt field

3. **Issue Classifier:**
   - Paste news content
   - Click "Classify"
   - View classification result dengan confidence score
   - Review suggested tags
   - Apply classification to article

4. **Report Generator:**
   - Select report template (Investigation, Analysis, Breaking)
   - Fill in template parameters
   - Click "Generate"
   - Review structured report
   - Edit sections as needed
   - Apply to report editor

5. **AI Assistant:**
   - Open chat panel
   - Ask questions tentang content strategy, SEO, atau editorial guidelines
   - Get contextual suggestions
   - Apply suggestions to content

**Media Monitoring Flow:**
1. View list of scraped content dari external sources
2. Filter by source, category, atau sentiment
3. Select item untuk review
4. Click "Convert to Article"
5. AI automatically generates article based on monitored content
6. Review dan edit generated article
7. Publish atau save as draft

**Content Management Flow:**
1. View content list dengan filters (status, category, author, date)
2. Search content dengan keyword
3. Bulk actions (publish, archive, delete)
4. Sort by various criteria (date, views, status)
5. Quick edit dari list view
6. Full edit dengan editor

### 2.3 UI Feedback & Notifications
- Loading states untuk all async operations
- Success/error toasts untuk user actions
- Progress indicators untuk AI generation
- Real-time updates untuk collaborative editing
- Validation feedback untuk form inputs
- Confirmation dialogs untuk destructive actions

## 3. Data Structures and Interfaces Overview

### 3.1 Core Data Models

**User Model:**
```typescript
interface User {
  id: string;
  email: string;
  full_name: string;
  role: 'admin' | 'editor';
  avatar_url: string;
  created_at: Date;
  updated_at: Date;
  last_login: Date;
}
```

**Article Model:**
```typescript
interface Article {
  id: string;
  title: string;
  slug: string;
  content: string;
  excerpt: string;
  category_id: string;
  author_id: string;
  featured_image: string;
  status: 'draft' | 'published' | 'archived';
  published_at: Date;
  views: number;
  is_featured: boolean;
  meta_title: string;
  meta_description: string;
  created_at: Date;
  updated_at: Date;
  
  // Relations
  category?: Category;
  author?: User;
  tags?: Tag[];
}
```

**Report Model:**
```typescript
interface Report {
  id: string;
  title: string;
  slug: string;
  content: string;
  category_id: string;
  author_id: string;
  report_type: 'investigation' | 'analysis' | 'breaking';
  featured_image: string;
  status: 'draft' | 'published' | 'archived';
  published_at: Date;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  source_urls: string[];
  created_at: Date;
  updated_at: Date;
  
  // Relations
  category?: Category;
  author?: User;
}
```

**Category Model:**
```typescript
interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
  color: string;
  order: number;
  created_at: Date;
}
```

**Tag Model:**
```typescript
interface Tag {
  id: string;
  name: string;
  slug: string;
  usage_count: number;
  created_at: Date;
}
```

**MediaMonitoring Model:**
```typescript
interface MediaMonitoring {
  id: string;
  source_name: string;
  source_url: string;
  title: string;
  content: string;
  published_date: Date;
  scraped_at: Date;
  category_id: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  is_processed: boolean;
  created_at: Date;
}
```

**AIGeneration Model:**
```typescript
interface AIGeneration {
  id: string;
  user_id: string;
  generation_type: 'article' | 'summary' | 'classification' | 'report' | 'assistant';
  input_prompt: string;
  output_content: string;
  model_used: string;
  tokens_used: number;
  cost: number;
  created_at: Date;
  metadata: Record<string, any>;
}
```

### 3.2 Service Interfaces

**IAuthService:**
```typescript
interface IAuthService {
  signIn(email: string, password: string): Promise<User>;
  signUp(email: string, password: string, fullName: string): Promise<User>;
  signOut(): Promise<void>;
  getCurrentUser(): Promise<User | null>;
  updateProfile(userId: string, data: Partial<User>): Promise<User>;
  resetPassword(email: string): Promise<void>;
}
```

**IArticleService:**
```typescript
interface IArticleService {
  getArticles(filters: ArticleFilters): Promise<Article[]>;
  getArticleById(id: string): Promise<Article>;
  getArticleBySlug(slug: string): Promise<Article>;
  createArticle(data: CreateArticleDTO): Promise<Article>;
  updateArticle(id: string, data: UpdateArticleDTO): Promise<Article>;
  deleteArticle(id: string): Promise<void>;
  publishArticle(id: string): Promise<Article>;
  incrementViews(id: string): Promise<void>;
}
```

**IAIService:**
```typescript
interface IAIService {
  generateArticle(prompt: string, options: GenerateOptions): Promise<AIGenerationResult>;
  summarizeContent(content: string, maxLength: number, style: SummaryStyle): Promise<string>;
  classifyIssue(content: string, categories: string[]): Promise<ClassificationResult>;
  generateReport(template: string, data: any): Promise<string>;
  chatAssistant(message: string, context: string[]): Promise<string>;
}
```

### 3.3 Context Providers

**AuthContext:**
```typescript
interface AuthContextValue {
  user: User | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateUser: (data: Partial<User>) => Promise<void>;
}
```

**ArticleContext:**
```typescript
interface ArticleContextValue {
  articles: Article[];
  loading: boolean;
  error: string | null;
  fetchArticles: (filters: ArticleFilters) => Promise<void>;
  createArticle: (data: CreateArticleDTO) => Promise<void>;
  updateArticle: (id: string, data: UpdateArticleDTO) => Promise<void>;
  deleteArticle: (id: string) => Promise<void>;
}
```

**AIContext:**
```typescript
interface AIContextValue {
  generating: boolean;
  error: string | null;
  generateArticle: (prompt: string, options: GenerateOptions) => Promise<AIGenerationResult>;
  summarize: (content: string, options: SummarizeOptions) => Promise<string>;
  classify: (content: string) => Promise<ClassificationResult>;
  chatHistory: ChatMessage[];
  sendMessage: (message: string) => Promise<string>;
}
```

## 4. Program Call Flow Overview

### 4.1 Authentication Flow
1. User enters credentials di login form
2. Frontend calls `AuthService.signIn(email, password)`
3. AuthService calls Supabase Auth API
4. Supabase validates credentials dan returns session token
5. Frontend stores session di AuthContext
6. AuthContext updates user state
7. Router redirects based on user role
8. Protected routes check authentication status

### 4.2 Article Creation with AI Flow
1. Admin clicks "Create Article" → Navigate to editor
2. Admin clicks "Generate with AI" → Open AI panel
3. Admin enters prompt dan selects options
4. Frontend calls `AIService.generateArticle(prompt, options)`
5. AIService calls Edge Function `/ai/generate-article`
6. Edge Function calls OpenAI API dengan structured prompt
7. OpenAI returns generated content
8. Edge Function logs generation di `ai_generations` table
9. Frontend receives generated content
10. Admin reviews dan edits content di editor
11. Admin uploads featured image via `StorageService.uploadImage()`
12. Admin submits form
13. Frontend calls `ArticleService.createArticle(data)`
14. ArticleService inserts article di database dengan RLS check
15. ArticleService creates tag associations
16. Database returns created article
17. Frontend shows success message dan redirects

### 4.3 Content Summarization Flow
1. Editor pastes long content di summarizer panel
2. Editor selects summary style dan max length
3. Frontend calls `AIService.summarizeContent(content, options)`
4. AIService calls Edge Function `/ai/summarize`
5. Edge Function calls Anthropic Claude API
6. Claude returns summarized content
7. Edge Function logs generation
8. Frontend displays summary
9. Editor clicks "Apply to Excerpt"
10. Summary is inserted into article excerpt field

### 4.4 Media Monitoring Flow
1. Cron job triggers Edge Function `/media/scrape` every 30 minutes
2. Edge Function loops through monitored sources
3. For each source, fetch RSS/HTML content
4. Parse content dan extract articles
5. Call `AIService.classifyIssue()` untuk each article
6. Insert scraped content di `media_monitoring` table
7. Admin views monitored content di dashboard
8. Admin selects item dan clicks "Convert to Article"
9. Frontend calls `MediaMonitoringService.processMonitoredContent(id)`
10. Service calls `AIService.generateArticle()` based on monitored content
11. Service creates article di database
12. Service marks monitored item as processed
13. Frontend shows success dan navigates to article editor

### 4.5 Report Generation Flow
1. Admin selects report template
2. Admin fills template parameters
3. Frontend calls `AIService.generateReport(template, data)`
4. AIService calls Edge Function `/ai/generate-report`
5. Edge Function structures prompt based on template
6. Edge Function calls OpenAI API
7. OpenAI returns structured report
8. Edge Function logs generation
9. Frontend displays generated report
10. Admin reviews dan edits sections
11. Admin submits report
12. Frontend calls `ReportService.createReport(data)`
13. Database stores report dengan RLS check
14. Frontend shows success message

## 5. Database ER Diagram Overview

### 5.1 Core Tables

**users** (Managed by Supabase Auth)
- Primary Key: id (uuid)
- Unique: email
- Fields: full_name, role, avatar_url, timestamps
- Indexes: email, role, created_at

**categories**
- Primary Key: id (uuid)
- Unique: name, slug
- Fields: description, icon, color, order
- Indexes: slug, order

**articles**
- Primary Key: id (uuid)
- Foreign Keys: category_id → categories.id, author_id → users.id
- Unique: slug
- Fields: title, content, excerpt, featured_image, status, published_at, views, is_featured, meta fields
- Indexes: slug, category_id, author_id, status, published_at, is_featured, created_at
- Full-Text Search: title, content, excerpt

**reports**
- Primary Key: id (uuid)
- Foreign Keys: category_id → categories.id, author_id → users.id
- Unique: slug
- Fields: title, content, report_type, featured_image, status, priority, source_urls
- Indexes: slug, category_id, author_id, status, priority, published_at

**tags**
- Primary Key: id (uuid)
- Unique: name, slug
- Fields: usage_count
- Indexes: name, slug, usage_count

**article_tags** (Junction Table)
- Composite Primary Key: (article_id, tag_id)
- Foreign Keys: article_id → articles.id, tag_id → tags.id
- Indexes: article_id, tag_id

**media_monitoring**
- Primary Key: id (uuid)
- Foreign Key: category_id → categories.id
- Fields: source_name, source_url, title, content, published_date, scraped_at, sentiment, is_processed
- Indexes: source_name, category_id, is_processed, published_date, scraped_at

**ai_generations**
- Primary Key: id (uuid)
- Foreign Key: user_id → users.id
- Fields: generation_type, input_prompt, output_content, model_used, tokens_used, cost, metadata (jsonb)
- Indexes: user_id, generation_type, created_at

### 5.2 Relationships
- users 1:N articles (author relationship)
- users 1:N reports (author relationship)
- users 1:N ai_generations (tracking relationship)
- categories 1:N articles
- categories 1:N reports
- categories 1:N media_monitoring
- articles N:M tags (through article_tags)

### 5.3 Row Level Security (RLS) Policies

**articles table:**
- SELECT: Public can view published articles; Authors can view their own; Admins can view all
- INSERT: Authenticated users with editor/admin role
- UPDATE: Authors can update their own; Admins can update all
- DELETE: Admins only

**reports table:**
- SELECT: Public can view published reports; Authors can view their own; Admins can view all
- INSERT: Authenticated users with editor/admin role
- UPDATE: Authors can update their own; Admins can update all
- DELETE: Admins only

**users table:**
- SELECT: Users can view their own profile; Admins can view all
- UPDATE: Users can update their own profile; Admins can update all

**categories, tags:**
- SELECT: Public read access
- INSERT/UPDATE/DELETE: Admins only

**media_monitoring:**
- SELECT: Authenticated users only
- INSERT: System/Edge Functions only
- UPDATE: Authenticated users (mark as processed)
- DELETE: Admins only

**ai_generations:**
- SELECT: Users can view their own; Admins can view all
- INSERT: Authenticated users
- UPDATE/DELETE: Not allowed (audit log)

## 6. UI Navigation Flow

### 6.1 Navigation Hierarchy

**Level 1 - Main Navigation (Max depth: 3-4 levels)**
```
Home
├── Articles (by Category)
│   ├── Politik
│   ├── Ekonomi
│   ├── Hankam
│   └── Sosbud
├── Reports
│   ├── Investigation
│   ├── Analysis
│   └── Breaking
└── Search

Admin Dashboard (Protected)
├── Content Management
│   ├── Articles
│   │   ├── Create New
│   │   ├── Edit Existing
│   │   └── Drafts
│   └── Reports
│       ├── Create New
│       ├── Edit Existing
│       └── Drafts
├── AI Tools
│   ├── Article Generator
│   ├── Content Summarizer
│   ├── Issue Classifier
│   ├── Report Generator
│   └── AI Assistant
├── Media Monitoring
│   ├── Scraped Content
│   └── Process to Article
└── Settings
    ├── Profile
    ├── Categories
    └── Users (Admin only)
```

### 6.2 Navigation Principles
1. **Maximum 3-4 levels deep** - Prevent deep nesting
2. **Clear back navigation** - Always provide way back at every level
3. **Breadcrumbs** - Show current location for deep navigation
4. **Quick access** - High-frequency actions always visible (Create Article, AI Tools)
5. **Persistent header** - Main menu always accessible

### 6.3 High-Frequency Functions (Always Visible)
- Create New Article (floating action button)
- Generate with AI (quick access button)
- Search (persistent search bar)
- User profile menu (top-right corner)
- Notifications (real-time updates)

### 6.4 State Transitions
- Home → Article List → Article Detail → Back to List → Back to Home
- Dashboard → Content Management → Article Editor → AI Tools → Apply to Editor → Save → Back to Dashboard
- Dashboard → Media Monitoring → Convert to Article → Article Editor → Publish → Back to Dashboard

## 7. API Endpoints & Edge Functions

### 7.1 AI Edge Functions

**POST /ai/generate-article**
```typescript
Request: {
  prompt: string;
  category: string;
  tone: 'formal' | 'casual' | 'investigative';
  length: 'short' | 'medium' | 'long';
}
Response: {
  content: string;
  title: string;
  excerpt: string;
  suggested_tags: string[];
  metadata: {
    word_count: number;
    reading_time: number;
  };
}
```

**POST /ai/summarize**
```typescript
Request: {
  content: string;
  max_length: number;
  style: 'bullet_points' | 'paragraph' | 'executive';
}
Response: {
  summary: string;
  original_length: number;
  summary_length: number;
  compression_ratio: number;
}
```

**POST /ai/classify**
```typescript
Request: {
  content: string;
  categories: string[];
}
Response: {
  category: string;
  confidence: number;
  tags: string[];
  sentiment: 'positive' | 'neutral' | 'negative';
}
```

**POST /ai/generate-report**
```typescript
Request: {
  template: 'investigation' | 'analysis' | 'breaking';
  data: Record<string, any>;
}
Response: {
  title: string;
  content: string;
  sections: Record<string, string>;
  word_count: number;
}
```

**POST /ai/chat**
```typescript
Request: {
  message: string;
  context: string[];
}
Response: {
  reply: string;
  suggestions: string[];
}
```

### 7.2 Media Monitoring Edge Functions

**POST /media/scrape**
```typescript
Request: {
  source_url: string;
}
Response: {
  items: MediaMonitoring[];
  success_count: number;
  error_count: number;
}
```

**POST /media/process**
```typescript
Request: {
  monitoring_id: string;
}
Response: {
  article_id: string;
  article: Article;
}
```

## 8. Security Considerations

### 8.1 Authentication & Authorization
- JWT-based authentication via Supabase Auth
- Role-based access control (Admin, Editor)
- Session management dengan auto-refresh
- Secure password hashing (bcrypt)

### 8.2 Data Security
- Row Level Security (RLS) policies di database level
- Input sanitization untuk prevent XSS
- SQL injection prevention via parameterized queries
- CORS configuration untuk API endpoints

### 8.3 API Security
- Rate limiting untuk AI endpoints (prevent abuse)
- API key rotation untuk external services
- Request validation dengan Zod schemas
- Error handling tanpa expose sensitive info

### 8.4 Content Security
- Content moderation untuk user-generated content
- Image validation (file type, size, dimensions)
- Malware scanning untuk uploaded files
- CSP headers untuk prevent XSS

## 9. Performance Optimization

### 9.1 Frontend Performance
- Code splitting dengan React.lazy()
- Image optimization dengan lazy loading
- Memoization dengan React.memo() dan useMemo()
- Virtual scrolling untuk long lists
- Service Worker untuk offline support

### 9.2 Backend Performance
- Database indexing untuk frequently queried fields
- Query optimization dengan proper joins
- Caching dengan Redis (future enhancement)
- CDN untuk static assets dan media files
- Connection pooling untuk database

### 9.3 AI Performance
- Response caching untuk repeated queries
- Streaming responses untuk long generations
- Token usage optimization
- Batch processing untuk multiple requests

## 10. Monitoring & Analytics

### 10.1 Application Monitoring
- Error tracking dengan Sentry (future)
- Performance monitoring dengan Web Vitals
- User analytics dengan Google Analytics
- Real-time monitoring dashboard

### 10.2 AI Usage Tracking
- Token usage per user/generation
- Cost tracking per AI operation
- Generation success/failure rates
- Model performance metrics

### 10.3 Content Analytics
- Article views dan engagement
- Popular categories dan tags
- User behavior tracking
- Content performance metrics

## 11. Deployment Strategy

### 11.1 Environment Setup
- Development: Local Supabase instance
- Staging: Supabase staging project
- Production: Supabase production project

### 11.2 CI/CD Pipeline
- GitHub Actions untuk automated testing
- Automated deployment ke Vercel/Netlify
- Database migration scripts
- Environment variable management

### 11.3 Rollback Strategy
- Database backup before migrations
- Feature flags untuk gradual rollout
- Blue-green deployment untuk zero downtime
- Monitoring alerts untuk quick detection

## 12. Unclear Aspects & Assumptions

### 12.1 Assumptions Made
1. **AI Model Selection:** Assumed OpenAI GPT-4 Turbo dan Anthropic Claude 3 Sonnet based on best performance/cost ratio. User may prefer different models.

2. **Content Moderation:** Assumed basic content validation. May need advanced moderation for sensitive political content.

3. **Media Monitoring Sources:** Assumed RSS feeds. May need custom scrapers untuk sources without RSS.

4. **Concurrent Users:** Assumed small to medium traffic (< 1000 concurrent users). May need scaling strategy untuk higher traffic.

5. **AI Cost Budget:** Assumed reasonable budget untuk AI operations. May need cost controls dan limits.

6. **Report Templates:** Assumed 3 basic templates. May need more specific templates based on editorial needs.

### 12.2 Clarifications Needed

1. **AI Model Preferences:**
   - Preferred AI models untuk each operation?
   - Budget constraints untuk AI operations?
   - Acceptable response times untuk AI generations?

2. **Content Workflow:**
   - Editorial review process before publishing?
   - Multi-stage approval workflow needed?
   - Content versioning requirements?

3. **Media Monitoring:**
   - Specific news sources to monitor?
   - Scraping frequency preferences?
   - Legal considerations untuk content scraping?

4. **User Roles:**
   - Additional roles beyond Admin/Editor?
   - Granular permissions needed?
   - Guest contributor access?

5. **Analytics Requirements:**
   - Specific metrics to track?
   - Reporting frequency?
   - Integration dengan external analytics tools?

6. **Scalability:**
   - Expected traffic growth?
   - Geographic distribution of users?
   - Need untuk multi-region deployment?

### 12.3 Technical Decisions to Confirm

1. **State Management:** Context API vs Redux/Zustand untuk complex state
2. **Rich Text Editor:** TinyMCE vs Quill vs custom solution
3. **Image Processing:** Client-side vs server-side resizing
4. **Search Implementation:** Supabase full-text search vs Algolia/Meilisearch
5. **Caching Strategy:** Browser cache vs Redis vs CDN
6. **Testing Strategy:** Unit tests coverage requirements

## 13. Next Steps

### 13.1 Immediate Actions
1. Confirm technical decisions dan clarifications
2. Setup Supabase project dan configure database
3. Create database schema dengan migrations
4. Setup development environment
5. Initialize React project dengan Vite

### 13.2 Development Roadmap
**Week 1-2:** Core infrastructure dan authentication
**Week 3-4:** Content management features
**Week 5-6:** AI integration
**Week 7-8:** Advanced features dan optimization

### 13.3 Documentation Deliverables
- API documentation dengan OpenAPI spec
- Component documentation dengan Storybook
- User manual untuk admin/editor
- Deployment guide
- Maintenance guide
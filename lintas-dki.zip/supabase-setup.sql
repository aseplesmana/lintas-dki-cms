-- ============================================
-- LINTAS DKI CMS - SUPABASE DATABASE SETUP
-- ============================================
-- Run this SQL in Supabase SQL Editor
-- This will create all tables and insert sample data

BEGIN;

-- ============================================
-- 1. CREATE TABLES
-- ============================================

-- Users table (extends auth.users)
CREATE TABLE IF NOT EXISTS public.users (
  id UUID REFERENCES auth.users PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  role TEXT DEFAULT 'writer' CHECK (role IN ('admin', 'editor', 'writer')),
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Categories
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  parent_id UUID REFERENCES categories(id),
  "order" INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tags
CREATE TABLE IF NOT EXISTS public.tags (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  color TEXT DEFAULT '#3B82F6',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Articles
CREATE TABLE IF NOT EXISTS public.articles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  category_id UUID REFERENCES categories(id),
  author_id UUID REFERENCES users(id),
  featured_image TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  published_at TIMESTAMP WITH TIME ZONE,
  scheduled_at TIMESTAMP WITH TIME ZONE,
  views INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  meta_title TEXT,
  meta_description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Article Tags (many-to-many)
CREATE TABLE IF NOT EXISTS public.article_tags (
  article_id UUID REFERENCES articles(id) ON DELETE CASCADE,
  tag_id UUID REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (article_id, tag_id)
);

-- Reports
CREATE TABLE IF NOT EXISTS public.reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  template TEXT NOT NULL,
  content TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'completed', 'archived')),
  author_id UUID REFERENCES users(id),
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_author ON articles(author_id);
CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at);
CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug);
CREATE INDEX IF NOT EXISTS idx_tags_slug ON tags(slug);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE article_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

-- ============================================
-- 2. RLS POLICIES
-- ============================================

-- Public can read published articles
DROP POLICY IF EXISTS "Public can read published articles" ON articles;
CREATE POLICY "Public can read published articles" ON articles
  FOR SELECT USING (status = 'published');

-- Public can read active categories
DROP POLICY IF EXISTS "Public can read active categories" ON categories;
CREATE POLICY "Public can read active categories" ON categories
  FOR SELECT USING (is_active = true);

-- Public can read all tags
DROP POLICY IF EXISTS "Public can read tags" ON tags;
CREATE POLICY "Public can read tags" ON tags
  FOR SELECT USING (true);

-- Authenticated users can manage their own articles
DROP POLICY IF EXISTS "Users can manage own articles" ON articles;
CREATE POLICY "Users can manage own articles" ON articles
  FOR ALL USING (auth.uid() = author_id);

-- Authenticated users can manage all articles (for admin/editor)
DROP POLICY IF EXISTS "Authenticated can manage articles" ON articles;
CREATE POLICY "Authenticated can manage articles" ON articles
  FOR ALL USING (auth.role() = 'authenticated');

-- ============================================
-- 3. INSERT SAMPLE DATA
-- ============================================

-- Insert Categories
INSERT INTO categories (id, name, slug, description, "order", is_active) VALUES
  ('c1111111-1111-1111-1111-111111111111', 'Berita', 'berita', 'Berita terkini seputar Jakarta dan Indonesia', 1, true),
  ('c2222222-2222-2222-2222-222222222222', 'Politik', 'politik', 'Berita politik dan pemerintahan', 2, true),
  ('c3333333-3333-3333-3333-333333333333', 'Ekonomi', 'ekonomi', 'Berita ekonomi dan bisnis', 3, true),
  ('c4444444-4444-4444-4444-444444444444', 'Olahraga', 'olahraga', 'Berita olahraga dan kompetisi', 4, true),
  ('c5555555-5555-5555-5555-555555555555', 'Teknologi', 'teknologi', 'Berita teknologi dan inovasi', 5, true),
  ('c6666666-6666-6666-6666-666666666666', 'Hiburan', 'hiburan', 'Berita hiburan dan selebriti', 6, true)
ON CONFLICT (id) DO NOTHING;

-- Insert Tags
INSERT INTO tags (id, name, slug, color) VALUES
  ('t1111111-1111-1111-1111-111111111111', 'Jakarta', 'jakarta', '#3B82F6'),
  ('t2222222-2222-2222-2222-222222222222', 'Trending', 'trending', '#EF4444'),
  ('t3333333-3333-3333-3333-333333333333', 'Breaking News', 'breaking-news', '#F59E0B'),
  ('t4444444-4444-4444-4444-444444444444', 'Investigasi', 'investigasi', '#8B5CF6'),
  ('t5555555-5555-5555-5555-555555555555', 'Opini', 'opini', '#10B981'),
  ('t6666666-6666-6666-6666-666666666666', 'Wawancara', 'wawancara', '#EC4899')
ON CONFLICT (id) DO NOTHING;

-- Insert Sample Articles (10 articles)
INSERT INTO articles (id, title, slug, content, excerpt, category_id, featured_image, status, published_at, views, is_featured, meta_title, meta_description) VALUES
  (
    'a1111111-1111-1111-1111-111111111111',
    'Gubernur DKI Jakarta Resmikan MRT Fase 3 yang Menghubungkan Jakarta Utara',
    'gubernur-dki-jakarta-resmikan-mrt-fase-3',
    '<p>Jakarta - Gubernur DKI Jakarta hari ini meresmikan pembukaan MRT Jakarta Fase 3 yang menghubungkan Jakarta Utara dengan pusat kota. Proyek infrastruktur senilai Rp 50 triliun ini diharapkan dapat mengurangi kemacetan di ibu kota.</p><p>Dalam sambutannya, Gubernur menyatakan bahwa MRT Fase 3 ini merupakan bagian dari komitmen pemerintah daerah untuk menyediakan transportasi publik yang modern dan ramah lingkungan. "Dengan hadirnya MRT Fase 3, kami berharap masyarakat Jakarta semakin nyaman menggunakan transportasi umum," ujarnya.</p><p>MRT Fase 3 memiliki 8 stasiun baru dengan total panjang jalur 12 kilometer. Diperkirakan dapat melayani 200 ribu penumpang per hari pada tahap awal operasional.</p>',
    'Gubernur DKI Jakarta meresmikan MRT Fase 3 senilai Rp 50 triliun yang menghubungkan Jakarta Utara dengan pusat kota.',
    'c1111111-1111-1111-1111-111111111111',
    'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '2 hours',
    1250,
    true,
    'Gubernur DKI Resmikan MRT Fase 3 Jakarta Utara',
    'MRT Jakarta Fase 3 diresmikan, menghubungkan Jakarta Utara dengan pusat kota untuk mengurangi kemacetan.'
  ),
  (
    'a2222222-2222-2222-2222-222222222222',
    'DPRD DKI Setujui Anggaran Rp 85 Triliun untuk Pembangunan 2025',
    'dprd-dki-setujui-anggaran-pembangunan-2025',
    '<p>Jakarta - DPRD DKI Jakarta secara resmi menyetujui Anggaran Pendapatan dan Belanja Daerah (APBD) 2025 sebesar Rp 85 triliun. Anggaran ini akan difokuskan pada pembangunan infrastruktur, pendidikan, dan kesehatan.</p><p>Ketua DPRD DKI Jakarta menyatakan bahwa pembahasan anggaran telah dilakukan secara mendalam dengan melibatkan berbagai stakeholder. "Kami memastikan setiap rupiah anggaran digunakan untuk kesejahteraan masyarakat Jakarta," katanya.</p><p>Dari total anggaran tersebut, 35% akan dialokasikan untuk infrastruktur, 25% untuk pendidikan, 20% untuk kesehatan, dan sisanya untuk program-program lainnya.</p>',
    'DPRD DKI Jakarta menyetujui APBD 2025 sebesar Rp 85 triliun untuk pembangunan infrastruktur, pendidikan, dan kesehatan.',
    'c2222222-2222-2222-2222-222222222222',
    'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '5 hours',
    890,
    true,
    'DPRD DKI Setujui APBD 2025 Rp 85 Triliun',
    'DPRD DKI Jakarta menyetujui anggaran Rp 85 triliun untuk pembangunan daerah tahun 2025.'
  ),
  (
    'a3333333-3333-3333-3333-333333333333',
    'Pertumbuhan Ekonomi Jakarta Capai 6.2% di Kuartal III 2024',
    'pertumbuhan-ekonomi-jakarta-capai-6-2-persen',
    '<p>Jakarta - Badan Pusat Statistik (BPS) DKI Jakarta mencatat pertumbuhan ekonomi Jakarta mencapai 6.2% di kuartal III 2024, melampaui target pemerintah sebesar 5.8%.</p><p>Kepala BPS DKI Jakarta menjelaskan bahwa pertumbuhan ini didorong oleh sektor perdagangan, jasa, dan industri kreatif. "Pemulihan ekonomi pasca pandemi terus berlanjut dengan baik," ujarnya.</p><p>Sektor yang mengalami pertumbuhan tertinggi adalah teknologi informasi dengan 8.5%, diikuti oleh sektor pariwisata 7.3%, dan sektor konstruksi 6.8%. Pemerintah optimis pertumbuhan ekonomi akan terus meningkat di kuartal berikutnya.</p>',
    'BPS DKI Jakarta mencatat pertumbuhan ekonomi Jakarta mencapai 6.2% di kuartal III 2024, melampaui target pemerintah.',
    'c3333333-3333-3333-3333-333333333333',
    'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '8 hours',
    720,
    true,
    'Ekonomi Jakarta Tumbuh 6.2% di Q3 2024',
    'Pertumbuhan ekonomi Jakarta mencapai 6.2% di kuartal III 2024, didorong sektor perdagangan dan jasa.'
  ),
  (
    'a4444444-4444-4444-4444-444444444444',
    'Persija Jakarta Juara Liga 1 Setelah Kalahkan Persib Bandung 3-1',
    'persija-jakarta-juara-liga-1-2024',
    '<p>Jakarta - Persija Jakarta berhasil meraih gelar juara Liga 1 2024 setelah mengalahkan Persib Bandung dengan skor 3-1 di Stadion Utama Gelora Bung Karno.</p><p>Pertandingan yang berlangsung sengit sejak awal babak ini dimenangkan oleh Persija berkat tiga gol dari Marko Simic, Riko Simanjuntak, dan Osvaldo Haay. Persib hanya mampu membalas satu gol melalui David da Silva.</p><p>Ini merupakan gelar juara Liga 1 ketiga bagi Persija Jakarta. Pelatih Persija menyatakan bangga dengan pencapaian timnya dan berterima kasih kepada suporter Jakmania yang selalu setia mendukung.</p>',
    'Persija Jakarta meraih gelar juara Liga 1 2024 setelah mengalahkan Persib Bandung 3-1 di final yang dramatis.',
    'c4444444-4444-4444-4444-444444444444',
    'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '12 hours',
    2150,
    false,
    'Persija Jakarta Juara Liga 1 2024',
    'Persija Jakarta meraih gelar juara Liga 1 setelah mengalahkan Persib Bandung 3-1 di final.'
  ),
  (
    'a5555555-5555-5555-5555-555555555555',
    'Startup Jakarta Raih Pendanaan Seri B Senilai $50 Juta',
    'startup-jakarta-raih-pendanaan-50-juta-dolar',
    '<p>Jakarta - Startup teknologi asal Jakarta berhasil meraih pendanaan Seri B senilai $50 juta dari investor global. Dana ini akan digunakan untuk ekspansi ke pasar Asia Tenggara.</p><p>CEO startup tersebut menyatakan bahwa pendanaan ini merupakan bukti kepercayaan investor terhadap potensi pasar Indonesia. "Kami akan menggunakan dana ini untuk mengembangkan produk dan memperluas tim," katanya.</p><p>Startup yang bergerak di bidang fintech ini telah melayani lebih dari 5 juta pengguna di Indonesia dan menargetkan untuk mencapai 20 juta pengguna dalam dua tahun ke depan.</p>',
    'Startup teknologi Jakarta meraih pendanaan Seri B $50 juta untuk ekspansi ke Asia Tenggara.',
    'c5555555-5555-5555-5555-555555555555',
    'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '1 day',
    560,
    false,
    'Startup Jakarta Raih Pendanaan $50 Juta',
    'Startup fintech Jakarta berhasil meraih pendanaan Seri B senilai $50 juta dari investor global.'
  ),
  (
    'a6666666-6666-6666-6666-666666666666',
    'Festival Film Jakarta 2024 Dibuka dengan Penampilan Spektakuler',
    'festival-film-jakarta-2024-dibuka',
    '<p>Jakarta - Festival Film Jakarta 2024 resmi dibuka dengan upacara pembukaan yang spektakuler di Teater Jakarta. Festival yang berlangsung selama 10 hari ini menampilkan 150 film dari berbagai negara.</p><p>Direktur Festival menyatakan bahwa tahun ini festival menghadirkan tema "Cinema for Humanity" yang mengangkat isu-isu kemanusiaan global. "Kami berharap festival ini dapat menginspirasi pembuat film muda Indonesia," ujarnya.</p><p>Festival Film Jakarta 2024 juga menghadirkan masterclass dari sutradara ternama dunia dan kompetisi film pendek dengan total hadiah Rp 500 juta.</p>',
    'Festival Film Jakarta 2024 dibuka dengan tema "Cinema for Humanity" menampilkan 150 film dari berbagai negara.',
    'c6666666-6666-6666-6666-666666666666',
    'https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '1 day',
    430,
    false,
    'Festival Film Jakarta 2024 Resmi Dibuka',
    'Festival Film Jakarta 2024 dibuka dengan menampilkan 150 film dan tema Cinema for Humanity.'
  ),
  (
    'a7777777-7777-7777-7777-777777777777',
    'Pemprov DKI Luncurkan Program Beasiswa untuk 10.000 Siswa Berprestasi',
    'pemprov-dki-luncurkan-program-beasiswa',
    '<p>Jakarta - Pemerintah Provinsi DKI Jakarta meluncurkan program beasiswa untuk 10.000 siswa berprestasi dari keluarga kurang mampu. Program ini mencakup biaya pendidikan dari SD hingga perguruan tinggi.</p><p>Kepala Dinas Pendidikan DKI Jakarta menyatakan bahwa program ini merupakan komitmen pemerintah untuk meningkatkan kualitas pendidikan di Jakarta. "Tidak ada anak Jakarta yang tidak bisa sekolah karena masalah biaya," tegasnya.</p><p>Pendaftaran program beasiswa dibuka mulai bulan depan melalui website resmi Dinas Pendidikan DKI Jakarta. Seleksi akan dilakukan berdasarkan prestasi akademik dan kondisi ekonomi keluarga.</p>',
    'Pemprov DKI Jakarta meluncurkan program beasiswa untuk 10.000 siswa berprestasi dari keluarga kurang mampu.',
    'c1111111-1111-1111-1111-111111111111',
    '/images/Scholarship.jpg',
    'published',
    NOW() - INTERVAL '2 days',
    680,
    false,
    'Pemprov DKI Beri Beasiswa 10.000 Siswa',
    'Pemerintah DKI Jakarta meluncurkan program beasiswa untuk 10.000 siswa berprestasi.'
  ),
  (
    'a8888888-8888-8888-8888-888888888888',
    'Jakarta Smart City Raih Penghargaan Internasional untuk Inovasi Digital',
    'jakarta-smart-city-raih-penghargaan-internasional',
    '<p>Jakarta - Program Jakarta Smart City meraih penghargaan internasional dari World Smart City Organization untuk kategori Best Digital Innovation. Penghargaan ini diberikan atas inovasi aplikasi Jaklingko yang mengintegrasikan seluruh moda transportasi publik.</p><p>Kepala Jakarta Smart City menyatakan bahwa penghargaan ini merupakan hasil kerja keras tim dalam mengembangkan solusi digital untuk masyarakat. "Kami akan terus berinovasi untuk memberikan layanan terbaik," katanya.</p><p>Aplikasi Jaklingko telah diunduh lebih dari 3 juta kali dan memiliki rating 4.5 bintang di Google Play Store. Aplikasi ini memungkinkan pengguna untuk merencanakan perjalanan, membeli tiket, dan mendapatkan informasi real-time tentang transportasi publik.</p>',
    'Jakarta Smart City meraih penghargaan internasional untuk inovasi aplikasi Jaklingko yang mengintegrasikan transportasi publik.',
    'c5555555-5555-5555-5555-555555555555',
    'https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '3 days',
    520,
    false,
    'Jakarta Smart City Raih Penghargaan Dunia',
    'Jakarta Smart City meraih penghargaan internasional untuk inovasi digital aplikasi Jaklingko.'
  ),
  (
    'a9999999-9999-9999-9999-999999999999',
    'Kebakaran Besar di Pasar Tanah Abang, 200 Kios Terbakar',
    'kebakaran-besar-pasar-tanah-abang',
    '<p>Jakarta - Kebakaran besar terjadi di Pasar Tanah Abang pada dini hari tadi, menghanguskan sekitar 200 kios. Tidak ada korban jiwa dalam insiden ini, namun kerugian material diperkirakan mencapai Rp 50 miliar.</p><p>Kepala Dinas Pemadam Kebakaran DKI Jakarta menyatakan bahwa 30 unit mobil pemadam telah dikerahkan untuk memadamkan api. "Api berhasil dipadamkan setelah 5 jam," ujarnya.</p><p>Penyebab kebakaran masih dalam penyelidikan. Pemprov DKI Jakarta berjanji akan memberikan bantuan kepada para pedagang yang terdampak dan mempercepat proses renovasi pasar.</p>',
    'Kebakaran besar di Pasar Tanah Abang menghanguskan 200 kios dengan kerugian mencapai Rp 50 miliar.',
    'c1111111-1111-1111-1111-111111111111',
    'https://images.unsplash.com/photo-1577962917302-cd874c4e31d2?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '4 days',
    1850,
    false,
    'Kebakaran Besar di Pasar Tanah Abang',
    'Kebakaran melanda Pasar Tanah Abang, 200 kios terbakar dengan kerugian Rp 50 miliar.'
  ),
  (
    'a0000000-0000-0000-0000-000000000000',
    'Pemprov DKI Bangun 50 Taman Kota Baru untuk Ruang Terbuka Hijau',
    'pemprov-dki-bangun-50-taman-kota-baru',
    '<p>Jakarta - Pemerintah Provinsi DKI Jakarta menargetkan pembangunan 50 taman kota baru di seluruh wilayah Jakarta untuk meningkatkan ruang terbuka hijau (RTH). Program ini merupakan bagian dari upaya menjadikan Jakarta sebagai kota yang lebih hijau dan ramah lingkungan.</p><p>Kepala Dinas Pertamanan dan Hutan Kota menyatakan bahwa pembangunan taman akan dimulai tahun depan dengan total anggaran Rp 500 miliar. "Setiap taman akan dilengkapi dengan fasilitas olahraga, area bermain anak, dan WiFi gratis," jelasnya.</p><p>Target RTH Jakarta adalah 30% dari total luas wilayah. Saat ini RTH Jakarta baru mencapai 15%, sehingga pembangunan taman-taman baru ini sangat penting untuk mencapai target tersebut.</p>',
    'Pemprov DKI Jakarta menargetkan pembangunan 50 taman kota baru untuk meningkatkan ruang terbuka hijau.',
    'c1111111-1111-1111-1111-111111111111',
    'https://images.unsplash.com/photo-1519331379826-f10be5486c6f?w=1200&h=675&fit=crop',
    'published',
    NOW() - INTERVAL '5 days',
    390,
    false,
    'Pemprov DKI Bangun 50 Taman Kota',
    'Pemerintah DKI Jakarta akan membangun 50 taman kota baru untuk meningkatkan RTH.'
  )
ON CONFLICT (id) DO NOTHING;

-- Link articles with tags
INSERT INTO article_tags (article_id, tag_id) VALUES
  ('a1111111-1111-1111-1111-111111111111', 't1111111-1111-1111-1111-111111111111'),
  ('a1111111-1111-1111-1111-111111111111', 't2222222-2222-2222-2222-222222222222'),
  ('a2222222-2222-2222-2222-222222222222', 't1111111-1111-1111-1111-111111111111'),
  ('a3333333-3333-3333-3333-333333333333', 't1111111-1111-1111-1111-111111111111'),
  ('a4444444-4444-4444-4444-444444444444', 't2222222-2222-2222-2222-222222222222'),
  ('a5555555-5555-5555-5555-555555555555', 't1111111-1111-1111-1111-111111111111'),
  ('a6666666-6666-6666-6666-666666666666', 't1111111-1111-1111-1111-111111111111'),
  ('a7777777-7777-7777-7777-777777777777', 't1111111-1111-1111-1111-111111111111'),
  ('a8888888-8888-8888-8888-888888888888', 't1111111-1111-1111-1111-111111111111'),
  ('a9999999-9999-9999-9999-999999999999', 't3333333-3333-3333-3333-333333333333'),
  ('a0000000-0000-0000-0000-000000000000', 't1111111-1111-1111-1111-111111111111')
ON CONFLICT (article_id, tag_id) DO NOTHING;

COMMIT;

-- ============================================
-- VERIFICATION QUERIES
-- ============================================
-- Run these to verify data was inserted correctly

-- Check categories
SELECT COUNT(*) as total_categories FROM categories;

-- Check tags
SELECT COUNT(*) as total_tags FROM tags;

-- Check articles
SELECT COUNT(*) as total_articles FROM articles WHERE status = 'published';

-- Check article-tag relationships
SELECT COUNT(*) as total_article_tags FROM article_tags;

-- View sample articles
SELECT 
  a.title,
  a.slug,
  c.name as category,
  a.views,
  a.is_featured,
  a.published_at
FROM articles a
LEFT JOIN categories c ON a.category_id = c.id
WHERE a.status = 'published'
ORDER BY a.published_at DESC
LIMIT 5;
# Lintas DKI CMS

Content Management System untuk portal berita Lintas DKI dengan fitur lengkap untuk manajemen artikel, laporan, kategori, tag, media, dan monitoring.

## 🚀 Features

### Admin Panel
- **Dashboard** - Overview statistik artikel, views, engagement
- **Article Management** - CRUD artikel dengan rich text editor
- **Report Management** - Generate laporan dengan AI templates
- **Category & Tag Management** - Kelola kategori dan tag artikel
- **Media Library** - Upload dan kelola file media
- **Monitoring** - Dashboard monitoring artikel trending
- **User Management** - Kelola user dan permissions
- **Settings** - Konfigurasi aplikasi

### Public Website
- **Homepage** - Featured articles, categories, latest news
- **Article Detail** - Full article dengan comments dan social sharing
- **Category Pages** - Browse artikel by category
- **Search** - Cari artikel dengan filter kategori
- **About** - Informasi perusahaan
- **Contact** - Form kontak dengan map

### Key Features
- ✅ Authentication & Authorization (Supabase Auth)
- ✅ Rich Text Editor untuk artikel
- ✅ AI Report Generator dengan templates
- ✅ Media upload dengan preview
- ✅ Social sharing (Facebook, Twitter, LinkedIn, WhatsApp)
- ✅ Comment system
- ✅ Newsletter subscription
- ✅ Responsive design (mobile, tablet, desktop)
- ✅ SEO optimization
- ✅ Real-time data dengan Supabase

## 📋 Prerequisites

- Node.js 18+ dan pnpm
- Supabase account
- Git

## 🛠️ Installation

### 1. Clone Repository

```bash
git clone <repository-url>
cd lintas-dki
```

### 2. Install Dependencies

```bash
pnpm install
```

### 3. Environment Setup

Copy `.env.example` ke `.env` dan isi dengan credentials Supabase Anda:

```bash
cp .env.example .env
```

Edit `.env`:
```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 4. Database Setup

#### Supabase Tables

Buat tables berikut di Supabase SQL Editor:

```sql
-- Users table (sudah ada dari Supabase Auth)
-- Extend dengan profile
CREATE TABLE IF NOT EXISTS public.users (
  id UUID REFERENCES auth.users PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT,
  role TEXT DEFAULT 'writer' CHECK (role IN ('admin', 'editor', 'writer')),
  avatar_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Categories
CREATE TABLE IF NOT EXISTS public.categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  description TEXT,
  parent_id UUID REFERENCES categories(id),
  order INTEGER DEFAULT 0,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tags
CREATE TABLE IF NOT EXISTS public.tags (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  color TEXT DEFAULT '#3B82F6',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Articles
CREATE TABLE IF NOT EXISTS public.articles (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  content TEXT NOT NULL,
  excerpt TEXT,
  category_id UUID REFERENCES categories(id),
  author_id UUID REFERENCES users(id),
  featured_image TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'archived')),
  published_at TIMESTAMP WITH TIME ZONE,
  scheduled_at TIMESTAMP WITH TIME ZONE,
  views INTEGER DEFAULT 0,
  is_featured BOOLEAN DEFAULT false,
  meta_title TEXT,
  meta_description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Article Tags (many-to-many)
CREATE TABLE IF NOT EXISTS public.article_tags (
  article_id UUID REFERENCES articles(id) ON DELETE CASCADE,
  tag_id UUID REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY (article_id, tag_id)
);

-- Reports
CREATE TABLE IF NOT EXISTS public.reports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT,
  template TEXT NOT NULL,
  content TEXT,
  status TEXT DEFAULT 'draft' CHECK (status IN ('draft', 'completed', 'archived')),
  author_id UUID REFERENCES users(id),
  metadata JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_author ON articles(author_id);
CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at);
CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug);
CREATE INDEX IF NOT EXISTS idx_tags_slug ON tags(slug);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE article_tags ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;

-- RLS Policies (contoh - sesuaikan dengan kebutuhan)
-- Public can read published articles
CREATE POLICY "Public can read published articles" ON articles
  FOR SELECT USING (status = 'published');

-- Authenticated users can manage their own articles
CREATE POLICY "Users can manage own articles" ON articles
  FOR ALL USING (auth.uid() = author_id);

-- Public can read active categories
CREATE POLICY "Public can read active categories" ON categories
  FOR SELECT USING (is_active = true);

-- Similar policies untuk tables lain...
```

#### Storage Buckets

Buat storage bucket untuk media files:

1. Go to Supabase Dashboard → Storage
2. Create new bucket: `media`
3. Set public access untuk bucket
4. Configure CORS jika diperlukan

### 5. Run Development Server

```bash
pnpm run dev
```

Aplikasi akan berjalan di `http://localhost:5173`

## 📦 Build & Deploy

### Production Build

```bash
pnpm run build
```

Build output akan ada di folder `dist/`

### Lint & Type Check

```bash
pnpm run lint
pnpm run type-check
```

### Preview Production Build

```bash
pnpm run preview
```

## 🗂️ Project Structure

```
lintas-dki/
├── src/
│   ├── components/          # Reusable components
│   │   ├── article/         # Article-related components
│   │   ├── auth/            # Authentication components
│   │   ├── category/        # Category components
│   │   ├── common/          # Common UI components
│   │   ├── dashboard/       # Dashboard components
│   │   ├── layout/          # Layout components
│   │   ├── media/           # Media components
│   │   ├── public/          # Public website components
│   │   ├── report/          # Report components
│   │   └── tag/             # Tag components
│   ├── contexts/            # React contexts
│   │   └── AuthContext.tsx  # Authentication context
│   ├── pages/               # Page components
│   │   ├── admin/           # Admin pages
│   │   ├── auth/            # Auth pages
│   │   └── public/          # Public pages
│   ├── services/            # API services
│   │   └── supabase/        # Supabase services
│   ├── types/               # TypeScript types
│   ├── utils/               # Utility functions
│   ├── App.tsx              # Main app component
│   └── main.tsx             # Entry point
├── public/                  # Static assets
├── docs/                    # Documentation
├── .env.example             # Environment variables example
├── package.json             # Dependencies
├── tsconfig.json            # TypeScript config
├── vite.config.ts           # Vite config
└── README.md                # This file
```

## 🔐 Authentication

### Default Admin Account

Buat admin account pertama melalui Supabase Dashboard:

1. Go to Authentication → Users
2. Add new user dengan email dan password
3. Update user role di table `users`:
   ```sql
   UPDATE users SET role = 'admin' WHERE email = 'admin@example.com';
   ```

### User Roles

- **Admin** - Full access ke semua fitur
- **Editor** - Manage articles, reports, categories, tags
- **Writer** - Create dan edit own articles

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

## 🎨 Design System

### Colors
- Primary: Blue-600 (#2563EB)
- Secondary: Slate-600 (#475569)
- Success: Green-600 (#10B981)
- Warning: Orange-600 (#F97316)
- Danger: Red-600 (#EF4444)

### Typography
- Font Family: Inter (sans-serif)
- Headings: font-bold
- Body: font-normal

## 🧪 Testing

### Manual Testing Checklist

**Authentication:**
- [ ] Login dengan email/password
- [ ] Logout
- [ ] Password reset
- [ ] Protected routes redirect ke login

**Article Management:**
- [ ] Create new article
- [ ] Edit article
- [ ] Delete article
- [ ] Publish article
- [ ] Search articles
- [ ] Filter by category/status

**Report Management:**
- [ ] Create report dengan template
- [ ] Edit report
- [ ] Delete report
- [ ] View report detail

**Category & Tag:**
- [ ] Create category
- [ ] Edit category
- [ ] Delete category
- [ ] Create tag dengan color picker
- [ ] Edit tag
- [ ] Delete tag

**Media:**
- [ ] Upload image
- [ ] Upload document
- [ ] Delete media
- [ ] Copy media URL

**Public Pages:**
- [ ] Homepage loads dengan featured articles
- [ ] Article detail page
- [ ] Category page dengan filtering
- [ ] Search functionality
- [ ] Social sharing buttons
- [ ] Comment form
- [ ] Newsletter subscription

**Responsive:**
- [ ] Test di mobile (375px)
- [ ] Test di tablet (768px)
- [ ] Test di desktop (1024px+)

## 🐛 Known Issues & Limitations

- ESLint warnings (23 warnings) - non-blocking, mostly React Hook dependencies
- Comment system menggunakan mock data (belum terintegrasi dengan backend)
- Newsletter subscription belum terintegrasi dengan email service
- Media upload belum ada size limit validation di frontend

## 📝 TODO / Future Enhancements

- [ ] Implement real comment system dengan Supabase
- [ ] Add email service integration untuk newsletter
- [ ] Add pagination untuk article lists
- [ ] Implement infinite scroll
- [ ] Add search autocomplete
- [ ] Add article bookmarks
- [ ] Add dark mode
- [ ] Generate XML sitemap
- [ ] Add structured data (Schema.org)
- [ ] Implement image optimization
- [ ] Add unit tests
- [ ] Add E2E tests
- [ ] Add CI/CD pipeline

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License.

## 👥 Team

- **Project Manager** - Mike
- **Engineer** - Alex
- **Design** - Based on modern CMS best practices

## 📞 Support

Untuk pertanyaan atau bantuan, silakan hubungi:
- Email: support@lintasdki.com
- Website: https://lintasdki.com

---

**Built with ❤️ using React, TypeScript, Tailwind CSS, and Supabase**